package com.mchange.lang;

import com.mchange.v2.lang.VersionUtils;
import java.io.PrintStream;
import java.io.PrintWriter;


public class PotentiallySecondaryException extends Exception implements PotentiallySecondary {
   static final String NESTED_MSG = ">>>>>>>>>> NESTED EXCEPTION >>>>>>>>";
   Throwable nested;

   public PotentiallySecondaryException(String msg, Throwable t) {
      super(msg);
      this.nested = t;
   }

   public PotentiallySecondaryException(Throwable t) {
      this("", t);
   }

   public PotentiallySecondaryException(String msg) {
      this(msg, (Throwable)null);
   }

   public PotentiallySecondaryException() {
      this("", (Throwable)null);
   }

   public Throwable getNestedThrowable() {
      return this.nested;
   }

   private void setNested(Throwable t) {
      this.nested = t;
      if (VersionUtils.isAtLeastJavaVersion14()) {
         this.initCause(t);
      }

   }

   public void printStackTrace(PrintWriter pw) {
      super.printStackTrace(pw);
      if (!VersionUtils.isAtLeastJavaVersion14() && this.nested != null) {
         pw.println(">>>>>>>>>> NESTED EXCEPTION >>>>>>>>");
         this.nested.printStackTrace(pw);
      }

   }

   public void printStackTrace(PrintStream ps) {
      super.printStackTrace(ps);
      if (!VersionUtils.isAtLeastJavaVersion14() && this.nested != null) {
         ps.println("NESTED_MSG");
         this.nested.printStackTrace(ps);
      }

   }

   public void printStackTrace() {
      if (VersionUtils.isAtLeastJavaVersion14()) {
         super.printStackTrace();
      } else {
         this.printStackTrace(System.err);
      }

   }
}