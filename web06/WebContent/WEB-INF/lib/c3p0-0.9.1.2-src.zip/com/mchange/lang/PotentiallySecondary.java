package com.mchange.lang;

public interface PotentiallySecondary {
   Throwable getNestedThrowable();
}