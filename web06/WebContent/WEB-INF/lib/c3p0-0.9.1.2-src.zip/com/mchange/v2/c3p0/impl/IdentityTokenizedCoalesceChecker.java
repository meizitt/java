package com.mchange.v2.c3p0.impl;

import com.mchange.v2.coalesce.CoalesceChecker;

public final class IdentityTokenizedCoalesceChecker implements CoalesceChecker {
   public static IdentityTokenizedCoalesceChecker INSTANCE = new IdentityTokenizedCoalesceChecker();

   public boolean checkCoalesce(Object a, Object b) {
      IdentityTokenized aa = (IdentityTokenized)a;
      IdentityTokenized bb = (IdentityTokenized)b;
      String ta = aa.getIdentityToken();
      String tb = bb.getIdentityToken();
      if (ta != null && tb != null) {
         return ta.equals(tb);
      } else {
         throw new NullPointerException("[c3p0 bug] An IdentityTokenized object has no identity token set?!?! " + (ta == null ? ta : tb));
      }
   }

   public int coalesceHash(Object a) {
      String t = ((IdentityTokenized)a).getIdentityToken();
      return t != null ? t.hashCode() : 0;
   }
}