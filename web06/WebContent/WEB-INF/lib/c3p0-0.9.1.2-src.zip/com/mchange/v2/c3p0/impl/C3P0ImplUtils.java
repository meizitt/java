package com.mchange.v2.c3p0.impl;

import com.mchange.lang.ByteUtils;
import com.mchange.v2.c3p0.ConnectionTester;
import com.mchange.v2.c3p0.PoolConfig;
import com.mchange.v2.cfg.MultiPropertiesConfig;
import com.mchange.v2.encounter.EncounterCounter;
import com.mchange.v2.encounter.EqualityEncounterCounter;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.ser.SerializableUtils;
import com.mchange.v2.sql.SqlUtils;
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Map;

public final class C3P0ImplUtils {
   private static final boolean CONDITIONAL_LONG_TOKENS = false;
   static final MLogger logger;
   public static final DbAuth NULL_AUTH;
   public static final Object[] NOARGS;
   private static final EncounterCounter ID_TOKEN_COUNTER;
   public static final String VMID_PROPKEY = "com.mchange.v2.c3p0.VMID";
   private static final String VMID_PFX;
   static String connectionTesterClassName;
   static ConnectionTester cachedTester;
   private static final String HASM_HEADER = "HexAsciiSerializedMap";

   private static String generateVmId() {
      DataOutputStream dos = null;
      DataInputStream dis = null;

      String var3;
      try {
         SecureRandom srand = new SecureRandom();
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         dos = new DataOutputStream(baos);

         try {
            dos.write(InetAddress.getLocalHost().getAddress());
         } catch (Exception var25) {
            if (logger.isLoggable(MLevel.INFO)) {
               logger.log(MLevel.INFO, "Failed to get local InetAddress for VMID. This is unlikely to matter. At all. We'll add some extra randomness", var25);
            }

            dos.write(srand.nextInt());
         }

         dos.writeLong(System.currentTimeMillis());
         dos.write(srand.nextInt());
         int remainder = baos.size() % 4;
         byte[] vmid_bytes;
         if (remainder > 0) {
            int pad = 4 - remainder;
            vmid_bytes = new byte[pad];
            srand.nextBytes(vmid_bytes);
            dos.write(vmid_bytes);
         }

         StringBuffer sb = new StringBuffer(32);
         vmid_bytes = baos.toByteArray();
         dis = new DataInputStream(new ByteArrayInputStream(vmid_bytes));
         int i = 0;

         for(int num_ints = vmid_bytes.length / 4; i < num_ints; ++i) {
            int signed = dis.readInt();
            long unsigned = (long)signed & 4294967295L;
            sb.append(Long.toString(unsigned, 36));
         }

         String var30 = sb.toString();
         return var30;
      } catch (IOException var26) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Bizarro! IOException while reading/writing from ByteArray-based streams? We're skipping the VMID thing. It almost certainly doesn't matter, but please report the error.", var26);
         }

         var3 = "";
      } finally {
         try {
            if (dos != null) {
               dos.close();
            }
         } catch (IOException var24) {
            logger.log(MLevel.WARNING, "Huh? Exception close()ing a byte-array bound OutputStream.", var24);
         }

         try {
            if (dis != null) {
               dis.close();
            }
         } catch (IOException var23) {
            logger.log(MLevel.WARNING, "Huh? Exception close()ing a byte-array bound IntputStream.", var23);
         }

      }

      return var3;
   }

   public static String allocateIdentityToken(Object o) {
      if (o == null) {
         return null;
      } else {
         String shortIdToken = Integer.toString(System.identityHashCode(o), 16);
         StringBuffer sb = new StringBuffer(128);
         sb.append(VMID_PFX);
         long count;
         if (ID_TOKEN_COUNTER != null && (count = ID_TOKEN_COUNTER.encounter(shortIdToken)) > 0L) {
            sb.append(shortIdToken);
            sb.append('#');
            sb.append(count);
         } else {
            sb.append(shortIdToken);
         }

         String out = sb.toString().intern();
         return out;
      }
   }

   public static DbAuth findAuth(Object o) throws SQLException {
      if (o == null) {
         return NULL_AUTH;
      } else {
         String user = null;
         String password = null;
         String overrideDefaultUser = null;
         String overrideDefaultPassword = null;

         try {
            BeanInfo bi = Introspector.getBeanInfo(o.getClass());
            PropertyDescriptor[] pds = bi.getPropertyDescriptors();
            int i = 0;

            for(int len = pds.length; i < len; ++i) {
               PropertyDescriptor pd = pds[i];
               Class propCl = pd.getPropertyType();
               String propName = pd.getName();
               if (propCl == String.class) {
                  Method readMethod = pd.getReadMethod();
                  if (readMethod != null) {
                     Object propVal = readMethod.invoke(o, NOARGS);
                     String value = (String)propVal;
                     if ("user".equals(propName)) {
                        user = value;
                     } else if ("password".equals(propName)) {
                        password = value;
                     } else if ("overrideDefaultUser".equals(propName)) {
                        overrideDefaultUser = value;
                     } else if ("overrideDefaultPassword".equals(propName)) {
                        overrideDefaultPassword = value;
                     }
                  }
               }
            }

            if (overrideDefaultUser != null) {
               return new DbAuth(overrideDefaultUser, overrideDefaultPassword);
            } else if (user != null) {
               return new DbAuth(user, password);
            } else {
               return NULL_AUTH;
            }
         } catch (Exception var15) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, "An exception occurred while trying to extract the default authentification info from a bean.", var15);
            }

            throw SqlUtils.toSQLException(var15);
         }
      }
   }

   static void resetTxnState(Connection pCon, boolean forceIgnoreUnresolvedTransactions, boolean autoCommitOnClose, boolean txnKnownResolved) throws SQLException {
      if (!forceIgnoreUnresolvedTransactions && !pCon.getAutoCommit()) {
         if (!autoCommitOnClose && !txnKnownResolved) {
            pCon.rollback();
         }

         pCon.setAutoCommit(true);
      }

   }

   public static synchronized ConnectionTester defaultConnectionTester() {
      String dfltCxnTesterClassName = PoolConfig.defaultConnectionTesterClassName();
      if (connectionTesterClassName != null && connectionTesterClassName.equals(dfltCxnTesterClassName)) {
         return cachedTester;
      } else {
         try {
            cachedTester = (ConnectionTester)Class.forName(dfltCxnTesterClassName).newInstance();
            connectionTesterClassName = cachedTester.getClass().getName();
         } catch (Exception var2) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "Could not load ConnectionTester " + dfltCxnTesterClassName + ", using built in default.", var2);
            }

            cachedTester = C3P0Defaults.connectionTester();
            connectionTesterClassName = cachedTester.getClass().getName();
         }

         return cachedTester;
      }
   }

   public static boolean supportsMethod(Object target, String mname, Class[] argTypes) {
      try {
         return target.getClass().getMethod(mname, argTypes) != null;
      } catch (NoSuchMethodException var4) {
         return false;
      } catch (SecurityException var5) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "We were denied access in a check of whether " + target + " supports method " + mname + ". Prob means external clients have no access, returning false.", var5);
         }

         return false;
      }
   }

   public static String createUserOverridesAsString(Map userOverrides) throws IOException {
      StringBuffer sb = new StringBuffer();
      sb.append("HexAsciiSerializedMap");
      sb.append('[');
      sb.append(ByteUtils.toHexAscii(SerializableUtils.toByteArray(userOverrides)));
      sb.append(']');
      return sb.toString();
   }

   public static Map parseUserOverridesAsString(String userOverridesAsString) throws IOException, ClassNotFoundException {
      if (userOverridesAsString != null) {
         String hexAscii = userOverridesAsString.substring("HexAsciiSerializedMap".length() + 1, userOverridesAsString.length() - 1);
         byte[] serBytes = ByteUtils.fromHexAscii(hexAscii);
         return Collections.unmodifiableMap((Map)SerializableUtils.fromByteArray(serBytes));
      } else {
         return Collections.EMPTY_MAP;
      }
   }

   static {
      logger = MLog.getLogger(C3P0ImplUtils.class);
      NULL_AUTH = new DbAuth((String)null, (String)null);
      NOARGS = new Object[0];
      ID_TOKEN_COUNTER = new EqualityEncounterCounter();
      String vmid = MultiPropertiesConfig.readVmConfig().getProperty("com.mchange.v2.c3p0.VMID");
      if (vmid != null && !(vmid = vmid.trim()).equals("") && !vmid.equals("AUTO")) {
         if (vmid.equals("NONE")) {
            VMID_PFX = "";
         } else {
            VMID_PFX = vmid + "|";
         }
      } else {
         VMID_PFX = generateVmId() + '|';
      }

      connectionTesterClassName = null;
      cachedTester = null;
   }
}