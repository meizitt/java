package com.mchange.v2.log.log4j;

import com.mchange.v2.log.LogUtils;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.log.log4j.Log4jMLog.Log4jMLogger;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;

public final class Log4jMLog extends MLog {
   static final String CHECK_CLASS = "org.apache.log4j.Logger";
   MLogger global = null;

   public Log4jMLog() throws ClassNotFoundException {
      Class.forName("org.apache.log4j.Logger");
   }

   public MLogger getMLogger(String name) {
      Logger lg = Logger.getLogger(name);
      return new Log4jMLogger(lg);
   }

   public MLogger getMLogger(Class cl) {
      Logger lg = Logger.getLogger(cl);
      return new Log4jMLogger(lg);
   }

   public MLogger getMLogger() {
      Logger lg = Logger.getRootLogger();
      return new Log4jMLogger(lg);
   }

   private static String formatMessage(String rbname, String msg, Object[] params) {
      if (msg == null) {
         return params == null ? "" : LogUtils.createParamsList(params);
      } else {
         ResourceBundle rb = ResourceBundle.getBundle(rbname);
         if (rb != null) {
            String check = rb.getString(msg);
            if (check != null) {
               msg = check;
            }
         }

         return params == null ? msg : MessageFormat.format(msg, params);
      }
   }
}