package com.mchange.v2.c3p0.impl;

public interface IdentityTokenized {
   String getIdentityToken();

   void setIdentityToken(String var1);
}