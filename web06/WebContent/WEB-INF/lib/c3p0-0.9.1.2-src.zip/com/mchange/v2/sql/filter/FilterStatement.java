package com.mchange.v2.sql.filter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

public abstract class FilterStatement implements Statement {
   protected Statement inner;

   public FilterStatement(Statement inner) {
      this.inner = inner;
   }

   public FilterStatement() {
   }

   public void setInner(Statement inner) {
      this.inner = inner;
   }

   public Statement getInner() {
      return this.inner;
   }

   public SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public void setFetchDirection(int a) throws SQLException {
      this.inner.setFetchDirection(a);
   }

   public int getFetchDirection() throws SQLException {
      return this.inner.getFetchDirection();
   }

   public void setFetchSize(int a) throws SQLException {
      this.inner.setFetchSize(a);
   }

   public int getFetchSize() throws SQLException {
      return this.inner.getFetchSize();
   }

   public int getResultSetHoldability() throws SQLException {
      return this.inner.getResultSetHoldability();
   }

   public ResultSet executeQuery(String a) throws SQLException {
      return this.inner.executeQuery(a);
   }

   public int executeUpdate(String a, int b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a, String[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a, int[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a) throws SQLException {
      return this.inner.executeUpdate(a);
   }

   public int getMaxFieldSize() throws SQLException {
      return this.inner.getMaxFieldSize();
   }

   public void setMaxFieldSize(int a) throws SQLException {
      this.inner.setMaxFieldSize(a);
   }

   public int getMaxRows() throws SQLException {
      return this.inner.getMaxRows();
   }

   public void setMaxRows(int a) throws SQLException {
      this.inner.setMaxRows(a);
   }

   public void setEscapeProcessing(boolean a) throws SQLException {
      this.inner.setEscapeProcessing(a);
   }

   public int getQueryTimeout() throws SQLException {
      return this.inner.getQueryTimeout();
   }

   public void setQueryTimeout(int a) throws SQLException {
      this.inner.setQueryTimeout(a);
   }

   public void setCursorName(String a) throws SQLException {
      this.inner.setCursorName(a);
   }

   public ResultSet getResultSet() throws SQLException {
      return this.inner.getResultSet();
   }

   public int getUpdateCount() throws SQLException {
      return this.inner.getUpdateCount();
   }

   public boolean getMoreResults() throws SQLException {
      return this.inner.getMoreResults();
   }

   public boolean getMoreResults(int a) throws SQLException {
      return this.inner.getMoreResults(a);
   }

   public int getResultSetConcurrency() throws SQLException {
      return this.inner.getResultSetConcurrency();
   }

   public int getResultSetType() throws SQLException {
      return this.inner.getResultSetType();
   }

   public void addBatch(String a) throws SQLException {
      this.inner.addBatch(a);
   }

   public void clearBatch() throws SQLException {
      this.inner.clearBatch();
   }

   public int[] executeBatch() throws SQLException {
      return this.inner.executeBatch();
   }

   public ResultSet getGeneratedKeys() throws SQLException {
      return this.inner.getGeneratedKeys();
   }

   public void close() throws SQLException {
      this.inner.close();
   }

   public boolean execute(String a, int b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public boolean execute(String a) throws SQLException {
      return this.inner.execute(a);
   }

   public boolean execute(String a, int[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public boolean execute(String a, String[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public Connection getConnection() throws SQLException {
      return this.inner.getConnection();
   }

   public void cancel() throws SQLException {
      this.inner.cancel();
   }
}