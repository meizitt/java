package com.mchange.v2.c3p0.impl;

public abstract class AbstractIdentityTokenized implements IdentityTokenized {
   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else {
         return o instanceof IdentityTokenized ? this.getIdentityToken().equals(((IdentityTokenized)o).getIdentityToken()) : false;
      }
   }

   public int hashCode() {
      return ~this.getIdentityToken().hashCode();
   }
}