package com.mchange.v2.resourcepool;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;

final class ResourcePoolUtils {
   static final MLogger logger;

   static final ResourcePoolException convertThrowable(String msg, Throwable t) {
      if (logger.isLoggable(MLevel.FINE)) {
         logger.log(MLevel.FINE, "Converting throwable to ResourcePoolException...", t);
      }

      return t instanceof ResourcePoolException ? (ResourcePoolException)t : new ResourcePoolException(msg, t);
   }

   static final ResourcePoolException convertThrowable(Throwable t) {
      return convertThrowable("Ouch! " + t.toString(), t);
   }

   static {
      logger = MLog.getLogger(ResourcePoolUtils.class);
   }
}