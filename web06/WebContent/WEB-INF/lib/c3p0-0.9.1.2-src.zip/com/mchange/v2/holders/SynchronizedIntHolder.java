package com.mchange.v2.holders;

import com.mchange.v2.ser.UnsupportedVersionException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SynchronizedIntHolder implements ThreadSafeIntHolder, Serializable {
   transient int value;
   static final long serialVersionUID = 1L;
   private static final short VERSION = 1;

   public SynchronizedIntHolder(int value) {
      this.value = value;
   }

   public SynchronizedIntHolder() {
      this(0);
   }

   public synchronized int getValue() {
      return this.value;
   }

   public synchronized void setValue(int value) {
      this.value = value;
   }

   public synchronized void increment() {
      ++this.value;
   }

   public synchronized void decrement() {
      --this.value;
   }

   private void writeObject(ObjectOutputStream out) throws IOException {
      out.writeShort(1);
      out.writeInt(this.value);
   }

   private void readObject(ObjectInputStream in) throws IOException {
      short version = in.readShort();
      switch(version) {
      case 1:
         this.value = in.readInt();
         return;
      default:
         throw new UnsupportedVersionException(this, version);
      }
   }
}