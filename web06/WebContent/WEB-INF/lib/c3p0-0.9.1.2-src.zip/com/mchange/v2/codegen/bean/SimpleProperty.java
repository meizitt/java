package com.mchange.v2.codegen.bean;

public class SimpleProperty implements Property {
   int variable_modifiers;
   String name;
   String simpleTypeName;
   String defensiveCopyExpression;
   String defaultValueExpression;
   int getter_modifiers;
   int setter_modifiers;
   boolean is_read_only;
   boolean is_bound;
   boolean is_constrained;

   public int getVariableModifiers() {
      return this.variable_modifiers;
   }

   public String getName() {
      return this.name;
   }

   public String getSimpleTypeName() {
      return this.simpleTypeName;
   }

   public String getDefensiveCopyExpression() {
      return this.defensiveCopyExpression;
   }

   public String getDefaultValueExpression() {
      return this.defaultValueExpression;
   }

   public int getGetterModifiers() {
      return this.getter_modifiers;
   }

   public int getSetterModifiers() {
      return this.setter_modifiers;
   }

   public boolean isReadOnly() {
      return this.is_read_only;
   }

   public boolean isBound() {
      return this.is_bound;
   }

   public boolean isConstrained() {
      return this.is_constrained;
   }

   public SimpleProperty(int variable_modifiers, String name, String simpleTypeName, String defensiveCopyExpression, String defaultValueExpression, int getter_modifiers, int setter_modifiers, boolean is_read_only, boolean is_bound, boolean is_constrained) {
      this.variable_modifiers = variable_modifiers;
      this.name = name;
      this.simpleTypeName = simpleTypeName;
      this.defensiveCopyExpression = defensiveCopyExpression;
      this.defaultValueExpression = defaultValueExpression;
      this.getter_modifiers = getter_modifiers;
      this.setter_modifiers = setter_modifiers;
      this.is_read_only = is_read_only;
      this.is_bound = is_bound;
      this.is_constrained = is_constrained;
   }

   public SimpleProperty(String name, String simpleTypeName, String defensiveCopyExpression, String defaultValueExpression, boolean is_read_only, boolean is_bound, boolean is_constrained) {
      this(2, name, simpleTypeName, defensiveCopyExpression, defaultValueExpression, 1, 1, is_read_only, is_bound, is_constrained);
   }
}