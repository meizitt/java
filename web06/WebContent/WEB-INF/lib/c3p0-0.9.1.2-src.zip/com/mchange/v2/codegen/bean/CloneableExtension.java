package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.IndentedWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class CloneableExtension implements GeneratorExtension {
   boolean export_public;
   boolean exception_swallowing;
   String mLoggerName;

   public boolean isExportPublic() {
      return this.export_public;
   }

   public void setExportPublic(boolean export_public) {
      this.export_public = export_public;
   }

   public boolean isExceptionSwallowing() {
      return this.exception_swallowing;
   }

   public void setExceptionSwallowing(boolean exception_swallowing) {
      this.exception_swallowing = exception_swallowing;
   }

   public String getMLoggerName() {
      return this.mLoggerName;
   }

   public void setMLoggerName(String mLoggerName) {
      this.mLoggerName = mLoggerName;
   }

   public CloneableExtension(boolean export_public, boolean exception_swallowing) {
      this.mLoggerName = null;
      this.export_public = export_public;
      this.exception_swallowing = exception_swallowing;
   }

   public CloneableExtension() {
      this(true, false);
   }

   public Collection extraGeneralImports() {
      return (Collection)(this.mLoggerName == null ? Collections.EMPTY_SET : Arrays.asList("com.mchange.v2.log"));
   }

   public Collection extraSpecificImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraInterfaceNames() {
      Set set = new HashSet();
      set.add("Cloneable");
      return set;
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      if (this.export_public) {
         iw.print("public Object clone()");
         if (!this.exception_swallowing) {
            iw.println(" throws CloneNotSupportedException");
         } else {
            iw.println();
         }

         iw.println("{");
         iw.upIndent();
         if (this.exception_swallowing) {
            iw.println("try");
            iw.println("{");
            iw.upIndent();
         }

         iw.println("return super.clone();");
         if (this.exception_swallowing) {
            iw.downIndent();
            iw.println("}");
            iw.println("catch (CloneNotSupportedException e)");
            iw.println("{");
            iw.upIndent();
            if (this.mLoggerName == null) {
               iw.println("e.printStackTrace();");
            } else {
               iw.println("if ( " + this.mLoggerName + ".isLoggable( MLevel.FINE ) )");
               iw.upIndent();
               iw.println(this.mLoggerName + ".log( MLevel.FINE, \"Inconsistent clone() definitions between subclass and superclass! \", e );");
               iw.downIndent();
            }

            iw.println("throw new RuntimeException(\"Inconsistent clone() definitions between subclass and superclass! \" + e);");
            iw.downIndent();
            iw.println("}");
         }

         iw.downIndent();
         iw.println("}");
      }

   }
}