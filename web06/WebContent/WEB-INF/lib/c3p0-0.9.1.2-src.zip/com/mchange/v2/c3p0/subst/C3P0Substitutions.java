package com.mchange.v2.c3p0.subst;

public final class C3P0Substitutions {
   public static final String VERSION = "0.9.1.2";
   public static final String DEBUG = "true";
   public static final String TRACE = "10";
   public static final String TIMESTAMP = "21-May-2007 15:04:56";
}