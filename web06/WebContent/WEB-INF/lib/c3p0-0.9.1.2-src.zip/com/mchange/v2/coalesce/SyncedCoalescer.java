package com.mchange.v2.coalesce;

import java.util.Iterator;

class SyncedCoalescer implements Coalescer {
   Coalescer inner;

   public SyncedCoalescer(Coalescer inner) {
      this.inner = inner;
   }

   public synchronized Object coalesce(Object o) {
      return this.inner.coalesce(o);
   }

   public synchronized int countCoalesced() {
      return this.inner.countCoalesced();
   }

   public synchronized Iterator iterator() {
      return this.inner.iterator();
   }
}