package com.mchange.v2.naming;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.naming.ReferenceableUtils.1;
import com.mchange.v2.naming.ReferenceableUtils.ExtractRec;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import javax.naming.spi.ObjectFactory;

public final class ReferenceableUtils {
   static final MLogger logger;
   static final String REFADDR_VERSION = "version";
   static final String REFADDR_CLASSNAME = "classname";
   static final String REFADDR_FACTORY = "factory";
   static final String REFADDR_FACTORY_CLASS_LOCATION = "factoryClassLocation";
   static final String REFADDR_SIZE = "size";
   static final int CURRENT_REF_VERSION = 1;

   public static String literalNullToNull(String s) {
      return s != null && !"null".equals(s) ? s : null;
   }

   public static Object referenceToObject(Reference ref, Name name, Context nameCtx, Hashtable env) throws NamingException {
      try {
         String fClassName = ref.getFactoryClassName();
         String fClassLocation = ref.getFactoryClassLocation();
         Object cl;
         if (fClassLocation == null) {
            cl = ClassLoader.getSystemClassLoader();
         } else {
            URL u = new URL(fClassLocation);
            cl = new URLClassLoader(new URL[]{u}, ClassLoader.getSystemClassLoader());
         }

         Class fClass = Class.forName(fClassName, true, (ClassLoader)cl);
         ObjectFactory of = (ObjectFactory)fClass.newInstance();
         return of.getObjectInstance(ref, name, nameCtx, env);
      } catch (Exception var9) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "Could not resolve Reference to Object!", var9);
         }

         NamingException ne = new NamingException("Could not resolve Reference to Object!");
         ne.setRootCause(var9);
         throw ne;
      }
   }

   
   public static void appendToReference(Reference appendTo, Reference orig) throws NamingException {
      int len = orig.size();
      appendTo.add(new StringRefAddr("version", String.valueOf(1)));
      appendTo.add(new StringRefAddr("classname", orig.getClassName()));
      appendTo.add(new StringRefAddr("factory", orig.getFactoryClassName()));
      appendTo.add(new StringRefAddr("factoryClassLocation", orig.getFactoryClassLocation()));
      appendTo.add(new StringRefAddr("size", String.valueOf(len)));

      for(int i = 0; i < len; ++i) {
         appendTo.add(orig.get(i));
      }

   }

   
   public static ExtractRec extractNestedReference(Reference extractFrom, int index) throws NamingException {
      try {
         int version = Integer.parseInt((String)extractFrom.get(index++).getContent());
         if (version != 1) {
            throw new NamingException("Bad version of nested reference!!!");
         } else {
            String className = (String)extractFrom.get(index++).getContent();
            String factoryClassName = (String)extractFrom.get(index++).getContent();
            String factoryClassLocation = (String)extractFrom.get(index++).getContent();
            Reference outRef = new Reference(className, factoryClassName, factoryClassLocation);
            int size = Integer.parseInt((String)extractFrom.get(index++).getContent());

            for(int i = 0; i < size; ++i) {
               outRef.add(extractFrom.get(index++));
            }

            return new ExtractRec(outRef, index, (1)null);
         }
      } catch (NumberFormatException var9) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "Version or size nested reference was not a number!!!", var9);
         }

         throw new NamingException("Version or size nested reference was not a number!!!");
      }
   }

   static {
      logger = MLog.getLogger(ReferenceableUtils.class);
   }
}