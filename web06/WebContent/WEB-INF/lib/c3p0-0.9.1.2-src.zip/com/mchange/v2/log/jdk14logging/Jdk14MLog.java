package com.mchange.v2.log.jdk14logging;

import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.log.jdk14logging.Jdk14MLog.Jdk14MLogger;
import com.mchange.v2.util.DoubleWeakHashMap;
import java.util.Map;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public final class Jdk14MLog extends MLog {
   private static String[] UNKNOWN_ARRAY = new String[]{"UNKNOWN_CLASS", "UNKNOWN_METHOD"};
   private static final String CHECK_CLASS = "java.util.logging.Logger";
   private final Map namedLoggerMap = new DoubleWeakHashMap();
   MLogger global = null;

   public Jdk14MLog() throws ClassNotFoundException {
      Class.forName("java.util.logging.Logger");
   }

   public synchronized MLogger getMLogger(String name) {
      name = name.intern();
      MLogger out = (MLogger)this.namedLoggerMap.get(name);
      if (out == null) {
         Logger lg = Logger.getLogger(name);
         out = new Jdk14MLogger(lg);
         this.namedLoggerMap.put(name, out);
      }

      return (MLogger)out;
   }

   public synchronized MLogger getMLogger(Class cl) {
      return getLogger(cl.getName());
   }

   public synchronized MLogger getMLogger() {
      if (this.global == null) {
         this.global = new Jdk14MLogger(LogManager.getLogManager().getLogger("global"));
      }

      return this.global;
   }

   private static String[] findCallingClassAndMethod() {
      StackTraceElement[] ste = (new Throwable()).getStackTrace();
      int i = 0;

      for(int len = ste.length; i < len; ++i) {
         StackTraceElement check = ste[i];
         String cn = check.getClassName();
         if (cn != null && !cn.startsWith("com.mchange.v2.log.jdk14logging")) {
            return new String[]{check.getClassName(), check.getMethodName()};
         }
      }

      return UNKNOWN_ARRAY;
   }
}