package com.mchange.v2.sql.filter;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class FilterDatabaseMetaData implements DatabaseMetaData {
   protected DatabaseMetaData inner;

   public FilterDatabaseMetaData(DatabaseMetaData inner) {
      this.inner = inner;
   }

   public FilterDatabaseMetaData() {
   }

   public void setInner(DatabaseMetaData inner) {
      this.inner = inner;
   }

   public DatabaseMetaData getInner() {
      return this.inner;
   }

   public boolean allProceduresAreCallable() throws SQLException {
      return this.inner.allProceduresAreCallable();
   }

   public boolean allTablesAreSelectable() throws SQLException {
      return this.inner.allTablesAreSelectable();
   }

   public boolean nullsAreSortedHigh() throws SQLException {
      return this.inner.nullsAreSortedHigh();
   }

   public boolean nullsAreSortedLow() throws SQLException {
      return this.inner.nullsAreSortedLow();
   }

   public boolean nullsAreSortedAtStart() throws SQLException {
      return this.inner.nullsAreSortedAtStart();
   }

   public boolean nullsAreSortedAtEnd() throws SQLException {
      return this.inner.nullsAreSortedAtEnd();
   }

   public String getDatabaseProductName() throws SQLException {
      return this.inner.getDatabaseProductName();
   }

   public String getDatabaseProductVersion() throws SQLException {
      return this.inner.getDatabaseProductVersion();
   }

   public String getDriverName() throws SQLException {
      return this.inner.getDriverName();
   }

   public String getDriverVersion() throws SQLException {
      return this.inner.getDriverVersion();
   }

   public int getDriverMajorVersion() {
      return this.inner.getDriverMajorVersion();
   }

   public int getDriverMinorVersion() {
      return this.inner.getDriverMinorVersion();
   }

   public boolean usesLocalFiles() throws SQLException {
      return this.inner.usesLocalFiles();
   }

   public boolean usesLocalFilePerTable() throws SQLException {
      return this.inner.usesLocalFilePerTable();
   }

   public boolean supportsMixedCaseIdentifiers() throws SQLException {
      return this.inner.supportsMixedCaseIdentifiers();
   }

   public boolean storesUpperCaseIdentifiers() throws SQLException {
      return this.inner.storesUpperCaseIdentifiers();
   }

   public boolean storesLowerCaseIdentifiers() throws SQLException {
      return this.inner.storesLowerCaseIdentifiers();
   }

   public boolean storesMixedCaseIdentifiers() throws SQLException {
      return this.inner.storesMixedCaseIdentifiers();
   }

   public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException {
      return this.inner.supportsMixedCaseQuotedIdentifiers();
   }

   public boolean storesUpperCaseQuotedIdentifiers() throws SQLException {
      return this.inner.storesUpperCaseQuotedIdentifiers();
   }

   public boolean storesLowerCaseQuotedIdentifiers() throws SQLException {
      return this.inner.storesLowerCaseQuotedIdentifiers();
   }

   public boolean storesMixedCaseQuotedIdentifiers() throws SQLException {
      return this.inner.storesMixedCaseQuotedIdentifiers();
   }

   public String getIdentifierQuoteString() throws SQLException {
      return this.inner.getIdentifierQuoteString();
   }

   public String getSQLKeywords() throws SQLException {
      return this.inner.getSQLKeywords();
   }

   public String getNumericFunctions() throws SQLException {
      return this.inner.getNumericFunctions();
   }

   public String getStringFunctions() throws SQLException {
      return this.inner.getStringFunctions();
   }

   public String getSystemFunctions() throws SQLException {
      return this.inner.getSystemFunctions();
   }

   public String getTimeDateFunctions() throws SQLException {
      return this.inner.getTimeDateFunctions();
   }

   public String getSearchStringEscape() throws SQLException {
      return this.inner.getSearchStringEscape();
   }

   public String getExtraNameCharacters() throws SQLException {
      return this.inner.getExtraNameCharacters();
   }

   public boolean supportsAlterTableWithAddColumn() throws SQLException {
      return this.inner.supportsAlterTableWithAddColumn();
   }

   public boolean supportsAlterTableWithDropColumn() throws SQLException {
      return this.inner.supportsAlterTableWithDropColumn();
   }

   public boolean supportsColumnAliasing() throws SQLException {
      return this.inner.supportsColumnAliasing();
   }

   public boolean nullPlusNonNullIsNull() throws SQLException {
      return this.inner.nullPlusNonNullIsNull();
   }

   public boolean supportsConvert() throws SQLException {
      return this.inner.supportsConvert();
   }

   public boolean supportsConvert(int a, int b) throws SQLException {
      return this.inner.supportsConvert(a, b);
   }

   public boolean supportsTableCorrelationNames() throws SQLException {
      return this.inner.supportsTableCorrelationNames();
   }

   public boolean supportsDifferentTableCorrelationNames() throws SQLException {
      return this.inner.supportsDifferentTableCorrelationNames();
   }

   public boolean supportsExpressionsInOrderBy() throws SQLException {
      return this.inner.supportsExpressionsInOrderBy();
   }

   public boolean supportsOrderByUnrelated() throws SQLException {
      return this.inner.supportsOrderByUnrelated();
   }

   public boolean supportsGroupBy() throws SQLException {
      return this.inner.supportsGroupBy();
   }

   public boolean supportsGroupByUnrelated() throws SQLException {
      return this.inner.supportsGroupByUnrelated();
   }

   public boolean supportsGroupByBeyondSelect() throws SQLException {
      return this.inner.supportsGroupByBeyondSelect();
   }

   public boolean supportsLikeEscapeClause() throws SQLException {
      return this.inner.supportsLikeEscapeClause();
   }

   public boolean supportsMultipleResultSets() throws SQLException {
      return this.inner.supportsMultipleResultSets();
   }

   public boolean supportsMultipleTransactions() throws SQLException {
      return this.inner.supportsMultipleTransactions();
   }

   public boolean supportsNonNullableColumns() throws SQLException {
      return this.inner.supportsNonNullableColumns();
   }

   public boolean supportsMinimumSQLGrammar() throws SQLException {
      return this.inner.supportsMinimumSQLGrammar();
   }

   public boolean supportsCoreSQLGrammar() throws SQLException {
      return this.inner.supportsCoreSQLGrammar();
   }

   public boolean supportsExtendedSQLGrammar() throws SQLException {
      return this.inner.supportsExtendedSQLGrammar();
   }

   public boolean supportsANSI92EntryLevelSQL() throws SQLException {
      return this.inner.supportsANSI92EntryLevelSQL();
   }

   public boolean supportsANSI92IntermediateSQL() throws SQLException {
      return this.inner.supportsANSI92IntermediateSQL();
   }

   public boolean supportsANSI92FullSQL() throws SQLException {
      return this.inner.supportsANSI92FullSQL();
   }

   public boolean supportsIntegrityEnhancementFacility() throws SQLException {
      return this.inner.supportsIntegrityEnhancementFacility();
   }

   public boolean supportsOuterJoins() throws SQLException {
      return this.inner.supportsOuterJoins();
   }

   public boolean supportsFullOuterJoins() throws SQLException {
      return this.inner.supportsFullOuterJoins();
   }

   public boolean supportsLimitedOuterJoins() throws SQLException {
      return this.inner.supportsLimitedOuterJoins();
   }

   public String getSchemaTerm() throws SQLException {
      return this.inner.getSchemaTerm();
   }

   public String getProcedureTerm() throws SQLException {
      return this.inner.getProcedureTerm();
   }

   public String getCatalogTerm() throws SQLException {
      return this.inner.getCatalogTerm();
   }

   public boolean isCatalogAtStart() throws SQLException {
      return this.inner.isCatalogAtStart();
   }

   public String getCatalogSeparator() throws SQLException {
      return this.inner.getCatalogSeparator();
   }

   public boolean supportsSchemasInDataManipulation() throws SQLException {
      return this.inner.supportsSchemasInDataManipulation();
   }

   public boolean supportsSchemasInProcedureCalls() throws SQLException {
      return this.inner.supportsSchemasInProcedureCalls();
   }

   public boolean supportsSchemasInTableDefinitions() throws SQLException {
      return this.inner.supportsSchemasInTableDefinitions();
   }

   public boolean supportsSchemasInIndexDefinitions() throws SQLException {
      return this.inner.supportsSchemasInIndexDefinitions();
   }

   public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException {
      return this.inner.supportsSchemasInPrivilegeDefinitions();
   }

   public boolean supportsCatalogsInDataManipulation() throws SQLException {
      return this.inner.supportsCatalogsInDataManipulation();
   }

   public boolean supportsCatalogsInProcedureCalls() throws SQLException {
      return this.inner.supportsCatalogsInProcedureCalls();
   }

   public boolean supportsCatalogsInTableDefinitions() throws SQLException {
      return this.inner.supportsCatalogsInTableDefinitions();
   }

   public boolean supportsCatalogsInIndexDefinitions() throws SQLException {
      return this.inner.supportsCatalogsInIndexDefinitions();
   }

   public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException {
      return this.inner.supportsCatalogsInPrivilegeDefinitions();
   }

   public boolean supportsPositionedDelete() throws SQLException {
      return this.inner.supportsPositionedDelete();
   }

   public boolean supportsPositionedUpdate() throws SQLException {
      return this.inner.supportsPositionedUpdate();
   }

   public boolean supportsSelectForUpdate() throws SQLException {
      return this.inner.supportsSelectForUpdate();
   }

   public boolean supportsStoredProcedures() throws SQLException {
      return this.inner.supportsStoredProcedures();
   }

   public boolean supportsSubqueriesInComparisons() throws SQLException {
      return this.inner.supportsSubqueriesInComparisons();
   }

   public boolean supportsSubqueriesInExists() throws SQLException {
      return this.inner.supportsSubqueriesInExists();
   }

   public boolean supportsSubqueriesInIns() throws SQLException {
      return this.inner.supportsSubqueriesInIns();
   }

   public boolean supportsSubqueriesInQuantifieds() throws SQLException {
      return this.inner.supportsSubqueriesInQuantifieds();
   }

   public boolean supportsCorrelatedSubqueries() throws SQLException {
      return this.inner.supportsCorrelatedSubqueries();
   }

   public boolean supportsUnion() throws SQLException {
      return this.inner.supportsUnion();
   }

   public boolean supportsUnionAll() throws SQLException {
      return this.inner.supportsUnionAll();
   }

   public boolean supportsOpenCursorsAcrossCommit() throws SQLException {
      return this.inner.supportsOpenCursorsAcrossCommit();
   }

   public boolean supportsOpenCursorsAcrossRollback() throws SQLException {
      return this.inner.supportsOpenCursorsAcrossRollback();
   }

   public boolean supportsOpenStatementsAcrossCommit() throws SQLException {
      return this.inner.supportsOpenStatementsAcrossCommit();
   }

   public boolean supportsOpenStatementsAcrossRollback() throws SQLException {
      return this.inner.supportsOpenStatementsAcrossRollback();
   }

   public int getMaxBinaryLiteralLength() throws SQLException {
      return this.inner.getMaxBinaryLiteralLength();
   }

   public int getMaxCharLiteralLength() throws SQLException {
      return this.inner.getMaxCharLiteralLength();
   }

   public int getMaxColumnNameLength() throws SQLException {
      return this.inner.getMaxColumnNameLength();
   }

   public int getMaxColumnsInGroupBy() throws SQLException {
      return this.inner.getMaxColumnsInGroupBy();
   }

   public int getMaxColumnsInIndex() throws SQLException {
      return this.inner.getMaxColumnsInIndex();
   }

   public int getMaxColumnsInOrderBy() throws SQLException {
      return this.inner.getMaxColumnsInOrderBy();
   }

   public int getMaxColumnsInSelect() throws SQLException {
      return this.inner.getMaxColumnsInSelect();
   }

   public int getMaxColumnsInTable() throws SQLException {
      return this.inner.getMaxColumnsInTable();
   }

   public int getMaxConnections() throws SQLException {
      return this.inner.getMaxConnections();
   }

   public int getMaxCursorNameLength() throws SQLException {
      return this.inner.getMaxCursorNameLength();
   }

   public int getMaxIndexLength() throws SQLException {
      return this.inner.getMaxIndexLength();
   }

   public int getMaxSchemaNameLength() throws SQLException {
      return this.inner.getMaxSchemaNameLength();
   }

   public int getMaxProcedureNameLength() throws SQLException {
      return this.inner.getMaxProcedureNameLength();
   }

   public int getMaxCatalogNameLength() throws SQLException {
      return this.inner.getMaxCatalogNameLength();
   }

   public int getMaxRowSize() throws SQLException {
      return this.inner.getMaxRowSize();
   }

   public boolean doesMaxRowSizeIncludeBlobs() throws SQLException {
      return this.inner.doesMaxRowSizeIncludeBlobs();
   }

   public int getMaxStatementLength() throws SQLException {
      return this.inner.getMaxStatementLength();
   }

   public int getMaxStatements() throws SQLException {
      return this.inner.getMaxStatements();
   }

   public int getMaxTableNameLength() throws SQLException {
      return this.inner.getMaxTableNameLength();
   }

   public int getMaxTablesInSelect() throws SQLException {
      return this.inner.getMaxTablesInSelect();
   }

   public int getMaxUserNameLength() throws SQLException {
      return this.inner.getMaxUserNameLength();
   }

   public int getDefaultTransactionIsolation() throws SQLException {
      return this.inner.getDefaultTransactionIsolation();
   }

   public boolean supportsTransactions() throws SQLException {
      return this.inner.supportsTransactions();
   }

   public boolean supportsTransactionIsolationLevel(int a) throws SQLException {
      return this.inner.supportsTransactionIsolationLevel(a);
   }

   public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException {
      return this.inner.supportsDataDefinitionAndDataManipulationTransactions();
   }

   public boolean supportsDataManipulationTransactionsOnly() throws SQLException {
      return this.inner.supportsDataManipulationTransactionsOnly();
   }

   public boolean dataDefinitionCausesTransactionCommit() throws SQLException {
      return this.inner.dataDefinitionCausesTransactionCommit();
   }

   public boolean dataDefinitionIgnoredInTransactions() throws SQLException {
      return this.inner.dataDefinitionIgnoredInTransactions();
   }

   public ResultSet getProcedures(String a, String b, String c) throws SQLException {
      return this.inner.getProcedures(a, b, c);
   }

   public ResultSet getProcedureColumns(String a, String b, String c, String d) throws SQLException {
      return this.inner.getProcedureColumns(a, b, c, d);
   }

   public ResultSet getTables(String a, String b, String c, String[] d) throws SQLException {
      return this.inner.getTables(a, b, c, d);
   }

   public ResultSet getSchemas() throws SQLException {
      return this.inner.getSchemas();
   }

   public ResultSet getCatalogs() throws SQLException {
      return this.inner.getCatalogs();
   }

   public ResultSet getTableTypes() throws SQLException {
      return this.inner.getTableTypes();
   }

   public ResultSet getColumnPrivileges(String a, String b, String c, String d) throws SQLException {
      return this.inner.getColumnPrivileges(a, b, c, d);
   }

   public ResultSet getTablePrivileges(String a, String b, String c) throws SQLException {
      return this.inner.getTablePrivileges(a, b, c);
   }

   public ResultSet getBestRowIdentifier(String a, String b, String c, int d, boolean e) throws SQLException {
      return this.inner.getBestRowIdentifier(a, b, c, d, e);
   }

   public ResultSet getVersionColumns(String a, String b, String c) throws SQLException {
      return this.inner.getVersionColumns(a, b, c);
   }

   public ResultSet getPrimaryKeys(String a, String b, String c) throws SQLException {
      return this.inner.getPrimaryKeys(a, b, c);
   }

   public ResultSet getImportedKeys(String a, String b, String c) throws SQLException {
      return this.inner.getImportedKeys(a, b, c);
   }

   public ResultSet getExportedKeys(String a, String b, String c) throws SQLException {
      return this.inner.getExportedKeys(a, b, c);
   }

   public ResultSet getCrossReference(String a, String b, String c, String d, String e, String f) throws SQLException {
      return this.inner.getCrossReference(a, b, c, d, e, f);
   }

   public ResultSet getTypeInfo() throws SQLException {
      return this.inner.getTypeInfo();
   }

   public ResultSet getIndexInfo(String a, String b, String c, boolean d, boolean e) throws SQLException {
      return this.inner.getIndexInfo(a, b, c, d, e);
   }

   public boolean supportsResultSetType(int a) throws SQLException {
      return this.inner.supportsResultSetType(a);
   }

   public boolean supportsResultSetConcurrency(int a, int b) throws SQLException {
      return this.inner.supportsResultSetConcurrency(a, b);
   }

   public boolean ownUpdatesAreVisible(int a) throws SQLException {
      return this.inner.ownUpdatesAreVisible(a);
   }

   public boolean ownDeletesAreVisible(int a) throws SQLException {
      return this.inner.ownDeletesAreVisible(a);
   }

   public boolean ownInsertsAreVisible(int a) throws SQLException {
      return this.inner.ownInsertsAreVisible(a);
   }

   public boolean othersUpdatesAreVisible(int a) throws SQLException {
      return this.inner.othersUpdatesAreVisible(a);
   }

   public boolean othersDeletesAreVisible(int a) throws SQLException {
      return this.inner.othersDeletesAreVisible(a);
   }

   public boolean othersInsertsAreVisible(int a) throws SQLException {
      return this.inner.othersInsertsAreVisible(a);
   }

   public boolean updatesAreDetected(int a) throws SQLException {
      return this.inner.updatesAreDetected(a);
   }

   public boolean deletesAreDetected(int a) throws SQLException {
      return this.inner.deletesAreDetected(a);
   }

   public boolean insertsAreDetected(int a) throws SQLException {
      return this.inner.insertsAreDetected(a);
   }

   public boolean supportsBatchUpdates() throws SQLException {
      return this.inner.supportsBatchUpdates();
   }

   public ResultSet getUDTs(String a, String b, String c, int[] d) throws SQLException {
      return this.inner.getUDTs(a, b, c, d);
   }

   public boolean supportsSavepoints() throws SQLException {
      return this.inner.supportsSavepoints();
   }

   public boolean supportsNamedParameters() throws SQLException {
      return this.inner.supportsNamedParameters();
   }

   public boolean supportsMultipleOpenResults() throws SQLException {
      return this.inner.supportsMultipleOpenResults();
   }

   public boolean supportsGetGeneratedKeys() throws SQLException {
      return this.inner.supportsGetGeneratedKeys();
   }

   public ResultSet getSuperTypes(String a, String b, String c) throws SQLException {
      return this.inner.getSuperTypes(a, b, c);
   }

   public ResultSet getSuperTables(String a, String b, String c) throws SQLException {
      return this.inner.getSuperTables(a, b, c);
   }

   public boolean supportsResultSetHoldability(int a) throws SQLException {
      return this.inner.supportsResultSetHoldability(a);
   }

   public int getResultSetHoldability() throws SQLException {
      return this.inner.getResultSetHoldability();
   }

   public int getDatabaseMajorVersion() throws SQLException {
      return this.inner.getDatabaseMajorVersion();
   }

   public int getDatabaseMinorVersion() throws SQLException {
      return this.inner.getDatabaseMinorVersion();
   }

   public int getJDBCMajorVersion() throws SQLException {
      return this.inner.getJDBCMajorVersion();
   }

   public int getJDBCMinorVersion() throws SQLException {
      return this.inner.getJDBCMinorVersion();
   }

   public int getSQLStateType() throws SQLException {
      return this.inner.getSQLStateType();
   }

   public boolean locatorsUpdateCopy() throws SQLException {
      return this.inner.locatorsUpdateCopy();
   }

   public boolean supportsStatementPooling() throws SQLException {
      return this.inner.supportsStatementPooling();
   }

   public String getURL() throws SQLException {
      return this.inner.getURL();
   }

   public boolean isReadOnly() throws SQLException {
      return this.inner.isReadOnly();
   }

   public ResultSet getAttributes(String a, String b, String c, String d) throws SQLException {
      return this.inner.getAttributes(a, b, c, d);
   }

   public Connection getConnection() throws SQLException {
      return this.inner.getConnection();
   }

   public ResultSet getColumns(String a, String b, String c, String d) throws SQLException {
      return this.inner.getColumns(a, b, c, d);
   }

   public String getUserName() throws SQLException {
      return this.inner.getUserName();
   }
}