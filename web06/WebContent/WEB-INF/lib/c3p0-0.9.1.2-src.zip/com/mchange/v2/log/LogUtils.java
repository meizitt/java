package com.mchange.v2.log;

public final class LogUtils {
   public static String createParamsList(Object[] params) {
      StringBuffer sb = new StringBuffer(511);
      appendParamsList(sb, params);
      return sb.toString();
   }

   public static void appendParamsList(StringBuffer sb, Object[] params) {
      sb.append("[params: ");
      int i = 0;

      for(int len = params.length; i < len; ++i) {
         if (i != 0) {
            sb.append(", ");
         }

         sb.append(params[i]);
      }

      sb.append(']');
   }
}