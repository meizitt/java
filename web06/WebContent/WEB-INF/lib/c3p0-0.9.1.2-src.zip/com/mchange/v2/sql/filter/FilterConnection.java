package com.mchange.v2.sql.filter;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Map;

public abstract class FilterConnection implements Connection {
   protected Connection inner;

   public FilterConnection(Connection inner) {
      this.inner = inner;
   }

   public FilterConnection() {
   }

   public void setInner(Connection inner) {
      this.inner = inner;
   }

   public Connection getInner() {
      return this.inner;
   }

   public Statement createStatement(int a, int b, int c) throws SQLException {
      return this.inner.createStatement(a, b, c);
   }

   public Statement createStatement(int a, int b) throws SQLException {
      return this.inner.createStatement(a, b);
   }

   public Statement createStatement() throws SQLException {
      return this.inner.createStatement();
   }

   public PreparedStatement prepareStatement(String a, String[] b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public PreparedStatement prepareStatement(String a) throws SQLException {
      return this.inner.prepareStatement(a);
   }

   public PreparedStatement prepareStatement(String a, int b, int c) throws SQLException {
      return this.inner.prepareStatement(a, b, c);
   }

   public PreparedStatement prepareStatement(String a, int b, int c, int d) throws SQLException {
      return this.inner.prepareStatement(a, b, c, d);
   }

   public PreparedStatement prepareStatement(String a, int b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public PreparedStatement prepareStatement(String a, int[] b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public CallableStatement prepareCall(String a, int b, int c, int d) throws SQLException {
      return this.inner.prepareCall(a, b, c, d);
   }

   public CallableStatement prepareCall(String a, int b, int c) throws SQLException {
      return this.inner.prepareCall(a, b, c);
   }

   public CallableStatement prepareCall(String a) throws SQLException {
      return this.inner.prepareCall(a);
   }

   public String nativeSQL(String a) throws SQLException {
      return this.inner.nativeSQL(a);
   }

   public void setAutoCommit(boolean a) throws SQLException {
      this.inner.setAutoCommit(a);
   }

   public boolean getAutoCommit() throws SQLException {
      return this.inner.getAutoCommit();
   }

   public void commit() throws SQLException {
      this.inner.commit();
   }

   public void rollback(Savepoint a) throws SQLException {
      this.inner.rollback(a);
   }

   public void rollback() throws SQLException {
      this.inner.rollback();
   }

   public DatabaseMetaData getMetaData() throws SQLException {
      return this.inner.getMetaData();
   }

   public void setCatalog(String a) throws SQLException {
      this.inner.setCatalog(a);
   }

   public String getCatalog() throws SQLException {
      return this.inner.getCatalog();
   }

   public void setTransactionIsolation(int a) throws SQLException {
      this.inner.setTransactionIsolation(a);
   }

   public int getTransactionIsolation() throws SQLException {
      return this.inner.getTransactionIsolation();
   }

   public SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public Map getTypeMap() throws SQLException {
      return this.inner.getTypeMap();
   }

   public void setTypeMap(Map a) throws SQLException {
      this.inner.setTypeMap(a);
   }

   public void setHoldability(int a) throws SQLException {
      this.inner.setHoldability(a);
   }

   public int getHoldability() throws SQLException {
      return this.inner.getHoldability();
   }

   public Savepoint setSavepoint() throws SQLException {
      return this.inner.setSavepoint();
   }

   public Savepoint setSavepoint(String a) throws SQLException {
      return this.inner.setSavepoint(a);
   }

   public void releaseSavepoint(Savepoint a) throws SQLException {
      this.inner.releaseSavepoint(a);
   }

   public void setReadOnly(boolean a) throws SQLException {
      this.inner.setReadOnly(a);
   }

   public boolean isReadOnly() throws SQLException {
      return this.inner.isReadOnly();
   }

   public void close() throws SQLException {
      this.inner.close();
   }

   public boolean isClosed() throws SQLException {
      return this.inner.isClosed();
   }
}