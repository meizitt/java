package com.mchange.v2.c3p0;

import java.io.Serializable;
import java.sql.Connection;

public interface ConnectionTester extends Serializable {
   int CONNECTION_IS_OKAY = 0;
   int CONNECTION_IS_INVALID = -1;
   int DATABASE_IS_INVALID = -8;

   int activeCheckConnection(Connection var1);

   int statusOnException(Connection var1, Throwable var2);

   boolean equals(Object var1);

   int hashCode();
}