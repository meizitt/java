package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.IndentedWriter;
import com.mchange.v2.naming.JavaBeanObjectFactory;
import com.mchange.v2.naming.JavaBeanReferenceMaker;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class PropertyReferenceableExtension implements GeneratorExtension {
   boolean explicit_reference_properties = false;
   String factoryClassName;
   String javaBeanReferenceMakerClassName;

   public PropertyReferenceableExtension() {
      this.factoryClassName = JavaBeanObjectFactory.class.getName();
      this.javaBeanReferenceMakerClassName = JavaBeanReferenceMaker.class.getName();
   }

   public void setUseExplicitReferenceProperties(boolean explicit_reference_properties) {
      this.explicit_reference_properties = explicit_reference_properties;
   }

   public boolean getUseExplicitReferenceProperties() {
      return this.explicit_reference_properties;
   }

   public void setFactoryClassName(String factoryClassName) {
      this.factoryClassName = factoryClassName;
   }

   public String getFactoryClassName() {
      return this.factoryClassName;
   }

   public Collection extraGeneralImports() {
      Set set = new HashSet();
      return set;
   }

   public Collection extraSpecificImports() {
      Set set = new HashSet();
      set.add("javax.naming.Reference");
      set.add("javax.naming.Referenceable");
      set.add("javax.naming.NamingException");
      set.add("com.mchange.v2.naming.JavaBeanObjectFactory");
      set.add("com.mchange.v2.naming.JavaBeanReferenceMaker");
      set.add("com.mchange.v2.naming.ReferenceMaker");
      return set;
   }

   public Collection extraInterfaceNames() {
      Set set = new HashSet();
      set.add("Referenceable");
      return set;
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      iw.println("final static JavaBeanReferenceMaker referenceMaker = new " + this.javaBeanReferenceMakerClassName + "();");
      iw.println();
      iw.println("static");
      iw.println("{");
      iw.upIndent();
      iw.println("referenceMaker.setFactoryClassName( \"" + this.factoryClassName + "\" );");
      if (this.explicit_reference_properties) {
         int i = 0;

         for(int len = props.length; i < len; ++i) {
            iw.println("referenceMaker.addReferenceProperty(\"" + props[i].getName() + "\");");
         }
      }

      iw.downIndent();
      iw.println("}");
      iw.println();
      iw.println("public Reference getReference() throws NamingException");
      iw.println("{");
      iw.upIndent();
      iw.println("return referenceMaker.createReference( this );");
      iw.downIndent();
      iw.println("}");
   }
}