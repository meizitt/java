package com.mchange.v2.naming;

import com.mchange.v2.beans.BeansUtils;
import com.mchange.v2.lang.Coerce;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.ser.SerializableUtils;
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.naming.BinaryRefAddr;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.StringRefAddr;
import javax.naming.spi.ObjectFactory;

public class JavaBeanObjectFactory implements ObjectFactory {
   private static final MLogger logger;
   static final Object NULL_TOKEN;

   public Object getObjectInstance(Object refObj, Name name, Context nameCtx, Hashtable env) throws Exception {
      if (!(refObj instanceof Reference)) {
         return null;
      } else {
         Reference ref = (Reference)refObj;
         Map refAddrsMap = new HashMap();
         Enumeration e = ref.getAll();

         while(e.hasMoreElements()) {
            RefAddr addr = (RefAddr)e.nextElement();
            refAddrsMap.put(addr.getType(), addr);
         }

         Class beanClass = Class.forName(ref.getClassName());
         Set refProps = null;
         RefAddr refPropsRefAddr = (BinaryRefAddr)refAddrsMap.remove("com.mchange.v2.naming.JavaBeanReferenceMaker.REF_PROPS_KEY");
         if (refPropsRefAddr != null) {
            refProps = (Set)SerializableUtils.fromByteArray((byte[])((byte[])refPropsRefAddr.getContent()));
         }

         Map propMap = this.createPropertyMap(beanClass, refAddrsMap);
         return this.findBean(beanClass, propMap, refProps);
      }
   }

   private Map createPropertyMap(Class beanClass, Map refAddrsMap) throws Exception {
      BeanInfo bi = Introspector.getBeanInfo(beanClass);
      PropertyDescriptor[] pds = bi.getPropertyDescriptors();
      Map out = new HashMap();
      int i = 0;

      for(int len = pds.length; i < len; ++i) {
         PropertyDescriptor pd = pds[i];
         String propertyName = pd.getName();
         Class propertyType = pd.getPropertyType();
         Object addr = refAddrsMap.remove(propertyName);
         if (addr != null) {
            if (addr instanceof StringRefAddr) {
               String content = (String)((StringRefAddr)addr).getContent();
               if (Coerce.canCoerce(propertyType)) {
                  out.put(propertyName, Coerce.toObject(content, propertyType));
               } else {
                  PropertyEditor pe = BeansUtils.findPropertyEditor(pd);
                  pe.setAsText(content);
                  out.put(propertyName, pe.getValue());
               }
            } else if (addr instanceof BinaryRefAddr) {
               byte[] content = (byte[])((byte[])((BinaryRefAddr)addr).getContent());
               if (content.length == 0) {
                  out.put(propertyName, NULL_TOKEN);
               } else {
                  out.put(propertyName, SerializableUtils.fromByteArray(content));
               }
            } else if (logger.isLoggable(MLevel.WARNING)) {
               logger.warning(this.getClass().getName() + " -- unknown RefAddr subclass: " + addr.getClass().getName());
            }
         }
      }

      Iterator ii = refAddrsMap.keySet().iterator();

      while(ii.hasNext()) {
         String type = (String)ii.next();
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.warning(this.getClass().getName() + " -- RefAddr for unknown property: " + type);
         }
      }

      return out;
   }

   protected Object createBlankInstance(Class beanClass) throws Exception {
      return beanClass.newInstance();
   }

   protected Object findBean(Class beanClass, Map propertyMap, Set refProps) throws Exception {
      Object bean = this.createBlankInstance(beanClass);
      BeanInfo bi = Introspector.getBeanInfo(bean.getClass());
      PropertyDescriptor[] pds = bi.getPropertyDescriptors();
      int i = 0;

      for(int len = pds.length; i < len; ++i) {
         PropertyDescriptor pd = pds[i];
         String propertyName = pd.getName();
         Object value = propertyMap.get(propertyName);
         Method setter = pd.getWriteMethod();
         if (value != null) {
            if (setter != null) {
               setter.invoke(bean, value == NULL_TOKEN ? null : value);
            } else if (logger.isLoggable(MLevel.WARNING)) {
               logger.warning(this.getClass().getName() + ": Could not restore read-only property '" + propertyName + "'.");
            }
         } else if (setter != null && (refProps == null || refProps.contains(propertyName)) && logger.isLoggable(MLevel.WARNING)) {
            logger.warning(this.getClass().getName() + " -- Expected writable property ''" + propertyName + "'' left at default value");
         }
      }

      return bean;
   }

   static {
      logger = MLog.getLogger(JavaBeanObjectFactory.class);
      NULL_TOKEN = new Object();
   }
}