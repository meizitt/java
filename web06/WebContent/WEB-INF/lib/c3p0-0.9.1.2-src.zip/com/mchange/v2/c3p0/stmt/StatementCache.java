package com.mchange.v2.c3p0.stmt;

import com.mchange.v1.util.ClosableResource;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;

public interface StatementCache extends ClosableResource {
   Object checkoutStatement(Connection var1, Method var2, Object[] var3) throws SQLException;

   void checkinStatement(Object var1) throws SQLException;

   void checkinAll(Connection var1) throws SQLException;

   void closeAll(Connection var1) throws SQLException;

   void close() throws SQLException;
}