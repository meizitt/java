package com.mchange.v2.c3p0.management;

import java.sql.SQLException;
import java.util.Collection;

public interface PooledDataSourceManagerMBean {
   String getIdentityToken();

   String getDataSourceName();

   void setDataSourceName(String var1);

   int getNumConnectionsDefaultUser() throws SQLException;

   int getNumIdleConnectionsDefaultUser() throws SQLException;

   int getNumBusyConnectionsDefaultUser() throws SQLException;

   int getNumUnclosedOrphanedConnectionsDefaultUser() throws SQLException;

   float getEffectivePropertyCycleDefaultUser() throws SQLException;

   void softResetDefaultUser() throws SQLException;

   int getNumConnections(String var1, String var2) throws SQLException;

   int getNumIdleConnections(String var1, String var2) throws SQLException;

   int getNumBusyConnections(String var1, String var2) throws SQLException;

   int getNumUnclosedOrphanedConnections(String var1, String var2) throws SQLException;

   float getEffectivePropertyCycle(String var1, String var2) throws SQLException;

   void softReset(String var1, String var2) throws SQLException;

   int getNumBusyConnectionsAllUsers() throws SQLException;

   int getNumIdleConnectionsAllUsers() throws SQLException;

   int getNumConnectionsAllUsers() throws SQLException;

   int getNumUnclosedOrphanedConnectionsAllUsers() throws SQLException;

   int getThreadPoolSize() throws SQLException;

   int getThreadPoolNumActiveThreads() throws SQLException;

   int getThreadPoolNumIdleThreads() throws SQLException;

   int getThreadPoolNumTasksPending() throws SQLException;

   String sampleThreadPoolStackTraces() throws SQLException;

   String sampleThreadPoolStatus() throws SQLException;

   void softResetAllUsers() throws SQLException;

   int getNumUserPools() throws SQLException;

   Collection getAllUsers() throws SQLException;

   void hardReset() throws SQLException;

   void close() throws SQLException;
}