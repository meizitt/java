package com.mchange.v2.debug;

final class Debug implements DebugConstants {
   static final boolean DEBUG = true;
   static final int TRACE = 10;
}