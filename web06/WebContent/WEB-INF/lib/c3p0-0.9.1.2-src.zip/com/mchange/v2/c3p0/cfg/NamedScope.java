package com.mchange.v2.c3p0.cfg;

import java.util.HashMap;

class NamedScope {
   HashMap props;
   HashMap userNamesToOverrides;

   NamedScope() {
      this.props = new HashMap();
      this.userNamesToOverrides = new HashMap();
   }

   NamedScope(HashMap props, HashMap userNamesToOverrides) {
      this.props = props;
      this.userNamesToOverrides = userNamesToOverrides;
   }
}