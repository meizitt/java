package com.mchange.v2.c3p0.impl;

import com.mchange.v1.db.sql.ResultSetUtils;
import com.mchange.v1.db.sql.StatementUtils;
import com.mchange.v2.c3p0.AbstractConnectionTester;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class DefaultConnectionTester extends AbstractConnectionTester {
   static final MLogger logger;
   static final int HASH_CODE;
   static final Set INVALID_DB_STATES;

   public int activeCheckConnection(Connection c, String query, Throwable[] rootCauseOutParamHolder) {
      if (query == null) {
         return this.activeCheckConnectionNoQuery(c, rootCauseOutParamHolder);
      } else {
         Statement stmt = null;
         ResultSet rs = null;

         try {
            try {
               stmt = c.createStatement();
               rs = stmt.executeQuery(query);
               byte var6 = 0;
               return var6;
            } catch (SQLException var13) {
               if (logger.isLoggable(MLevel.FINE)) {
                  logger.log(MLevel.FINE, "Connection " + c + " failed Connection test with an Exception! [query=" + query + "]", var13);
               }
            } catch (Exception var14) {
               if (logger.isLoggable(MLevel.FINE)) {
                  logger.log(MLevel.FINE, "Connection " + c + " failed Connection test with an Exception!", var14);
               }

               if (rootCauseOutParamHolder != null) {
                  rootCauseOutParamHolder[0] = var14;
               }

               byte var7 = -1;
               return var7;
            }

            if (rootCauseOutParamHolder != null) {
               rootCauseOutParamHolder[0] = var13;
            }

            String state = var13.getSQLState();
            byte var8;
            if (INVALID_DB_STATES.contains(state)) {
               if (logger.isLoggable(MLevel.WARNING)) {
                  logger.log(MLevel.WARNING, "SQL State '" + state + "' of Exception which occurred during a Connection test (test with query '" + query + "') implies that the database is invalid, " + "and the pool should refill itself with fresh Connections.", var13);
               }

               var8 = -8;
               return var8;
            } else {
               var8 = -1;
               return var8;
            }
         } finally {
            ResultSetUtils.attemptClose(rs);
            StatementUtils.attemptClose(stmt);
         }
      }
   }

   public int statusOnException(Connection c, Throwable t, String query, Throwable[] rootCauseOutParamHolder) {
      if (logger.isLoggable(MLevel.FINER)) {
         logger.log(MLevel.FINER, "Testing a Connection in response to an Exception:", t);
      }

      try {
         byte var6;
         try {
            if (t instanceof SQLException) {
               String state = ((SQLException)t).getSQLState();
               if (INVALID_DB_STATES.contains(state)) {
                  if (logger.isLoggable(MLevel.WARNING)) {
                     logger.log(MLevel.WARNING, "SQL State '" + state + "' of Exception tested by statusOnException() implies that the database is invalid, " + "and the pool should refill itself with fresh Connections.", t);
                  }

                  var6 = -8;
                  return var6;
               } else {
                  int var13 = this.activeCheckConnection(c, query, rootCauseOutParamHolder);
                  return var13;
               }
            } else {
               if (logger.isLoggable(MLevel.FINE)) {
                  logger.log(MLevel.FINE, "Connection test failed because test-provoking Throwable is an unexpected, non-SQLException.", t);
               }

               if (rootCauseOutParamHolder != null) {
                  rootCauseOutParamHolder[0] = t;
               }

               byte var5 = -1;
               return var5;
            }
         } catch (Exception var10) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, "Connection " + c + " failed Connection test with an Exception!", var10);
            }

            if (rootCauseOutParamHolder != null) {
               rootCauseOutParamHolder[0] = var10;
            }

            var6 = -1;
            return var6;
         }
      } finally {
         ;
      }
   }

   private static String queryInfo(String query) {
      return query == null ? "[using default system-table query]" : "[query=" + query + "]";
   }

   private int activeCheckConnectionNoQuery(Connection c, Throwable[] rootCauseOutParamHolder) {
      ResultSet rs = null;

      byte var6;
      try {
         try {
            rs = c.getMetaData().getTables((String)null, (String)null, "PROBABLYNOT", new String[]{"TABLE"});
            byte var4 = 0;
            return var4;
         } catch (SQLException var11) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, "Connection " + c + " failed default system-table Connection test with an Exception!", var11);
            }
         } catch (Exception var12) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, "Connection " + c + " failed default system-table Connection test with an Exception!", var12);
            }

            if (rootCauseOutParamHolder != null) {
               rootCauseOutParamHolder[0] = var12;
            }

            byte var5 = -1;
            return var5;
         }

         if (rootCauseOutParamHolder != null) {
            rootCauseOutParamHolder[0] = var11;
         }

         String state = var11.getSQLState();
         if (INVALID_DB_STATES.contains(state)) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "SQL State '" + state + "' of Exception which occurred during a Connection test (fallback DatabaseMetaData test) implies that the database is invalid, " + "and the pool should refill itself with fresh Connections.", var11);
            }

            var6 = -8;
            return var6;
         }

         var6 = -1;
      } finally {
         ResultSetUtils.attemptClose(rs);
      }

      return var6;
   }

   public boolean equals(Object o) {
      return o != null && o.getClass() == DefaultConnectionTester.class;
   }

   public int hashCode() {
      return HASH_CODE;
   }

   static {
      logger = MLog.getLogger(DefaultConnectionTester.class);
      HASH_CODE = DefaultConnectionTester.class.getName().hashCode();
      Set temp = new HashSet();
      temp.add("08001");
      temp.add("08007");
      INVALID_DB_STATES = Collections.unmodifiableSet(temp);
   }
}