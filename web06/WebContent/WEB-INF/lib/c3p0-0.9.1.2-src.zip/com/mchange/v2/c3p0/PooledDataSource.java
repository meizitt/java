package com.mchange.v2.c3p0;

import java.sql.SQLException;
import java.util.Collection;
import javax.sql.DataSource;

public interface PooledDataSource extends DataSource {
   String getIdentityToken();

   String getDataSourceName();

   void setDataSourceName(String var1);

   
   int getNumConnections() throws SQLException;

   
   int getNumIdleConnections() throws SQLException;

   
   int getNumBusyConnections() throws SQLException;

   
   int getNumUnclosedOrphanedConnections() throws SQLException;

   int getNumConnectionsDefaultUser() throws SQLException;

   int getNumIdleConnectionsDefaultUser() throws SQLException;

   int getNumBusyConnectionsDefaultUser() throws SQLException;

   int getNumUnclosedOrphanedConnectionsDefaultUser() throws SQLException;

   int getStatementCacheNumStatementsDefaultUser() throws SQLException;

   int getStatementCacheNumCheckedOutDefaultUser() throws SQLException;

   int getStatementCacheNumConnectionsWithCachedStatementsDefaultUser() throws SQLException;

   long getStartTimeMillisDefaultUser() throws SQLException;

   long getUpTimeMillisDefaultUser() throws SQLException;

   long getNumFailedCheckinsDefaultUser() throws SQLException;

   long getNumFailedCheckoutsDefaultUser() throws SQLException;

   long getNumFailedIdleTestsDefaultUser() throws SQLException;

   float getEffectivePropertyCycleDefaultUser() throws SQLException;

   int getNumThreadsAwaitingCheckoutDefaultUser() throws SQLException;

   void softResetDefaultUser() throws SQLException;

   int getNumConnections(String var1, String var2) throws SQLException;

   int getNumIdleConnections(String var1, String var2) throws SQLException;

   int getNumBusyConnections(String var1, String var2) throws SQLException;

   int getNumUnclosedOrphanedConnections(String var1, String var2) throws SQLException;

   int getStatementCacheNumStatements(String var1, String var2) throws SQLException;

   int getStatementCacheNumCheckedOut(String var1, String var2) throws SQLException;

   int getStatementCacheNumConnectionsWithCachedStatements(String var1, String var2) throws SQLException;

   float getEffectivePropertyCycle(String var1, String var2) throws SQLException;

   int getNumThreadsAwaitingCheckout(String var1, String var2) throws SQLException;

   void softReset(String var1, String var2) throws SQLException;

   int getNumBusyConnectionsAllUsers() throws SQLException;

   int getNumIdleConnectionsAllUsers() throws SQLException;

   int getNumConnectionsAllUsers() throws SQLException;

   int getNumUnclosedOrphanedConnectionsAllUsers() throws SQLException;

   int getStatementCacheNumStatementsAllUsers() throws SQLException;

   int getStatementCacheNumCheckedOutStatementsAllUsers() throws SQLException;

   int getStatementCacheNumConnectionsWithCachedStatementsAllUsers() throws SQLException;

   int getThreadPoolSize() throws SQLException;

   int getThreadPoolNumActiveThreads() throws SQLException;

   int getThreadPoolNumIdleThreads() throws SQLException;

   int getThreadPoolNumTasksPending() throws SQLException;

   String sampleThreadPoolStackTraces() throws SQLException;

   String sampleThreadPoolStatus() throws SQLException;

   String sampleStatementCacheStatusDefaultUser() throws SQLException;

   String sampleStatementCacheStatus(String var1, String var2) throws SQLException;

   Throwable getLastAcquisitionFailureDefaultUser() throws SQLException;

   Throwable getLastCheckinFailureDefaultUser() throws SQLException;

   Throwable getLastCheckoutFailureDefaultUser() throws SQLException;

   Throwable getLastIdleTestFailureDefaultUser() throws SQLException;

   Throwable getLastConnectionTestFailureDefaultUser() throws SQLException;

   Throwable getLastAcquisitionFailure(String var1, String var2) throws SQLException;

   Throwable getLastCheckinFailure(String var1, String var2) throws SQLException;

   Throwable getLastCheckoutFailure(String var1, String var2) throws SQLException;

   Throwable getLastIdleTestFailure(String var1, String var2) throws SQLException;

   Throwable getLastConnectionTestFailure(String var1, String var2) throws SQLException;

   String sampleLastAcquisitionFailureStackTraceDefaultUser() throws SQLException;

   String sampleLastCheckinFailureStackTraceDefaultUser() throws SQLException;

   String sampleLastCheckoutFailureStackTraceDefaultUser() throws SQLException;

   String sampleLastIdleTestFailureStackTraceDefaultUser() throws SQLException;

   String sampleLastConnectionTestFailureStackTraceDefaultUser() throws SQLException;

   String sampleLastAcquisitionFailureStackTrace(String var1, String var2) throws SQLException;

   String sampleLastCheckinFailureStackTrace(String var1, String var2) throws SQLException;

   String sampleLastCheckoutFailureStackTrace(String var1, String var2) throws SQLException;

   String sampleLastIdleTestFailureStackTrace(String var1, String var2) throws SQLException;

   String sampleLastConnectionTestFailureStackTrace(String var1, String var2) throws SQLException;

   void softResetAllUsers() throws SQLException;

   int getNumUserPools() throws SQLException;

   int getNumHelperThreads() throws SQLException;

   Collection getAllUsers() throws SQLException;

   void hardReset() throws SQLException;

   void close() throws SQLException;

   
   void close(boolean var1) throws SQLException;
}