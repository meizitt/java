package com.mchange.v2.c3p0.stmt;

import com.mchange.v2.async.AsynchronousRunner;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.ConnectionStatementManager;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.Deathmarch;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.SimpleConnectionStatementManager;
import java.sql.Connection;

public final class GlobalMaxOnlyStatementCache extends GooGooStatementCache {
   int max_statements;
   Deathmarch globalDeathmarch = new Deathmarch(this);

   public GlobalMaxOnlyStatementCache(AsynchronousRunner blockingTaskAsyncRunner, int max_statements) {
      super(blockingTaskAsyncRunner);
      this.max_statements = max_statements;
   }

   protected ConnectionStatementManager createConnectionStatementManager() {
      return new SimpleConnectionStatementManager();
   }

   void addStatementToDeathmarches(Object pstmt, Connection physicalConnection) {
      this.globalDeathmarch.deathmarchStatement(pstmt);
   }

   void removeStatementFromDeathmarches(Object pstmt, Connection physicalConnection) {
      this.globalDeathmarch.undeathmarchStatement(pstmt);
   }

   boolean prepareAssimilateNewStatement(Connection pcon) {
      int global_size = this.countCachedStatements();
      return global_size < this.max_statements || global_size == this.max_statements && this.globalDeathmarch.cullNext();
   }
}