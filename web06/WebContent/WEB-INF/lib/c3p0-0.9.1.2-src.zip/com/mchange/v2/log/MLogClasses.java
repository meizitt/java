package com.mchange.v2.log;

public final class MLogClasses {
   public static final String[] CLASSNAMES = new String[]{"com.mchange.v2.log.jdk14logging.Jdk14MLog", "com.mchange.v2.log.FallbackMLog"};
}