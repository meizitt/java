package com.mchange.v2.codegen;

import java.io.Writer;


public class IndentedWriter extends com.mchange.v2.io.IndentedWriter {
   public IndentedWriter(Writer out) {
      super(out);
   }
}