package com.mchange.v2.coalesce;

public final class CoalescerFactory {
   public static Coalescer createCoalescer() {
      return createCoalescer(true, true);
   }

   public static Coalescer createCoalescer(boolean weak, boolean synced) {
      return createCoalescer((CoalesceChecker)null, weak, synced);
   }

   public static Coalescer createCoalescer(CoalesceChecker cc, boolean weak, boolean synced) {
      Object out;
      if (cc == null) {
         out = weak ? new WeakEqualsCoalescer() : new StrongEqualsCoalescer();
      } else {
         out = weak ? new WeakCcCoalescer(cc) : new StrongCcCoalescer(cc);
      }

      return (Coalescer)(synced ? new SyncedCoalescer((Coalescer)out) : out);
   }
}