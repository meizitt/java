package com.mchange.v2.beans;

public interface StateBean {
}