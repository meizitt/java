package com.mchange.v2.beans;

public interface StateBeanExporter {
   StateBean exportStateBean();
}