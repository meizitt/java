package com.mchange.v2.codegen.intfc;

import com.mchange.v1.lang.ClassUtils;
import com.mchange.v2.codegen.CodegenUtils;
import com.mchange.v2.codegen.IndentedWriter;
import com.mchange.v2.codegen.intfc.DelegatorGenerator.1;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class DelegatorGenerator {
   int class_modifiers = 1025;
   int method_modifiers = 1;
   int wrapping_ctor_modifiers = 1;
   int default_ctor_modifiers = 1;
   boolean wrapping_constructor = true;
   boolean default_constructor = true;
   boolean inner_getter = true;
   boolean inner_setter = true;
   Class superclass = null;
   Class[] extraInterfaces = null;
   static final Comparator classComp = new 1();

   public void setGenerateInnerSetter(boolean b) {
      this.inner_setter = b;
   }

   public boolean isGenerateInnerSetter() {
      return this.inner_setter;
   }

   public void setGenerateInnerGetter(boolean b) {
      this.inner_getter = b;
   }

   public boolean isGenerateInnerGetter() {
      return this.inner_getter;
   }

   public void setGenerateNoArgConstructor(boolean b) {
      this.default_constructor = b;
   }

   public boolean isGenerateNoArgConstructor() {
      return this.default_constructor;
   }

   public void setGenerateWrappingConstructor(boolean b) {
      this.wrapping_constructor = b;
   }

   public boolean isGenerateWrappingConstructor() {
      return this.wrapping_constructor;
   }

   public void setWrappingConstructorModifiers(int modifiers) {
      this.wrapping_ctor_modifiers = modifiers;
   }

   public int getWrappingConstructorModifiers() {
      return this.wrapping_ctor_modifiers;
   }

   public void setNoArgConstructorModifiers(int modifiers) {
      this.default_ctor_modifiers = modifiers;
   }

   public int getNoArgConstructorModifiers() {
      return this.default_ctor_modifiers;
   }

   public void setMethodModifiers(int modifiers) {
      this.method_modifiers = modifiers;
   }

   public int getMethodModifiers() {
      return this.method_modifiers;
   }

   public void setClassModifiers(int modifiers) {
      this.class_modifiers = modifiers;
   }

   public int getClassModifiers() {
      return this.class_modifiers;
   }

   public void setSuperclass(Class superclass) {
      this.superclass = superclass;
   }

   public Class getSuperclass() {
      return this.superclass;
   }

   public void setExtraInterfaces(Class[] extraInterfaces) {
      this.extraInterfaces = extraInterfaces;
   }

   public Class[] getExtraInterfaces() {
      return this.extraInterfaces;
   }

   public void writeDelegator(Class intfcl, String genclass, Writer w) throws IOException {
      IndentedWriter iw = CodegenUtils.toIndentedWriter(w);
      String pkg = genclass.substring(0, genclass.lastIndexOf(46));
      String sgc = CodegenUtils.fqcnLastElement(genclass);
      String scn = this.superclass != null ? ClassUtils.simpleClassName(this.superclass) : null;
      String sin = ClassUtils.simpleClassName(intfcl);
      String[] eins = null;
      if (this.extraInterfaces != null) {
         eins = new String[this.extraInterfaces.length];
         int i = 0;

         for(int len = this.extraInterfaces.length; i < len; ++i) {
            eins[i] = ClassUtils.simpleClassName(this.extraInterfaces[i]);
         }
      }

      Set imports = new TreeSet(classComp);
      Method[] methods = intfcl.getMethods();
      if (!CodegenUtils.inSamePackage(intfcl.getName(), genclass)) {
         imports.add(intfcl);
      }

      if (this.superclass != null && !CodegenUtils.inSamePackage(this.superclass.getName(), genclass)) {
         imports.add(this.superclass);
      }

      int i;
      int len;
      if (this.extraInterfaces != null) {
         i = 0;

         for(len = this.extraInterfaces.length; i < len; ++i) {
            Class checkMe = this.extraInterfaces[i];
            if (!CodegenUtils.inSamePackage(checkMe.getName(), genclass)) {
               imports.add(checkMe);
            }
         }
      }

      i = 0;

      for(len = methods.length; i < len; ++i) {
         Class[] args = methods[i].getParameterTypes();
         int j = 0;

         int j;
         for(j = args.length; j < j; ++j) {
            if (!CodegenUtils.inSamePackage(args[j].getName(), genclass)) {
               imports.add(CodegenUtils.unarrayClass(args[j]));
            }
         }

         Class[] excClasses = methods[i].getExceptionTypes();
         j = 0;

         for(int jlen = excClasses.length; j < jlen; ++j) {
            if (!CodegenUtils.inSamePackage(excClasses[j].getName(), genclass)) {
               imports.add(CodegenUtils.unarrayClass(excClasses[j]));
            }
         }

         if (!CodegenUtils.inSamePackage(methods[i].getReturnType().getName(), genclass)) {
            imports.add(CodegenUtils.unarrayClass(methods[i].getReturnType()));
         }
      }

      this.generateBannerComment(iw);
      iw.println("package " + pkg + ';');
      iw.println();
      Iterator ii = imports.iterator();

      while(ii.hasNext()) {
         iw.println("import " + ((Class)ii.next()).getName() + ';');
      }

      this.generateExtraImports(iw);
      iw.println();
      iw.print(CodegenUtils.getModifierString(this.class_modifiers) + " class " + sgc);
      if (this.superclass != null) {
         iw.print(" extends " + scn);
      }

      iw.print(" implements " + sin);
      if (eins != null) {
         i = 0;

         for(len = eins.length; i < len; ++i) {
            iw.print(", " + eins[i]);
         }
      }

      iw.println();
      iw.println("{");
      iw.upIndent();
      iw.println("protected " + sin + " inner;");
      iw.println();
      if (this.wrapping_constructor) {
         iw.println("public " + sgc + '(' + sin + " inner)");
         iw.println("{ this.inner = inner; }");
      }

      if (this.default_constructor) {
         iw.println();
         iw.println("public " + sgc + "()");
         iw.println("{}");
      }

      if (this.inner_setter) {
         iw.println();
         iw.println(CodegenUtils.getModifierString(this.method_modifiers) + " void setInner( " + sin + " inner )");
         iw.println("{ this.inner = inner; }");
      }

      if (this.inner_getter) {
         iw.println();
         iw.println(CodegenUtils.getModifierString(this.method_modifiers) + ' ' + sin + " getInner()");
         iw.println("{ return inner; }");
      }

      iw.println();
      i = 0;

      for(len = methods.length; i < len; ++i) {
         Method method = methods[i];
         Class retType = method.getReturnType();
         if (i != 0) {
            iw.println();
         }

         iw.println(CodegenUtils.methodSignature(this.method_modifiers, method, (String[])null));
         iw.println("{");
         iw.upIndent();
         this.generatePreDelegateCode(intfcl, genclass, method, iw);
         this.generateDelegateCode(intfcl, genclass, method, iw);
         this.generatePostDelegateCode(intfcl, genclass, method, iw);
         iw.downIndent();
         iw.println("}");
      }

      iw.println();
      this.generateExtraDeclarations(intfcl, genclass, iw);
      iw.downIndent();
      iw.println("}");
   }

   protected void generateDelegateCode(Class intfcl, String genclass, Method method, IndentedWriter iw) throws IOException {
      Class retType = method.getReturnType();
      iw.println((retType == Void.TYPE ? "" : "return ") + "inner." + CodegenUtils.methodCall(method) + ";");
   }

   protected void generateBannerComment(IndentedWriter iw) throws IOException {
      iw.println("");
   }

   protected void generateExtraImports(IndentedWriter iw) throws IOException {
   }

   protected void generatePreDelegateCode(Class intfcl, String genclass, Method method, IndentedWriter iw) throws IOException {
   }

   protected void generatePostDelegateCode(Class intfcl, String genclass, Method method, IndentedWriter iw) throws IOException {
   }

   protected void generateExtraDeclarations(Class intfcl, String genclass, IndentedWriter iw) throws IOException {
   }
}