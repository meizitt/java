package com.mchange.v2.sql.filter;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public abstract class FilterPreparedStatement implements PreparedStatement {
   protected PreparedStatement inner;

   public FilterPreparedStatement(PreparedStatement inner) {
      this.inner = inner;
   }

   public FilterPreparedStatement() {
   }

   public void setInner(PreparedStatement inner) {
      this.inner = inner;
   }

   public PreparedStatement getInner() {
      return this.inner;
   }

   public ResultSetMetaData getMetaData() throws SQLException {
      return this.inner.getMetaData();
   }

   public ResultSet executeQuery() throws SQLException {
      return this.inner.executeQuery();
   }

   public int executeUpdate() throws SQLException {
      return this.inner.executeUpdate();
   }

   public void addBatch() throws SQLException {
      this.inner.addBatch();
   }

   public void setNull(int a, int b, String c) throws SQLException {
      this.inner.setNull(a, b, c);
   }

   public void setNull(int a, int b) throws SQLException {
      this.inner.setNull(a, b);
   }

   public void setBigDecimal(int a, BigDecimal b) throws SQLException {
      this.inner.setBigDecimal(a, b);
   }

   public void setBytes(int a, byte[] b) throws SQLException {
      this.inner.setBytes(a, b);
   }

   public void setTimestamp(int a, Timestamp b, Calendar c) throws SQLException {
      this.inner.setTimestamp(a, b, c);
   }

   public void setTimestamp(int a, Timestamp b) throws SQLException {
      this.inner.setTimestamp(a, b);
   }

   public void setAsciiStream(int a, InputStream b, int c) throws SQLException {
      this.inner.setAsciiStream(a, b, c);
   }

   public void setUnicodeStream(int a, InputStream b, int c) throws SQLException {
      this.inner.setUnicodeStream(a, b, c);
   }

   public void setBinaryStream(int a, InputStream b, int c) throws SQLException {
      this.inner.setBinaryStream(a, b, c);
   }

   public void clearParameters() throws SQLException {
      this.inner.clearParameters();
   }

   public void setObject(int a, Object b) throws SQLException {
      this.inner.setObject(a, b);
   }

   public void setObject(int a, Object b, int c, int d) throws SQLException {
      this.inner.setObject(a, b, c, d);
   }

   public void setObject(int a, Object b, int c) throws SQLException {
      this.inner.setObject(a, b, c);
   }

   public void setCharacterStream(int a, Reader b, int c) throws SQLException {
      this.inner.setCharacterStream(a, b, c);
   }

   public void setRef(int a, Ref b) throws SQLException {
      this.inner.setRef(a, b);
   }

   public void setBlob(int a, Blob b) throws SQLException {
      this.inner.setBlob(a, b);
   }

   public void setClob(int a, Clob b) throws SQLException {
      this.inner.setClob(a, b);
   }

   public void setArray(int a, Array b) throws SQLException {
      this.inner.setArray(a, b);
   }

   public ParameterMetaData getParameterMetaData() throws SQLException {
      return this.inner.getParameterMetaData();
   }

   public void setBoolean(int a, boolean b) throws SQLException {
      this.inner.setBoolean(a, b);
   }

   public void setByte(int a, byte b) throws SQLException {
      this.inner.setByte(a, b);
   }

   public void setShort(int a, short b) throws SQLException {
      this.inner.setShort(a, b);
   }

   public void setInt(int a, int b) throws SQLException {
      this.inner.setInt(a, b);
   }

   public void setLong(int a, long b) throws SQLException {
      this.inner.setLong(a, b);
   }

   public void setFloat(int a, float b) throws SQLException {
      this.inner.setFloat(a, b);
   }

   public void setDouble(int a, double b) throws SQLException {
      this.inner.setDouble(a, b);
   }

   public void setURL(int a, URL b) throws SQLException {
      this.inner.setURL(a, b);
   }

   public void setTime(int a, Time b) throws SQLException {
      this.inner.setTime(a, b);
   }

   public void setTime(int a, Time b, Calendar c) throws SQLException {
      this.inner.setTime(a, b, c);
   }

   public boolean execute() throws SQLException {
      return this.inner.execute();
   }

   public void setString(int a, String b) throws SQLException {
      this.inner.setString(a, b);
   }

   public void setDate(int a, Date b, Calendar c) throws SQLException {
      this.inner.setDate(a, b, c);
   }

   public void setDate(int a, Date b) throws SQLException {
      this.inner.setDate(a, b);
   }

   public SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public void setFetchDirection(int a) throws SQLException {
      this.inner.setFetchDirection(a);
   }

   public int getFetchDirection() throws SQLException {
      return this.inner.getFetchDirection();
   }

   public void setFetchSize(int a) throws SQLException {
      this.inner.setFetchSize(a);
   }

   public int getFetchSize() throws SQLException {
      return this.inner.getFetchSize();
   }

   public int getResultSetHoldability() throws SQLException {
      return this.inner.getResultSetHoldability();
   }

   public ResultSet executeQuery(String a) throws SQLException {
      return this.inner.executeQuery(a);
   }

   public int executeUpdate(String a, int b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a, String[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a, int[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public int executeUpdate(String a) throws SQLException {
      return this.inner.executeUpdate(a);
   }

   public int getMaxFieldSize() throws SQLException {
      return this.inner.getMaxFieldSize();
   }

   public void setMaxFieldSize(int a) throws SQLException {
      this.inner.setMaxFieldSize(a);
   }

   public int getMaxRows() throws SQLException {
      return this.inner.getMaxRows();
   }

   public void setMaxRows(int a) throws SQLException {
      this.inner.setMaxRows(a);
   }

   public void setEscapeProcessing(boolean a) throws SQLException {
      this.inner.setEscapeProcessing(a);
   }

   public int getQueryTimeout() throws SQLException {
      return this.inner.getQueryTimeout();
   }

   public void setQueryTimeout(int a) throws SQLException {
      this.inner.setQueryTimeout(a);
   }

   public void setCursorName(String a) throws SQLException {
      this.inner.setCursorName(a);
   }

   public ResultSet getResultSet() throws SQLException {
      return this.inner.getResultSet();
   }

   public int getUpdateCount() throws SQLException {
      return this.inner.getUpdateCount();
   }

   public boolean getMoreResults() throws SQLException {
      return this.inner.getMoreResults();
   }

   public boolean getMoreResults(int a) throws SQLException {
      return this.inner.getMoreResults(a);
   }

   public int getResultSetConcurrency() throws SQLException {
      return this.inner.getResultSetConcurrency();
   }

   public int getResultSetType() throws SQLException {
      return this.inner.getResultSetType();
   }

   public void addBatch(String a) throws SQLException {
      this.inner.addBatch(a);
   }

   public void clearBatch() throws SQLException {
      this.inner.clearBatch();
   }

   public int[] executeBatch() throws SQLException {
      return this.inner.executeBatch();
   }

   public ResultSet getGeneratedKeys() throws SQLException {
      return this.inner.getGeneratedKeys();
   }

   public void close() throws SQLException {
      this.inner.close();
   }

   public boolean execute(String a, int b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public boolean execute(String a) throws SQLException {
      return this.inner.execute(a);
   }

   public boolean execute(String a, int[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public boolean execute(String a, String[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public Connection getConnection() throws SQLException {
      return this.inner.getConnection();
   }

   public void cancel() throws SQLException {
      this.inner.cancel();
   }
}