package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.IndentedWriter;
import com.mchange.v2.codegen.bean.SimpleStateBeanImportExportGeneratorExtension.SimplePropertyMask;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;

public class SimpleStateBeanImportExportGeneratorExtension implements GeneratorExtension {
   int ctor_modifiers = 1;

   public Collection extraGeneralImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraSpecificImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraInterfaceNames() {
      return Collections.EMPTY_SET;
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      int num_props = props.length;
      Property[] masked = new Property[num_props];

      int i;
      for(i = 0; i < num_props; ++i) {
         masked[i] = new SimplePropertyMask(props[i]);
      }

      iw.println("protected static class SimpleStateBean implements ExportedState");
      iw.println("{");
      iw.upIndent();

      for(i = 0; i < num_props; ++i) {
         masked[i] = new SimplePropertyMask(props[i]);
         BeangenUtils.writePropertyMember(masked[i], iw);
         iw.println();
         BeangenUtils.writePropertyGetter(masked[i], iw);
         iw.println();
         BeangenUtils.writePropertySetter(masked[i], iw);
      }

      iw.downIndent();
      iw.println("}");
   }
}