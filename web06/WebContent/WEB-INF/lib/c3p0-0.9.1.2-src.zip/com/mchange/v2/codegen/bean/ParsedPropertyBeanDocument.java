package com.mchange.v2.codegen.bean;

import com.mchange.v1.xml.DomParseUtils;
import com.mchange.v2.codegen.bean.ParsedPropertyBeanDocument.1;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ParsedPropertyBeanDocument {
   static final String[] EMPTY_SA = new String[0];
   String packageName;
   int class_modifiers;
   String className;
   String superclassName;
   String[] interfaceNames;
   String[] generalImports;
   String[] specificImports;
   Property[] properties;

   public ParsedPropertyBeanDocument(Document doc) {
      this.interfaceNames = EMPTY_SA;
      this.generalImports = EMPTY_SA;
      this.specificImports = EMPTY_SA;
      Element rootElem = doc.getDocumentElement();
      this.packageName = DomParseUtils.allTextFromUniqueChild(rootElem, "package");
      Element modifiersElem = DomParseUtils.uniqueImmediateChild(rootElem, "modifiers");
      if (modifiersElem != null) {
         this.class_modifiers = parseModifiers(modifiersElem);
      } else {
         this.class_modifiers = 1;
      }

      Element importsElem = DomParseUtils.uniqueChild(rootElem, "imports");
      if (importsElem != null) {
         this.generalImports = DomParseUtils.allTextFromImmediateChildElements(importsElem, "general");
         this.specificImports = DomParseUtils.allTextFromImmediateChildElements(importsElem, "specific");
      }

      this.className = DomParseUtils.allTextFromUniqueChild(rootElem, "output-class");
      this.superclassName = DomParseUtils.allTextFromUniqueChild(rootElem, "extends");
      Element implementsElem = DomParseUtils.uniqueChild(rootElem, "implements");
      if (implementsElem != null) {
         this.interfaceNames = DomParseUtils.allTextFromImmediateChildElements(implementsElem, "interface");
      }

      Element propertiesElem = DomParseUtils.uniqueChild(rootElem, "properties");
      this.properties = this.findProperties(propertiesElem);
   }

   public ClassInfo getClassInfo() {
      return new 1(this);
   }

   public Property[] getProperties() {
      return (Property[])((Property[])this.properties.clone());
   }

   private Property[] findProperties(Element propertiesElem) {
      NodeList nl = DomParseUtils.immediateChildElementsByTagName(propertiesElem, "property");
      int len = nl.getLength();
      Property[] out = new Property[len];

      for(int i = 0; i < len; ++i) {
         Element propertyElem = (Element)nl.item(i);
         int variable_modifiers = modifiersThroughParentElem(propertyElem, "variable", 2);
         String name = DomParseUtils.allTextFromUniqueChild(propertyElem, "name", true);
         String simpleTypeName = DomParseUtils.allTextFromUniqueChild(propertyElem, "type", true);
         String defensiveCopyExpression = DomParseUtils.allTextFromUniqueChild(propertyElem, "defensive-copy", true);
         String defaultValueExpression = DomParseUtils.allTextFromUniqueChild(propertyElem, "default-value", true);
         int getter_modifiers = modifiersThroughParentElem(propertyElem, "getter", 1);
         int setter_modifiers = modifiersThroughParentElem(propertyElem, "setter", 1);
         Element readOnlyElem = DomParseUtils.uniqueChild(propertyElem, "read-only");
         boolean is_read_only = readOnlyElem != null;
         Element isBoundElem = DomParseUtils.uniqueChild(propertyElem, "bound");
         boolean is_bound = isBoundElem != null;
         Element isConstrainedElem = DomParseUtils.uniqueChild(propertyElem, "constrained");
         boolean is_constrained = isConstrainedElem != null;
         out[i] = new SimpleProperty(variable_modifiers, name, simpleTypeName, defensiveCopyExpression, defaultValueExpression, getter_modifiers, setter_modifiers, is_read_only, is_bound, is_constrained);
      }

      return out;
   }

   private static int modifiersThroughParentElem(Element grandparentElem, String parentElemName, int default_mods) {
      Element parentElem = DomParseUtils.uniqueChild(grandparentElem, parentElemName);
      if (parentElem != null) {
         Element modifiersElem = DomParseUtils.uniqueChild(parentElem, "modifiers");
         return modifiersElem != null ? parseModifiers(modifiersElem) : default_mods;
      } else {
         return default_mods;
      }
   }

   private static int parseModifiers(Element modifiersElem) {
      int out = 0;
      String[] all_modifiers = DomParseUtils.allTextFromImmediateChildElements(modifiersElem, "modifier", true);
      int i = 0;

      for(int len = all_modifiers.length; i < len; ++i) {
         String modifier = all_modifiers[i];
         if ("public".equals(modifier)) {
            out |= 1;
         } else if ("protected".equals(modifier)) {
            out |= 4;
         } else if ("private".equals(modifier)) {
            out |= 2;
         } else if ("final".equals(modifier)) {
            out |= 16;
         } else if ("abstract".equals(modifier)) {
            out |= 1024;
         } else if ("static".equals(modifier)) {
            out |= 8;
         } else if ("synchronized".equals(modifier)) {
            out |= 32;
         } else if ("volatile".equals(modifier)) {
            out |= 64;
         } else if ("transient".equals(modifier)) {
            out |= 128;
         } else if ("strictfp".equals(modifier)) {
            out |= 2048;
         } else if ("native".equals(modifier)) {
            out |= 256;
         } else {
            if (!"interface".equals(modifier)) {
               throw new IllegalArgumentException("Bad modifier: " + modifier);
            }

            out |= 512;
         }
      }

      return out;
   }
}