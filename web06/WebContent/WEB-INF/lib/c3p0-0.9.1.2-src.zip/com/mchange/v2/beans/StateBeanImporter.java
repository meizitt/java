package com.mchange.v2.beans;

public interface StateBeanImporter extends StateBeanExporter {
   void importStateBean(StateBean var1);
}