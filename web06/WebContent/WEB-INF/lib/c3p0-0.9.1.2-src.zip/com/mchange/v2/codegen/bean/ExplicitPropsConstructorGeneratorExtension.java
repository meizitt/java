package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.CodegenUtils;
import com.mchange.v2.codegen.IndentedWriter;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExplicitPropsConstructorGeneratorExtension implements GeneratorExtension {
   static final MLogger logger;
   String[] propNames;
   boolean skips_silently = false;
   int ctor_modifiers = 1;

   public ExplicitPropsConstructorGeneratorExtension() {
   }

   public ExplicitPropsConstructorGeneratorExtension(String[] propNames) {
      this.propNames = propNames;
   }

   public String[] getPropNames() {
      return (String[])((String[])this.propNames.clone());
   }

   public void setPropNames(String[] propNames) {
      this.propNames = (String[])((String[])propNames.clone());
   }

   public boolean isSkipsSilently() {
      return this.skips_silently;
   }

   public void setsSkipsSilently(boolean skips_silently) {
      this.skips_silently = skips_silently;
   }

   public Collection extraGeneralImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraSpecificImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraInterfaceNames() {
      return Collections.EMPTY_SET;
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      Map propNamesToProps = new HashMap();
      int i = 0;

      int i;
      for(i = props.length; i < i; ++i) {
         propNamesToProps.put(props[i].getName(), props[i]);
      }

      List subPropsList = new ArrayList(this.propNames.length);
      i = 0;

      int i;
      for(i = this.propNames.length; i < i; ++i) {
         Property p = (Property)propNamesToProps.get(this.propNames[i]);
         if (p == null) {
            logger.warning("Could not include property '" + this.propNames[i] + "' in explicit-props-constructor generated for bean class '" + info.getClassName() + "' because the property is not defined for the bean. Skipping.");
         } else {
            subPropsList.add(p);
         }
      }

      if (subPropsList.size() > 0) {
         Property[] subProps = (Property[])((Property[])subPropsList.toArray(new Property[subPropsList.size()]));
         iw.print(CodegenUtils.getModifierString(this.ctor_modifiers));
         iw.print(info.getClassName() + "( ");
         BeangenUtils.writeArgList(subProps, true, iw);
         iw.println(" )");
         iw.println("{");
         iw.upIndent();
         i = 0;

         for(int len = subProps.length; i < len; ++i) {
            iw.print("this." + subProps[i].getName() + " = ");
            String setExp = subProps[i].getDefensiveCopyExpression();
            if (setExp == null) {
               setExp = subProps[i].getName();
            }

            iw.println(setExp + ';');
         }

         iw.downIndent();
         iw.println("}");
      }

   }

   static {
      logger = MLog.getLogger(ExplicitPropsConstructorGeneratorExtension.class);
   }
}