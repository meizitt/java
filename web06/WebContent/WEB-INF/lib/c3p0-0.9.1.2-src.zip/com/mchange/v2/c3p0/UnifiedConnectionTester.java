package com.mchange.v2.c3p0;

import java.sql.Connection;

public interface UnifiedConnectionTester extends FullQueryConnectionTester {
   int CONNECTION_IS_OKAY = 0;
   int CONNECTION_IS_INVALID = -1;
   int DATABASE_IS_INVALID = -8;

   int activeCheckConnection(Connection var1);

   int activeCheckConnection(Connection var1, Throwable[] var2);

   int activeCheckConnection(Connection var1, String var2);

   int activeCheckConnection(Connection var1, String var2, Throwable[] var3);

   int statusOnException(Connection var1, Throwable var2);

   int statusOnException(Connection var1, Throwable var2, Throwable[] var3);

   int statusOnException(Connection var1, Throwable var2, String var3);

   int statusOnException(Connection var1, Throwable var2, String var3, Throwable[] var4);

   boolean equals(Object var1);

   int hashCode();
}