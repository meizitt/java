package com.mchange.v2.async;

import com.mchange.v2.async.ThreadPoolAsynchronousRunner.DeadlockDetector;
import com.mchange.v2.async.ThreadPoolAsynchronousRunner.MaxIndividualTaskTimeEnforcer;
import com.mchange.v2.async.ThreadPoolAsynchronousRunner.PoolThread;
import com.mchange.v2.async.ThreadPoolAsynchronousRunner.ReplacedThreadInterruptor;
import com.mchange.v2.io.IndentedWriter;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.util.ResourceClosedException;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public final class ThreadPoolAsynchronousRunner implements AsynchronousRunner {
   static final MLogger logger;
   static final int POLL_FOR_STOP_INTERVAL = 5000;
   static final int DFLT_DEADLOCK_DETECTOR_INTERVAL = 10000;
   static final int DFLT_INTERRUPT_DELAY_AFTER_APPARENT_DEADLOCK = 60000;
   static final int DFLT_MAX_INDIVIDUAL_TASK_TIME = 0;
   static final int DFLT_MAX_EMERGENCY_THREADS = 10;
   int deadlock_detector_interval;
   int interrupt_delay_after_apparent_deadlock;
   int max_individual_task_time;
   int num_threads;
   boolean daemon;
   HashSet managed;
   HashSet available;
   LinkedList pendingTasks;
   Timer myTimer;
   boolean should_cancel_timer;
   TimerTask deadlockDetector;
   TimerTask replacedThreadInterruptor;
   Map stoppedThreadsToStopDates;

   private ThreadPoolAsynchronousRunner(int num_threads, boolean daemon, int max_individual_task_time, int deadlock_detector_interval, int interrupt_delay_after_apparent_deadlock, Timer myTimer, boolean should_cancel_timer) {
      this.deadlockDetector = new DeadlockDetector(this);
      this.replacedThreadInterruptor = null;
      this.stoppedThreadsToStopDates = new HashMap();
      this.num_threads = num_threads;
      this.daemon = daemon;
      this.max_individual_task_time = max_individual_task_time;
      this.deadlock_detector_interval = deadlock_detector_interval;
      this.interrupt_delay_after_apparent_deadlock = interrupt_delay_after_apparent_deadlock;
      this.myTimer = myTimer;
      this.should_cancel_timer = should_cancel_timer;
      this.recreateThreadsAndTasks();
      myTimer.schedule(this.deadlockDetector, (long)deadlock_detector_interval, (long)deadlock_detector_interval);
   }

   public ThreadPoolAsynchronousRunner(int num_threads, boolean daemon, int max_individual_task_time, int deadlock_detector_interval, int interrupt_delay_after_apparent_deadlock, Timer myTimer) {
      this(num_threads, daemon, max_individual_task_time, deadlock_detector_interval, interrupt_delay_after_apparent_deadlock, myTimer, false);
   }

   public ThreadPoolAsynchronousRunner(int num_threads, boolean daemon, int max_individual_task_time, int deadlock_detector_interval, int interrupt_delay_after_apparent_deadlock) {
      this(num_threads, daemon, max_individual_task_time, deadlock_detector_interval, interrupt_delay_after_apparent_deadlock, new Timer(true), true);
   }

   public ThreadPoolAsynchronousRunner(int num_threads, boolean daemon, Timer sharedTimer) {
      this(num_threads, daemon, 0, 10000, 60000, sharedTimer, false);
   }

   public ThreadPoolAsynchronousRunner(int num_threads, boolean daemon) {
      this(num_threads, daemon, 0, 10000, 60000, new Timer(true), true);
   }

   public synchronized void postRunnable(Runnable r) {
      try {
         this.pendingTasks.add(r);
         this.notifyAll();
      } catch (NullPointerException var3) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "NullPointerException while posting Runnable -- Probably we're closed.", var3);
         }

         throw new ResourceClosedException("Attempted to use a ThreadPoolAsynchronousRunner in a closed or broken state.");
      }
   }

   public synchronized int getThreadCount() {
      return this.managed.size();
   }

   public void close(boolean skip_remaining_tasks) {
      synchronized(this) {
         if (this.managed != null) {
            this.deadlockDetector.cancel();
            if (this.should_cancel_timer) {
               this.myTimer.cancel();
            }

            this.myTimer = null;
            Iterator ii = this.managed.iterator();

            while(ii.hasNext()) {
               PoolThread stopMe = (PoolThread)ii.next();
               stopMe.gentleStop();
               if (skip_remaining_tasks) {
                  stopMe.interrupt();
               }
            }

            this.managed = null;
            if (!skip_remaining_tasks) {
               ii = this.pendingTasks.iterator();

               while(ii.hasNext()) {
                  Runnable r = (Runnable)ii.next();
                  (new Thread(r)).start();
                  ii.remove();
               }
            }

            this.available = null;
            this.pendingTasks = null;
         }
      }
   }

   public void close() {
      this.close(true);
   }

   public synchronized int getActiveCount() {
      return this.managed.size() - this.available.size();
   }

   public synchronized int getIdleCount() {
      return this.available.size();
   }

   public synchronized int getPendingTaskCount() {
      return this.pendingTasks.size();
   }

   public synchronized String getStatus() {
      return this.getMultiLineStatusString();
   }

   public synchronized String getStackTraces() {
      return this.getStackTraces(0);
   }

   private String getStackTraces(int initial_indent) {
      if (this.managed == null) {
         return null;
      } else {
         try {
            Method m = Thread.class.getMethod("getStackTrace", (Class[])null);
            StringWriter sw = new StringWriter(2048);
            IndentedWriter iw = new IndentedWriter(sw);

            int i;
            for(i = 0; i < initial_indent; ++i) {
               iw.upIndent();
            }

            Iterator ii = this.managed.iterator();

            while(ii.hasNext()) {
               Object poolThread = ii.next();
               Object[] stackTraces = (Object[])((Object[])m.invoke(poolThread, (Object[])null));
               iw.println(poolThread);
               iw.upIndent();
               int i = 0;

               for(int len = stackTraces.length; i < len; ++i) {
                  iw.println(stackTraces[i]);
               }

               iw.downIndent();
            }

            for(i = 0; i < initial_indent; ++i) {
               iw.downIndent();
            }

            iw.flush();
            String out = sw.toString();
            iw.close();
            return out;
         } catch (NoSuchMethodException var10) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.fine(this + ": strack traces unavailable because this is a pre-Java 1.5 VM.");
            }

            return null;
         } catch (Exception var11) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, this + ": An Exception occurred while trying to extract PoolThread stack traces.", var11);
            }

            return null;
         }
      }
   }

   public synchronized String getMultiLineStatusString() {
      return this.getMultiLineStatusString(0);
   }

   private String getMultiLineStatusString(int initial_indent) {
      try {
         StringWriter sw = new StringWriter(2048);
         IndentedWriter iw = new IndentedWriter(sw);

         int i;
         for(i = 0; i < initial_indent; ++i) {
            iw.upIndent();
         }

         if (this.managed == null) {
            iw.print("[");
            iw.print(this);
            iw.println(" closed.]");
         } else {
            HashSet active = (HashSet)this.managed.clone();
            active.removeAll(this.available);
            iw.print("Managed Threads: ");
            iw.println(this.managed.size());
            iw.print("Active Threads: ");
            iw.println(active.size());
            iw.println("Active Tasks: ");
            iw.upIndent();
            Iterator ii = active.iterator();

            while(ii.hasNext()) {
               PoolThread pt = (PoolThread)ii.next();
               iw.print(pt.getCurrentTask());
               iw.print(" (");
               iw.print(pt.getName());
               iw.println(')');
            }

            iw.downIndent();
            iw.println("Pending Tasks: ");
            iw.upIndent();
            int i = 0;

            for(int len = this.pendingTasks.size(); i < len; ++i) {
               iw.println(this.pendingTasks.get(i));
            }

            iw.downIndent();
         }

         for(i = 0; i < initial_indent; ++i) {
            iw.downIndent();
         }

         iw.flush();
         String out = sw.toString();
         iw.close();
         return out;
      } catch (IOException var7) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Huh? An IOException when working with a StringWriter?!?", var7);
         }

         throw new RuntimeException("Huh? An IOException when working with a StringWriter?!? " + var7);
      }
   }

   private void appendStatusString(StringBuffer sb) {
      if (this.managed == null) {
         sb.append("[closed]");
      } else {
         HashSet active = (HashSet)this.managed.clone();
         active.removeAll(this.available);
         sb.append("[num_managed_threads: ");
         sb.append(this.managed.size());
         sb.append(", num_active: ");
         sb.append(active.size());
         sb.append("; activeTasks: ");
         boolean first = true;
         Iterator ii = active.iterator();

         while(ii.hasNext()) {
            if (first) {
               first = false;
            } else {
               sb.append(", ");
            }

            PoolThread pt = (PoolThread)ii.next();
            sb.append(pt.getCurrentTask());
            sb.append(" (");
            sb.append(pt.getName());
            sb.append(')');
         }

         sb.append("; pendingTasks: ");
         int i = 0;

         for(int len = this.pendingTasks.size(); i < len; ++i) {
            if (i != 0) {
               sb.append(", ");
            }

            sb.append(this.pendingTasks.get(i));
         }

         sb.append(']');
      }

   }

   private void recreateThreadsAndTasks() {
      if (this.managed != null) {
         Date aboutNow = new Date();
         Iterator ii = this.managed.iterator();

         while(ii.hasNext()) {
            PoolThread pt = (PoolThread)ii.next();
            pt.gentleStop();
            this.stoppedThreadsToStopDates.put(pt, aboutNow);
            this.ensureReplacedThreadsProcessing();
         }
      }

      this.managed = new HashSet();
      this.available = new HashSet();
      this.pendingTasks = new LinkedList();

      for(int i = 0; i < this.num_threads; ++i) {
         Thread t = new PoolThread(this, i, this.daemon);
         this.managed.add(t);
         this.available.add(t);
         t.start();
      }

   }

   private void processReplacedThreads() {
      long about_now = System.currentTimeMillis();
      Iterator ii = this.stoppedThreadsToStopDates.keySet().iterator();

      while(ii.hasNext()) {
         PoolThread pt = (PoolThread)ii.next();
         if (!pt.isAlive()) {
            ii.remove();
         } else {
            Date d = (Date)this.stoppedThreadsToStopDates.get(pt);
            if (about_now - d.getTime() > (long)this.interrupt_delay_after_apparent_deadlock) {
               if (logger.isLoggable(MLevel.WARNING)) {
                  logger.log(MLevel.WARNING, "Task " + pt.getCurrentTask() + " (in deadlocked PoolThread) failed to complete in maximum time " + this.interrupt_delay_after_apparent_deadlock + "ms. Trying interrupt().");
               }

               pt.interrupt();
               ii.remove();
            }
         }

         if (this.stoppedThreadsToStopDates.isEmpty()) {
            this.stopReplacedThreadsProcessing();
         }
      }

   }

   private void ensureReplacedThreadsProcessing() {
      if (this.replacedThreadInterruptor == null) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.fine("Apparently some threads have been replaced. Replacement thread processing enabled.");
         }

         this.replacedThreadInterruptor = new ReplacedThreadInterruptor(this);
         int replacedThreadProcessDelay = this.interrupt_delay_after_apparent_deadlock / 4;
         this.myTimer.schedule(this.replacedThreadInterruptor, (long)replacedThreadProcessDelay, (long)replacedThreadProcessDelay);
      }

   }

   private void stopReplacedThreadsProcessing() {
      if (this.replacedThreadInterruptor != null) {
         this.replacedThreadInterruptor.cancel();
         this.replacedThreadInterruptor = null;
         if (logger.isLoggable(MLevel.FINE)) {
            logger.fine("Apparently all replaced threads have either completed their tasks or been interrupted(). Replacement thread processing cancelled.");
         }
      }

   }

   private void shuttingDown(PoolThread pt) {
      if (this.managed != null && this.managed.contains(pt)) {
         this.managed.remove(pt);
         this.available.remove(pt);
         PoolThread replacement = new PoolThread(this, pt.getIndex(), this.daemon);
         this.managed.add(replacement);
         this.available.add(replacement);
         replacement.start();
      }

   }

   private void runInEmergencyThread(Runnable r) {
      Thread t = new Thread(r);
      t.start();
      if (this.max_individual_task_time > 0) {
         TimerTask maxIndividualTaskTimeEnforcer = new MaxIndividualTaskTimeEnforcer(this, t, t + " [One-off emergency thread!!!]", r.toString());
         this.myTimer.schedule(maxIndividualTaskTimeEnforcer, (long)this.max_individual_task_time);
      }

   }

   static {
      logger = MLog.getLogger(ThreadPoolAsynchronousRunner.class);
   }
}