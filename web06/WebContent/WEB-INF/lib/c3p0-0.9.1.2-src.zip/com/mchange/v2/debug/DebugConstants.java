package com.mchange.v2.debug;

public interface DebugConstants {
   int TRACE_NONE = 0;
   int TRACE_MED = 5;
   int TRACE_MAX = 10;
}