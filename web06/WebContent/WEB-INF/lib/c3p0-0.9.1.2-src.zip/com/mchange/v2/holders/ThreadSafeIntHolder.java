package com.mchange.v2.holders;

public interface ThreadSafeIntHolder {
   int getValue();

   void setValue(int var1);
}