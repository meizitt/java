package com.mchange.v2.coalesce;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Map;

class AbstractWeakCoalescer implements Coalescer {
   Map wcoalesced;

   AbstractWeakCoalescer(Map wcoalesced) {
      this.wcoalesced = wcoalesced;
   }

   public Object coalesce(Object o) {
      Object out = null;
      WeakReference wr = (WeakReference)this.wcoalesced.get(o);
      if (wr != null) {
         out = wr.get();
      }

      if (out == null) {
         this.wcoalesced.put(o, new WeakReference(o));
         out = o;
      }

      return out;
   }

   public int countCoalesced() {
      return this.wcoalesced.size();
   }

   public Iterator iterator() {
      return new CoalescerIterator(this.wcoalesced.keySet().iterator());
   }
}