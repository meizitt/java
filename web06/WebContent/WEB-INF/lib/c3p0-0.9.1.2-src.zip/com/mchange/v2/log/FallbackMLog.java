package com.mchange.v2.log;

import com.mchange.v2.log.FallbackMLog.1;
import com.mchange.v2.log.FallbackMLog.FallbackMLogger;

public final class FallbackMLog extends MLog {
   static final MLevel DEFAULT_CUTOFF_LEVEL;
   MLogger logger = new FallbackMLogger((1)null);

   public synchronized MLogger getMLogger(String name) {
      return this.logger;
   }

   public MLogger getMLogger(Class cl) {
      return getLogger(cl.getName());
   }

   public MLogger getMLogger() {
      return this.logger;
   }

   static {
      MLevel dflt = null;
      String dfltName = MLog.CONFIG.getProperty("com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL");
      if (dfltName != null) {
         dflt = MLevel.fromSeverity(dfltName);
      }

      if (dflt == null) {
         dflt = MLevel.INFO;
      }

      DEFAULT_CUTOFF_LEVEL = dflt;
   }
}