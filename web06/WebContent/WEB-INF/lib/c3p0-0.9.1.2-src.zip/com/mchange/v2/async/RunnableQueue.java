package com.mchange.v2.async;

public interface RunnableQueue extends AsynchronousRunner {
}