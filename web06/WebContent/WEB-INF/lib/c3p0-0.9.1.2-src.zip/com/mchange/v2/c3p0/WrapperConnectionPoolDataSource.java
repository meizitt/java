package com.mchange.v2.c3p0;

import com.mchange.v2.c3p0.WrapperConnectionPoolDataSource.1;
import com.mchange.v2.c3p0.cfg.C3P0Config;
import com.mchange.v2.c3p0.impl.C3P0ImplUtils;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection;
import com.mchange.v2.c3p0.impl.NewPooledConnection;
import com.mchange.v2.c3p0.impl.WrapperConnectionPoolDataSourceBase;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.beans.VetoableChangeListener;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.DataSource;
import javax.sql.PooledConnection;

public final class WrapperConnectionPoolDataSource extends WrapperConnectionPoolDataSourceBase implements ConnectionPoolDataSource {
   static final MLogger logger;
   ConnectionTester connectionTester;
   Map userOverrides;

   public WrapperConnectionPoolDataSource(boolean autoregister) {
      super(autoregister);
      this.connectionTester = C3P0ImplUtils.defaultConnectionTester();
      this.setUpPropertyListeners();

      try {
         this.userOverrides = C3P0ImplUtils.parseUserOverridesAsString(this.getUserOverridesAsString());
      } catch (Exception var3) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Failed to parse stringified userOverrides. " + this.getUserOverridesAsString(), var3);
         }
      }

   }

   public WrapperConnectionPoolDataSource() {
      this(true);
   }

   private void setUpPropertyListeners() {
      VetoableChangeListener setConnectionTesterListener = new 1(this);
      this.addVetoableChangeListener(setConnectionTesterListener);
   }

   public WrapperConnectionPoolDataSource(String configName) {
      this();

      try {
         if (configName != null) {
            C3P0Config.bindNamedConfigToBean(this, configName);
         }
      } catch (Exception var3) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Error binding WrapperConnectionPoolDataSource to named-config '" + configName + "'. Some default-config values may be used.", var3);
         }
      }

   }

   public PooledConnection getPooledConnection() throws SQLException {
      return this.getPooledConnection((ConnectionCustomizer)((ConnectionCustomizer)null), (String)null);
   }

   protected PooledConnection getPooledConnection(ConnectionCustomizer cc, String pdsIdt) throws SQLException {
      DataSource nds = this.getNestedDataSource();
      if (nds == null) {
         throw new SQLException("No standard DataSource has been set beneath this wrapper! [ nestedDataSource == null ]");
      } else {
         Connection conn = nds.getConnection();
         if (conn == null) {
            throw new SQLException("An (unpooled) DataSource returned null from its getConnection() method! DataSource: " + this.getNestedDataSource());
         } else {
            return (PooledConnection)(this.isUsesTraditionalReflectiveProxies() ? new C3P0PooledConnection(conn, this.connectionTester, this.isAutoCommitOnClose(), this.isForceIgnoreUnresolvedTransactions(), cc, pdsIdt) : new NewPooledConnection(conn, this.connectionTester, this.isAutoCommitOnClose(), this.isForceIgnoreUnresolvedTransactions(), this.getPreferredTestQuery(), cc, pdsIdt));
         }
      }
   }

   public PooledConnection getPooledConnection(String user, String password) throws SQLException {
      return this.getPooledConnection(user, password, (ConnectionCustomizer)null, (String)null);
   }

   protected PooledConnection getPooledConnection(String user, String password, ConnectionCustomizer cc, String pdsIdt) throws SQLException {
      DataSource nds = this.getNestedDataSource();
      if (nds == null) {
         throw new SQLException("No standard DataSource has been set beneath this wrapper! [ nestedDataSource == null ]");
      } else {
         Connection conn = nds.getConnection(user, password);
         if (conn == null) {
            throw new SQLException("An (unpooled) DataSource returned null from its getConnection() method! DataSource: " + this.getNestedDataSource());
         } else {
            return (PooledConnection)(this.isUsesTraditionalReflectiveProxies() ? new C3P0PooledConnection(conn, this.connectionTester, this.isAutoCommitOnClose(), this.isForceIgnoreUnresolvedTransactions(), cc, pdsIdt) : new NewPooledConnection(conn, this.connectionTester, this.isAutoCommitOnClose(), this.isForceIgnoreUnresolvedTransactions(), this.getPreferredTestQuery(), cc, pdsIdt));
         }
      }
   }

   public PrintWriter getLogWriter() throws SQLException {
      return this.getNestedDataSource().getLogWriter();
   }

   public void setLogWriter(PrintWriter out) throws SQLException {
      this.getNestedDataSource().setLogWriter(out);
   }

   public void setLoginTimeout(int seconds) throws SQLException {
      this.getNestedDataSource().setLoginTimeout(seconds);
   }

   public int getLoginTimeout() throws SQLException {
      return this.getNestedDataSource().getLoginTimeout();
   }

   public String getUser() {
      try {
         return C3P0ImplUtils.findAuth(this.getNestedDataSource()).getUser();
      } catch (SQLException var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while trying to find the 'user' property from our nested DataSource. Defaulting to no specified username.", var2);
         }

         return null;
      }
   }

   public String getPassword() {
      try {
         return C3P0ImplUtils.findAuth(this.getNestedDataSource()).getPassword();
      } catch (SQLException var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while trying to find the 'password' property from our nested DataSource. Defaulting to no specified password.", var2);
         }

         return null;
      }
   }

   public Map getUserOverrides() {
      return this.userOverrides;
   }

   public String toString() {
      StringBuffer sb = new StringBuffer();
      sb.append(super.toString());
      return sb.toString();
   }

   protected String extraToStringInfo() {
      return this.userOverrides != null ? "; userOverrides: " + this.userOverrides.toString() : null;
   }

   private synchronized void recreateConnectionTester(String className) throws Exception {
      if (className != null) {
         ConnectionTester ct = (ConnectionTester)Class.forName(className).newInstance();
         this.connectionTester = ct;
      } else {
         this.connectionTester = C3P0ImplUtils.defaultConnectionTester();
      }

   }

   static {
      logger = MLog.getLogger(WrapperConnectionPoolDataSource.class);
   }
}