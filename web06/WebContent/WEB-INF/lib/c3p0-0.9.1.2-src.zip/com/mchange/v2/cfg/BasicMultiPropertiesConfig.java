package com.mchange.v2.cfg;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLogger;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class BasicMultiPropertiesConfig extends MultiPropertiesConfig {
   String[] rps;
   Map propsByResourcePaths;
   Map propsByPrefixes;
   Properties propsByKey;

   public BasicMultiPropertiesConfig(String[] resourcePaths) {
      this(resourcePaths, (MLogger)null);
   }

   public BasicMultiPropertiesConfig(String[] resourcePaths, MLogger logger) {
      this.propsByResourcePaths = new HashMap();
      List goodPaths = new ArrayList();
      int i = 0;

      for(int len = resourcePaths.length; i < len; ++i) {
         String rp = resourcePaths[i];
         if ("/".equals(rp)) {
            try {
               this.propsByResourcePaths.put(rp, System.getProperties());
               goodPaths.add(rp);
            } catch (SecurityException var19) {
               if (logger != null) {
                  if (logger.isLoggable(MLevel.WARNING)) {
                     logger.log(MLevel.WARNING, "Read of system Properties blocked -- ignoring any configuration via System properties, and using Empty Properties! (But any configuration via a resource properties files is still okay!)", var19);
                  }
               } else {
                  System.err.println("Read of system Properties blocked -- ignoring any configuration via System properties, and using Empty Properties! (But any configuration via a resource properties files is still okay!)");
                  var19.printStackTrace();
               }
            }
         } else {
            Properties p = new Properties();
            InputStream pis = MultiPropertiesConfig.class.getResourceAsStream(rp);
            if (pis != null) {
               try {
                  p.load(pis);
                  this.propsByResourcePaths.put(rp, p);
                  goodPaths.add(rp);
               } catch (IOException var20) {
                  if (logger != null) {
                     if (logger.isLoggable(MLevel.WARNING)) {
                        logger.log(MLevel.WARNING, "An IOException occurred while loading configuration properties from resource path '" + rp + "'.", var20);
                     }
                  } else {
                     var20.printStackTrace();
                  }
               } finally {
                  try {
                     if (pis != null) {
                        pis.close();
                     }
                  } catch (IOException var18) {
                     if (logger != null) {
                        if (logger.isLoggable(MLevel.WARNING)) {
                           logger.log(MLevel.WARNING, "An IOException occurred while closing InputStream from resource path '" + rp + "'.", var18);
                        }
                     } else {
                        var18.printStackTrace();
                     }
                  }

               }
            } else if (logger != null && logger.isLoggable(MLevel.FINE)) {
               logger.fine("Configuration properties not found at ResourcePath '" + rp + "'. [logger name: " + logger.getName() + ']');
            }
         }
      }

      this.rps = (String[])((String[])goodPaths.toArray(new String[goodPaths.size()]));
      this.propsByPrefixes = Collections.unmodifiableMap(extractPrefixMapFromRsrcPathMap(this.rps, this.propsByResourcePaths));
      this.propsByResourcePaths = Collections.unmodifiableMap(this.propsByResourcePaths);
      this.propsByKey = extractPropsByKey(this.rps, this.propsByResourcePaths);
   }

   private static String extractPrefix(String s) {
      int lastdot = s.lastIndexOf(46);
      return lastdot < 0 ? null : s.substring(0, lastdot);
   }

   private static Properties findProps(String rp, Map pbrp) {
      Properties p = (Properties)pbrp.get(rp);
      return p;
   }

   private static Properties extractPropsByKey(String[] resourcePaths, Map pbrp) {
      Properties out = new Properties();
      int i = 0;

      label56:
      for(int len = resourcePaths.length; i < len; ++i) {
         String rp = resourcePaths[i];
         Properties p = findProps(rp, pbrp);
         if (p == null) {
            System.err.println("Could not find loaded properties for resource path: " + rp);
         } else {
            Iterator ii = p.keySet().iterator();

            while(true) {
               while(true) {
                  if (!ii.hasNext()) {
                     continue label56;
                  }

                  Object kObj = ii.next();
                  if (!(kObj instanceof String)) {
                     System.err.println(BasicMultiPropertiesConfig.class.getName() + ": " + "Properties object found at resource path " + ("/".equals(rp) ? "[system properties]" : "'" + rp + "'") + "' contains a key that is not a String: " + kObj);
                     System.err.println("Skipping...");
                  } else {
                     Object vObj = p.get(kObj);
                     if (vObj != null && !(vObj instanceof String)) {
                        System.err.println(BasicMultiPropertiesConfig.class.getName() + ": " + "Properties object found at resource path " + ("/".equals(rp) ? "[system properties]" : "'" + rp + "'") + " contains a value that is not a String: " + vObj);
                        System.err.println("Skipping...");
                     } else {
                        String key = (String)kObj;
                        String val = (String)vObj;
                        out.put(key, val);
                     }
                  }
               }
            }
         }
      }

      return out;
   }

   private static Map extractPrefixMapFromRsrcPathMap(String[] resourcePaths, Map pbrp) {
      Map out = new HashMap();
      int i = 0;

      label56:
      for(int len = resourcePaths.length; i < len; ++i) {
         String rp = resourcePaths[i];
         Properties p = findProps(rp, pbrp);
         if (p == null) {
            System.err.println(BasicMultiPropertiesConfig.class.getName() + " -- Could not find loaded properties for resource path: " + rp);
         } else {
            Iterator jj = p.keySet().iterator();

            while(true) {
               while(true) {
                  if (!jj.hasNext()) {
                     continue label56;
                  }

                  Object kObj = jj.next();
                  if (!(kObj instanceof String)) {
                     System.err.println(BasicMultiPropertiesConfig.class.getName() + ": " + "Properties object found at resource path " + ("/".equals(rp) ? "[system properties]" : "'" + rp + "'") + "' contains a key that is not a String: " + kObj);
                     System.err.println("Skipping...");
                  } else {
                     String key = (String)kObj;

                     for(String prefix = extractPrefix(key); prefix != null; prefix = extractPrefix(prefix)) {
                        Properties byPfx = (Properties)out.get(prefix);
                        if (byPfx == null) {
                           byPfx = new Properties();
                           out.put(prefix, byPfx);
                        }

                        byPfx.put(key, p.get(key));
                     }
                  }
               }
            }
         }
      }

      return out;
   }

   public String[] getPropertiesResourcePaths() {
      return (String[])((String[])this.rps.clone());
   }

   public Properties getPropertiesByResourcePath(String path) {
      Properties out = (Properties)this.propsByResourcePaths.get(path);
      return out == null ? new Properties() : out;
   }

   public Properties getPropertiesByPrefix(String pfx) {
      Properties out = (Properties)this.propsByPrefixes.get(pfx);
      return out == null ? new Properties() : out;
   }

   public String getProperty(String key) {
      return this.propsByKey.getProperty(key);
   }
}