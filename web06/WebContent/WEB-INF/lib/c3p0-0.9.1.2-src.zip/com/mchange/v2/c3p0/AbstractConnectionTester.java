package com.mchange.v2.c3p0;

import java.sql.Connection;

public abstract class AbstractConnectionTester implements UnifiedConnectionTester {
   public abstract int activeCheckConnection(Connection var1, String var2, Throwable[] var3);

   public abstract int statusOnException(Connection var1, Throwable var2, String var3, Throwable[] var4);

   public int activeCheckConnection(Connection c) {
      return this.activeCheckConnection(c, (String)null, (Throwable[])null);
   }

   public int activeCheckConnection(Connection c, Throwable[] rootCauseOutParamHolder) {
      return this.activeCheckConnection(c, (String)null, rootCauseOutParamHolder);
   }

   public int activeCheckConnection(Connection c, String preferredTestQuery) {
      return this.activeCheckConnection(c, preferredTestQuery, (Throwable[])null);
   }

   public int statusOnException(Connection c, Throwable t) {
      return this.statusOnException(c, t, (String)null, (Throwable[])null);
   }

   public int statusOnException(Connection c, Throwable t, Throwable[] rootCauseOutParamHolder) {
      return this.statusOnException(c, t, (String)null, rootCauseOutParamHolder);
   }

   public int statusOnException(Connection c, Throwable t, String preferredTestQuery) {
      return this.statusOnException(c, t, preferredTestQuery, (Throwable[])null);
   }
}