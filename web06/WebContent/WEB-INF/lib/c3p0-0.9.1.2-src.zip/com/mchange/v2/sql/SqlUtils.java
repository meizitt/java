package com.mchange.v2.sql;

import com.mchange.lang.ThrowableUtils;
import com.mchange.v2.lang.VersionUtils;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class SqlUtils {
   static final MLogger logger;
   static final DateFormat tsdf;
   public static final String DRIVER_MANAGER_USER_PROPERTY = "user";
   public static final String DRIVER_MANAGER_PASSWORD_PROPERTY = "password";

   public static String escapeBadSqlPatternChars(String s) {
      StringBuffer sb = new StringBuffer(s);
      int i = 0;

      for(int len = sb.length(); i < len; ++i) {
         if (sb.charAt(i) == '\'') {
            sb.insert(i, '\'');
            ++len;
            i += 2;
         }
      }

      return sb.toString();
   }

   public static synchronized String escapeAsTimestamp(Date date) {
      return "{ts '" + tsdf.format(date) + "'}";
   }

   public static SQLException toSQLException(Throwable t) {
      return toSQLException((String)null, t);
   }

   public static SQLException toSQLException(String msg, Throwable t) {
      return toSQLException(msg, (String)null, t);
   }

   public static SQLException toSQLException(String msg, String sqlState, Throwable t) {
      SQLException out;
      if (!(t instanceof SQLException)) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "Converting Throwable to SQLException...", t);
         }

         if (msg == null) {
            msg = "An SQLException was provoked by the following failure: " + t.toString();
         }

         if (VersionUtils.isAtLeastJavaVersion14()) {
            out = new SQLException(msg);
            out.initCause(t);
            return out;
         } else {
            return new SQLException(msg + System.getProperty("line.separator") + "[Cause: " + ThrowableUtils.extractStackTrace(t) + ']', sqlState);
         }
      } else {
         if (logger.isLoggable(MLevel.FINER)) {
            out = (SQLException)t;
            StringBuffer tmp = new StringBuffer(255);
            tmp.append("Attempted to convert SQLException to SQLException. Leaving it alone.");
            tmp.append(" [SQLState: ");
            tmp.append(out.getSQLState());
            tmp.append("; errorCode: ");
            tmp.append(out.getErrorCode());
            tmp.append(']');
            if (msg != null) {
               tmp.append(" Ignoring suggested message: '" + msg + "'.");
            }

            logger.log(MLevel.FINER, tmp.toString(), t);
            SQLException s2 = out;

            while((s2 = s2.getNextException()) != null) {
               logger.log(MLevel.FINER, "Nested SQLException or SQLWarning: ", s2);
            }
         }

         return (SQLException)t;
      }
   }

   static {
      logger = MLog.getLogger(SqlUtils.class);
      tsdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSS");
   }
}