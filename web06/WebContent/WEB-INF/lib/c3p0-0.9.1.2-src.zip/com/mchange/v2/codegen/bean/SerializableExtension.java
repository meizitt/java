package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.IndentedWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SerializableExtension implements GeneratorExtension {
   Set transientProperties;
   Map transientPropertyInitializers;

   public SerializableExtension(Set transientProperties, Map transientPropertyInitializers) {
      this.transientProperties = transientProperties;
      this.transientPropertyInitializers = transientPropertyInitializers;
   }

   public SerializableExtension() {
      this(Collections.EMPTY_SET, (Map)null);
   }

   public Collection extraGeneralImports() {
      return Collections.EMPTY_SET;
   }

   public Collection extraSpecificImports() {
      Set set = new HashSet();
      set.add("java.io.IOException");
      set.add("java.io.Serializable");
      set.add("java.io.ObjectOutputStream");
      set.add("java.io.ObjectInputStream");
      return set;
   }

   public Collection extraInterfaceNames() {
      Set set = new HashSet();
      set.add("Serializable");
      return set;
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      iw.println("private static final long serialVersionUID = 1;");
      iw.println("private static final short VERSION = 0x0001;");
      iw.println();
      iw.println("private void writeObject( ObjectOutputStream oos ) throws IOException");
      iw.println("{");
      iw.upIndent();
      iw.println("oos.writeShort( VERSION );");
      int i = 0;

      int len;
      Property prop;
      Class propType;
      for(len = props.length; i < len; ++i) {
         prop = props[i];
         if (!this.transientProperties.contains(prop.getName())) {
            propType = propTypes[i];
            if (propType != null && propType.isPrimitive()) {
               if (propType == Byte.TYPE) {
                  iw.println("oos.writeByte(" + prop.getName() + ");");
               } else if (propType == Character.TYPE) {
                  iw.println("oos.writeChar(" + prop.getName() + ");");
               } else if (propType == Short.TYPE) {
                  iw.println("oos.writeShort(" + prop.getName() + ");");
               } else if (propType == Integer.TYPE) {
                  iw.println("oos.writeInt(" + prop.getName() + ");");
               } else if (propType == Boolean.TYPE) {
                  iw.println("oos.writeBoolean(" + prop.getName() + ");");
               } else if (propType == Long.TYPE) {
                  iw.println("oos.writeLong(" + prop.getName() + ");");
               } else if (propType == Float.TYPE) {
                  iw.println("oos.writeFloat(" + prop.getName() + ");");
               } else if (propType == Double.TYPE) {
                  iw.println("oos.writeDouble(" + prop.getName() + ");");
               }
            } else {
               this.writeStoreObject(prop, propType, iw);
            }
         }
      }

      this.generateExtraSerWriteStatements(info, superclassType, props, propTypes, iw);
      iw.downIndent();
      iw.println("}");
      iw.println();
      iw.println("private void readObject( ObjectInputStream ois ) throws IOException, ClassNotFoundException");
      iw.println("{");
      iw.upIndent();
      iw.println("short version = ois.readShort();");
      iw.println("switch (version)");
      iw.println("{");
      iw.upIndent();
      iw.println("case VERSION:");
      iw.upIndent();
      i = 0;

      for(len = props.length; i < len; ++i) {
         prop = props[i];
         if (!this.transientProperties.contains(prop.getName())) {
            propType = propTypes[i];
            if (propType != null && propType.isPrimitive()) {
               if (propType == Byte.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readByte();");
               } else if (propType == Character.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readChar();");
               } else if (propType == Short.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readShort();");
               } else if (propType == Integer.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readInt();");
               } else if (propType == Boolean.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readBoolean();");
               } else if (propType == Long.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readLong();");
               } else if (propType == Float.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readFloat();");
               } else if (propType == Double.TYPE) {
                  iw.println("this." + prop.getName() + " = ois.readDouble();");
               }
            } else {
               this.writeUnstoreObject(prop, propType, iw);
            }
         } else {
            String initializer = (String)this.transientPropertyInitializers.get(prop.getName());
            if (initializer != null) {
               iw.println("this." + prop.getName() + " = " + initializer + ';');
            }
         }
      }

      this.generateExtraSerInitializers(info, superclassType, props, propTypes, iw);
      iw.println("break;");
      iw.downIndent();
      iw.println("default:");
      iw.upIndent();
      iw.println("throw new IOException(\"Unsupported Serialized Version: \" + version);");
      iw.downIndent();
      iw.downIndent();
      iw.println("}");
      iw.downIndent();
      iw.println("}");
   }

   protected void writeStoreObject(Property prop, Class propType, IndentedWriter iw) throws IOException {
      iw.println("oos.writeObject( " + prop.getName() + " );");
   }

   protected void writeUnstoreObject(Property prop, Class propType, IndentedWriter iw) throws IOException {
      iw.println("this." + prop.getName() + " = (" + prop.getSimpleTypeName() + ") ois.readObject();");
   }

   protected void generateExtraSerWriteStatements(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
   }

   protected void generateExtraSerInitializers(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
   }
}