package com.mchange.v2.cfg;

import com.mchange.v2.log.MLogger;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

public abstract class MultiPropertiesConfig {
   static final MultiPropertiesConfig EMPTY = new BasicMultiPropertiesConfig(new String[0]);
   static final String VM_CONFIG_RSRC_PATHS = "/com/mchange/v2/cfg/vmConfigResourcePaths.txt";
   static MultiPropertiesConfig vmConfig = null;

   public static MultiPropertiesConfig read(String[] resourcePath, MLogger logger) {
      return new BasicMultiPropertiesConfig(resourcePath, logger);
   }

   public static MultiPropertiesConfig read(String[] resourcePath) {
      return new BasicMultiPropertiesConfig(resourcePath);
   }

   public static MultiPropertiesConfig combine(MultiPropertiesConfig[] configs) {
      return new CombinedMultiPropertiesConfig(configs);
   }

   public static MultiPropertiesConfig readVmConfig(String[] defaultResources, String[] preemptingResources) {
      List l = new LinkedList();
      if (defaultResources != null) {
         l.add(read(defaultResources));
      }

      l.add(readVmConfig());
      if (preemptingResources != null) {
         l.add(read(preemptingResources));
      }

      return combine((MultiPropertiesConfig[])((MultiPropertiesConfig[])l.toArray(new MultiPropertiesConfig[l.size()])));
   }

   public static MultiPropertiesConfig readVmConfig() {
      if (vmConfig == null) {
         List rps = new ArrayList();
         BufferedReader br = null;

         try {
            InputStream is = MultiPropertiesConfig.class.getResourceAsStream("/com/mchange/v2/cfg/vmConfigResourcePaths.txt");
            if (is != null) {
               br = new BufferedReader(new InputStreamReader(is, "8859_1"));

               String rp;
               while((rp = br.readLine()) != null) {
                  rp = rp.trim();
                  if (!"".equals(rp) && !rp.startsWith("#")) {
                     rps.add(rp);
                  }
               }

               vmConfig = new BasicMultiPropertiesConfig((String[])((String[])rps.toArray(new String[rps.size()])));
            } else {
               System.err.println("com.mchange.v2.cfg.MultiPropertiesConfig: Resource path list could not be found at resource path: /com/mchange/v2/cfg/vmConfigResourcePaths.txt");
               System.err.println("com.mchange.v2.cfg.MultiPropertiesConfig: Using empty vmconfig.");
               vmConfig = EMPTY;
            }
         } catch (IOException var12) {
            var12.printStackTrace();
         } finally {
            try {
               if (br != null) {
                  br.close();
               }
            } catch (IOException var11) {
               var11.printStackTrace();
            }

         }
      }

      return vmConfig;
   }

   public boolean foundVmConfig() {
      return vmConfig != EMPTY;
   }

   public abstract String[] getPropertiesResourcePaths();

   public abstract Properties getPropertiesByResourcePath(String var1);

   public abstract Properties getPropertiesByPrefix(String var1);

   public abstract String getProperty(String var1);
}