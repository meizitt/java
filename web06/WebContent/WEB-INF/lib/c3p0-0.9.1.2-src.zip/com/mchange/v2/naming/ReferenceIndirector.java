package com.mchange.v2.naming;

import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.naming.ReferenceIndirector.ReferenceSerialized;
import com.mchange.v2.ser.IndirectlySerialized;
import com.mchange.v2.ser.Indirector;
import java.util.Hashtable;
import javax.naming.Name;
import javax.naming.Reference;
import javax.naming.Referenceable;

public class ReferenceIndirector implements Indirector {
   static final MLogger logger;
   Name name;
   Name contextName;
   Hashtable environmentProperties;

   public Name getName() {
      return this.name;
   }

   public void setName(Name name) {
      this.name = name;
   }

   public Name getNameContextName() {
      return this.contextName;
   }

   public void setNameContextName(Name contextName) {
      this.contextName = contextName;
   }

   public Hashtable getEnvironmentProperties() {
      return this.environmentProperties;
   }

   public void setEnvironmentProperties(Hashtable environmentProperties) {
      this.environmentProperties = environmentProperties;
   }

   public IndirectlySerialized indirectForm(Object orig) throws Exception {
      Reference ref = ((Referenceable)orig).getReference();
      return new ReferenceSerialized(ref, this.name, this.contextName, this.environmentProperties);
   }

   static {
      logger = MLog.getLogger(ReferenceIndirector.class);
   }
}