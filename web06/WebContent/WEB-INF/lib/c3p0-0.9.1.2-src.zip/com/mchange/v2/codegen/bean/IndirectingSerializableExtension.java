package com.mchange.v2.codegen.bean;

import com.mchange.v2.codegen.IndentedWriter;
import com.mchange.v2.ser.IndirectPolicy;
import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;

public class IndirectingSerializableExtension extends SerializableExtension {
   protected String findIndirectorExpr;
   protected String indirectorClassName;

   public IndirectingSerializableExtension(String indirectorClassName) {
      this.indirectorClassName = indirectorClassName;
      this.findIndirectorExpr = "new " + indirectorClassName + "()";
   }

   protected IndirectingSerializableExtension() {
   }

   public Collection extraSpecificImports() {
      Collection col = super.extraSpecificImports();
      col.add(this.indirectorClassName);
      col.add("com.mchange.v2.ser.IndirectlySerialized");
      col.add("com.mchange.v2.ser.Indirector");
      col.add("com.mchange.v2.ser.SerializableUtils");
      col.add("java.io.NotSerializableException");
      return col;
   }

   protected IndirectPolicy indirectingPolicy(Property prop, Class propType) {
      return Serializable.class.isAssignableFrom(propType) ? IndirectPolicy.DEFINITELY_DIRECT : IndirectPolicy.INDIRECT_ON_EXCEPTION;
   }

   protected void writeInitializeIndirector(Property prop, Class propType, IndentedWriter iw) throws IOException {
   }

   protected void writeExtraDeclarations(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
   }

   public void generate(ClassInfo info, Class superclassType, Property[] props, Class[] propTypes, IndentedWriter iw) throws IOException {
      super.generate(info, superclassType, props, propTypes, iw);
      this.writeExtraDeclarations(info, superclassType, props, propTypes, iw);
   }

   protected void writeStoreObject(Property prop, Class propType, IndentedWriter iw) throws IOException {
      IndirectPolicy policy = this.indirectingPolicy(prop, propType);
      if (policy == IndirectPolicy.DEFINITELY_INDIRECT) {
         this.writeIndirectStoreObject(prop, propType, iw);
      } else if (policy == IndirectPolicy.INDIRECT_ON_EXCEPTION) {
         iw.println("try");
         iw.println("{");
         iw.upIndent();
         iw.println("//test serialize");
         iw.println("SerializableUtils.toByteArray(" + prop.getName() + ");");
         super.writeStoreObject(prop, propType, iw);
         iw.downIndent();
         iw.println("}");
         iw.println("catch (NotSerializableException nse)");
         iw.println("{");
         iw.upIndent();
         this.writeIndirectStoreObject(prop, propType, iw);
         iw.downIndent();
         iw.println("}");
      } else {
         if (policy != IndirectPolicy.DEFINITELY_DIRECT) {
            throw new InternalError("indirectingPolicy() overridden to return unknown policy: " + policy);
         }

         super.writeStoreObject(prop, propType, iw);
      }

   }

   protected void writeIndirectStoreObject(Property prop, Class propType, IndentedWriter iw) throws IOException {
      iw.println("try");
      iw.println("{");
      iw.upIndent();
      iw.println("Indirector indirector = " + this.findIndirectorExpr + ';');
      this.writeInitializeIndirector(prop, propType, iw);
      iw.println("oos.writeObject( indirector.indirectForm( " + prop.getName() + " ) );");
      iw.downIndent();
      iw.println("}");
      iw.println("catch (IOException indirectionIOException)");
      iw.println("{ throw indirectionIOException; }");
      iw.println("catch (Exception indirectionOtherException)");
      iw.println("{ throw new IOException(\"Problem indirectly serializing " + prop.getName() + ": \" + indirectionOtherException.toString() ); }");
   }

   protected void writeUnstoreObject(Property prop, Class propType, IndentedWriter iw) throws IOException {
      IndirectPolicy policy = this.indirectingPolicy(prop, propType);
      if (policy != IndirectPolicy.DEFINITELY_INDIRECT && policy != IndirectPolicy.INDIRECT_ON_EXCEPTION) {
         if (policy != IndirectPolicy.DEFINITELY_DIRECT) {
            throw new InternalError("indirectingPolicy() overridden to return unknown policy: " + policy);
         }

         super.writeUnstoreObject(prop, propType, iw);
      } else {
         iw.println("Object o = ois.readObject();");
         iw.println("if (o instanceof IndirectlySerialized) o = ((IndirectlySerialized) o).getObject();");
         iw.println("this." + prop.getName() + " = (" + prop.getSimpleTypeName() + ") o;");
      }

   }
}