package com.mchange.v2.ser;

import com.mchange.v1.io.InputStreamUtils;
import com.mchange.v1.io.OutputStreamUtils;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public final class SerializableUtils {
   static final MLogger logger;

   public static byte[] toByteArray(Object obj) throws NotSerializableException {
      return serializeToByteArray(obj);
   }

   public static byte[] toByteArray(Object obj, Indirector indirector, IndirectPolicy policy) throws NotSerializableException {
      try {
         if (policy == IndirectPolicy.DEFINITELY_INDIRECT) {
            if (indirector == null) {
               throw new IllegalArgumentException("null indirector is not consistent with " + policy);
            } else {
               IndirectlySerialized indirect = indirector.indirectForm(obj);
               return toByteArray(indirect);
            }
         } else if (policy == IndirectPolicy.INDIRECT_ON_EXCEPTION) {
            if (indirector == null) {
               throw new IllegalArgumentException("null indirector is not consistent with " + policy);
            } else {
               try {
                  return toByteArray(obj);
               } catch (NotSerializableException var4) {
                  return toByteArray(obj, indirector, IndirectPolicy.DEFINITELY_INDIRECT);
               }
            }
         } else if (policy == IndirectPolicy.DEFINITELY_DIRECT) {
            return toByteArray(obj);
         } else {
            throw new InternalError("unknown indirecting policy: " + policy);
         }
      } catch (NotSerializableException var5) {
         throw var5;
      } catch (Exception var6) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while serializing an Object to a byte[] with an Indirector.", var6);
         }

         throw new NotSerializableException(var6.toString());
      }
   }

   
   public static byte[] serializeToByteArray(Object obj) throws NotSerializableException {
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
         ObjectOutputStream out = new ObjectOutputStream(baos);
         out.writeObject(obj);
         return baos.toByteArray();
      } catch (NotSerializableException var3) {
         var3.fillInStackTrace();
         throw var3;
      } catch (IOException var4) {
         if (logger.isLoggable(MLevel.SEVERE)) {
            logger.log(MLevel.SEVERE, "An IOException occurred while writing into a ByteArrayOutputStream?!?", var4);
         }

         throw new Error("IOException writing to a byte array!");
      }
   }

   public static Object fromByteArray(byte[] bytes) throws IOException, ClassNotFoundException {
      Object out = deserializeFromByteArray(bytes);
      return out instanceof IndirectlySerialized ? ((IndirectlySerialized)out).getObject() : out;
   }

   public static Object fromByteArray(byte[] bytes, boolean ignore_indirects) throws IOException, ClassNotFoundException {
      return ignore_indirects ? deserializeFromByteArray(bytes) : fromByteArray(bytes);
   }

   
   public static Object deserializeFromByteArray(byte[] bytes) throws IOException, ClassNotFoundException {
      ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bytes));
      return in.readObject();
   }

   public static Object testSerializeDeserialize(Object o) throws IOException, ClassNotFoundException {
      return deepCopy(o);
   }

   public static Object deepCopy(Object o) throws IOException, ClassNotFoundException {
      byte[] bytes = serializeToByteArray(o);
      return deserializeFromByteArray(bytes);
   }

   public static final Object unmarshallObjectFromFile(File file) throws IOException, ClassNotFoundException {
      ObjectInputStream in = null;

      Object var2;
      try {
         in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
         var2 = in.readObject();
      } finally {
         InputStreamUtils.attemptClose(in);
      }

      return var2;
   }

   public static final void marshallObjectToFile(Object o, File file) throws IOException {
      ObjectOutputStream out = null;

      try {
         out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
         out.writeObject(o);
      } finally {
         OutputStreamUtils.attemptClose(out);
      }

   }

   static {
      logger = MLog.getLogger(SerializableUtils.class);
   }
}