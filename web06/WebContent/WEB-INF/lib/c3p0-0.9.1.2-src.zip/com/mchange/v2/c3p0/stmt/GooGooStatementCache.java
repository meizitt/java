package com.mchange.v2.c3p0.stmt;

import com.mchange.v1.db.sql.StatementUtils;
import com.mchange.v2.async.AsynchronousRunner;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.1;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.1StatementCloseTask;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.1StmtAcquireTask;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.ConnectionStatementManager;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache.KeyRec;
import com.mchange.v2.io.IndentedWriter;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.sql.SqlUtils;
import com.mchange.v2.util.ResourceClosedException;
import java.io.IOException;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

public abstract class GooGooStatementCache {
   private static final MLogger logger;
   private static final int DESTROY_NEVER = 0;
   private static final int DESTROY_IF_CHECKED_IN = 1;
   private static final int DESTROY_IF_CHECKED_OUT = 2;
   private static final int DESTROY_ALWAYS = 3;
   ConnectionStatementManager cxnStmtMgr;
   HashMap stmtToKey = new HashMap();
   HashMap keyToKeyRec = new HashMap();
   HashSet checkedOut = new HashSet();
   AsynchronousRunner blockingTaskAsyncRunner;
   HashSet removalPending = new HashSet();

   public GooGooStatementCache(AsynchronousRunner blockingTaskAsyncRunner) {
      this.blockingTaskAsyncRunner = blockingTaskAsyncRunner;
      this.cxnStmtMgr = this.createConnectionStatementManager();
   }

   public synchronized int getNumStatements() {
      return this.isClosed() ? -1 : this.countCachedStatements();
   }

   public synchronized int getNumStatementsCheckedOut() {
      return this.isClosed() ? -1 : this.checkedOut.size();
   }

   public synchronized int getNumConnectionsWithCachedStatements() {
      return this.isClosed() ? -1 : this.cxnStmtMgr.getNumConnectionsWithCachedStatements();
   }

   public synchronized String dumpStatementCacheStatus() {
      if (this.isClosed()) {
         return this + "status: Closed.";
      } else {
         StringWriter sw = new StringWriter(2048);
         IndentedWriter iw = new IndentedWriter(sw);

         try {
            iw.print(this);
            iw.println(" status:");
            iw.upIndent();
            iw.println("core stats:");
            iw.upIndent();
            iw.print("num cached statements: ");
            iw.println(this.countCachedStatements());
            iw.print("num cached statements in use: ");
            iw.println(this.checkedOut.size());
            iw.print("num connections with cached statements: ");
            iw.println(this.cxnStmtMgr.getNumConnectionsWithCachedStatements());
            iw.downIndent();
            iw.println("cached statement dump:");
            iw.upIndent();
            Iterator ii = this.cxnStmtMgr.connectionSet().iterator();

            while(ii.hasNext()) {
               Connection pcon = (Connection)ii.next();
               iw.print(pcon);
               iw.println(':');
               iw.upIndent();
               Iterator jj = this.cxnStmtMgr.statementSet(pcon).iterator();

               while(jj.hasNext()) {
                  iw.println(jj.next());
               }

               iw.downIndent();
            }

            iw.downIndent();
            iw.downIndent();
            return sw.toString();
         } catch (IOException var6) {
            if (logger.isLoggable(MLevel.SEVERE)) {
               logger.log(MLevel.SEVERE, "Huh? We've seen an IOException writing to s StringWriter?!", var6);
            }

            return var6.toString();
         }
      }
   }

   abstract ConnectionStatementManager createConnectionStatementManager();

   public synchronized Object checkoutStatement(Connection physicalConnection, Method stmtProducingMethod, Object[] args) throws SQLException, ResourceClosedException {
      try {
         Object out = null;
         StatementCacheKey key = StatementCacheKey.find(physicalConnection, stmtProducingMethod, args);
         LinkedList l = this.checkoutQueue(key);
         if (l != null && !l.isEmpty()) {
            logger.finest(this.getClass().getName() + " ----> CACHE HIT");
            out = l.get(0);
            l.remove(0);
            if (!this.checkedOut.add(out)) {
               throw new RuntimeException("Internal inconsistency: Checking out a statement marked as already checked out!");
            }

            this.removeStatementFromDeathmarches(out, physicalConnection);
         } else {
            out = this.acquireStatement(physicalConnection, stmtProducingMethod, args);
            if (this.prepareAssimilateNewStatement(physicalConnection)) {
               this.assimilateNewCheckedOutStatement(key, physicalConnection, out);
            }
         }

         if (logger.isLoggable(MLevel.FINEST)) {
            logger.finest("checkoutStatement: " + this.statsString());
         }

         return out;
      } catch (NullPointerException var7) {
         if (this.checkedOut == null) {
            if (logger.isLoggable(MLevel.FINE)) {
               logger.log(MLevel.FINE, "A client attempted to work with a closed Statement cache, provoking a NullPointerException. c3p0 recovers, but this should be rare.", var7);
            }

            throw new ResourceClosedException(var7);
         } else {
            throw var7;
         }
      }
   }

   public synchronized void checkinStatement(Object pstmt) throws SQLException {
      if (this.checkedOut == null) {
         this.synchronousDestroyStatement(pstmt);
      } else if (!this.checkedOut.remove(pstmt)) {
         if (!this.ourResource(pstmt)) {
            this.destroyStatement(pstmt);
         }

      } else {
         try {
            this.refreshStatement((PreparedStatement)pstmt);
         } catch (Exception var4) {
            if (logger.isLoggable(MLevel.INFO)) {
               logger.log(MLevel.INFO, "Problem with checked-in Statement, discarding.", var4);
            }

            this.checkedOut.add(pstmt);
            this.removeStatement(pstmt, 3);
            return;
         }

         StatementCacheKey key = (StatementCacheKey)this.stmtToKey.get(pstmt);
         if (key == null) {
            throw new RuntimeException("Internal inconsistency: A checked-out statement has no key associated with it!");
         } else {
            LinkedList l = this.checkoutQueue(key);
            l.add(pstmt);
            this.addStatementToDeathmarches(pstmt, key.physicalConnection);
            if (logger.isLoggable(MLevel.FINEST)) {
               logger.finest("checkinStatement(): " + this.statsString());
            }

         }
      }
   }

   public synchronized void checkinAll(Connection pcon) throws SQLException {
      Set stmtSet = this.cxnStmtMgr.statementSet(pcon);
      if (stmtSet != null) {
         Iterator ii = stmtSet.iterator();

         while(ii.hasNext()) {
            Object stmt = ii.next();
            if (this.checkedOut.contains(stmt)) {
               this.checkinStatement(stmt);
            }
         }
      }

      if (logger.isLoggable(MLevel.FINEST)) {
         logger.log(MLevel.FINEST, "checkinAll(): " + this.statsString());
      }

   }

   public void closeAll(Connection pcon) throws SQLException {
      if (!this.isClosed()) {
         if (logger.isLoggable(MLevel.FINEST)) {
            logger.log(MLevel.FINEST, "ENTER METHOD: closeAll( " + pcon + " )! -- num_connections: " + this.cxnStmtMgr.getNumConnectionsWithCachedStatements());
         }

         Set stmtSet = null;
         synchronized(this) {
            Set cSet = this.cxnStmtMgr.statementSet(pcon);
            if (cSet != null) {
               stmtSet = new HashSet(cSet);
               Iterator ii = stmtSet.iterator();

               while(ii.hasNext()) {
                  Object stmt = ii.next();
                  this.removeStatement(stmt, 0);
               }
            }
         }

         if (stmtSet != null) {
            Iterator ii = stmtSet.iterator();

            while(ii.hasNext()) {
               Object stmt = ii.next();
               this.synchronousDestroyStatement(stmt);
            }
         }

         if (logger.isLoggable(MLevel.FINEST)) {
            logger.finest("closeAll(): " + this.statsString());
         }
      }

   }

   public synchronized void close() throws SQLException {
      if (!this.isClosed()) {
         Iterator ii = this.stmtToKey.keySet().iterator();

         while(ii.hasNext()) {
            this.synchronousDestroyStatement(ii.next());
         }

         this.cxnStmtMgr = null;
         this.stmtToKey = null;
         this.keyToKeyRec = null;
         this.checkedOut = null;
      } else if (logger.isLoggable(MLevel.FINE)) {
         logger.log(MLevel.FINE, this + ": duplicate call to close() [not harmful! -- debug only!]", new Exception("DUPLICATE CLOSE DEBUG STACK TRACE."));
      }

   }

   public synchronized boolean isClosed() {
      return this.cxnStmtMgr == null;
   }

   private void destroyStatement(Object pstmt) {
      Runnable r = new 1StatementCloseTask(this, pstmt);
      this.blockingTaskAsyncRunner.postRunnable(r);
   }

   private void synchronousDestroyStatement(Object pstmt) {
      StatementUtils.attemptClose((PreparedStatement)pstmt);
   }

   abstract boolean prepareAssimilateNewStatement(Connection var1);

   abstract void addStatementToDeathmarches(Object var1, Connection var2);

   abstract void removeStatementFromDeathmarches(Object var1, Connection var2);

   final int countCachedStatements() {
      return this.stmtToKey.size();
   }

   private void assimilateNewCheckedOutStatement(StatementCacheKey key, Connection pConn, Object ps) {
      this.stmtToKey.put(ps, key);
      HashSet ks = this.keySet(key);
      if (ks == null) {
         this.keyToKeyRec.put(key, new KeyRec((1)null));
      } else {
         if (logger.isLoggable(MLevel.INFO)) {
            logger.info("Multiply prepared statement! " + key.stmtText);
         }

         if (logger.isLoggable(MLevel.FINE)) {
            logger.fine("(The same statement has already been prepared by this Connection, and that other instance has not yet been closed, so the statement pool has to prepare a second PreparedStatement object rather than reusing the previously-cached Statement. The new Statement will be cached, in case you frequently need multiple copies of this Statement.)");
         }
      }

      this.keySet(key).add(ps);
      this.cxnStmtMgr.addStatementForConnection(ps, pConn);
      if (logger.isLoggable(MLevel.FINEST)) {
         logger.finest("cxnStmtMgr.statementSet( " + pConn + " ).size(): " + this.cxnStmtMgr.statementSet(pConn).size());
      }

      this.checkedOut.add(ps);
   }

   private void removeStatement(Object ps, int destruction_policy) {
      HashSet var3 = this.removalPending;
      synchronized(this.removalPending) {
         if (this.removalPending.contains(ps)) {
            return;
         }

         this.removalPending.add(ps);
      }

      StatementCacheKey sck = (StatementCacheKey)this.stmtToKey.remove(ps);
      this.removeFromKeySet(sck, ps);
      Connection pConn = sck.physicalConnection;
      boolean checked_in = !this.checkedOut.contains(ps);
      if (checked_in) {
         this.removeStatementFromDeathmarches(ps, pConn);
         this.removeFromCheckoutQueue(sck, ps);
         if ((destruction_policy & 1) != 0) {
            this.destroyStatement(ps);
         }
      } else {
         this.checkedOut.remove(ps);
         if ((destruction_policy & 2) != 0) {
            this.destroyStatement(ps);
         }
      }

      boolean check = this.cxnStmtMgr.removeStatementForConnection(ps, pConn);
      if (!check && logger.isLoggable(MLevel.WARNING)) {
         logger.log(MLevel.WARNING, this + " removed a statement that apparently wasn't in a statement set!!!", new Exception("LOG STACK TRACE"));
      }

      HashSet var7 = this.removalPending;
      synchronized(this.removalPending) {
         this.removalPending.remove(ps);
      }
   }

   private Object acquireStatement(Connection pConn, Method stmtProducingMethod, Object[] args) throws SQLException {
      try {
         Object[] outHolder = new Object[1];
         SQLException[] exceptionHolder = new SQLException[1];
         Runnable r = new 1StmtAcquireTask(this, outHolder, stmtProducingMethod, pConn, args, exceptionHolder);
         this.blockingTaskAsyncRunner.postRunnable(r);

         while(outHolder[0] == null && exceptionHolder[0] == null) {
            this.wait();
         }

         if (exceptionHolder[0] != null) {
            throw exceptionHolder[0];
         } else {
            Object out = outHolder[0];
            return out;
         }
      } catch (InterruptedException var8) {
         throw SqlUtils.toSQLException(var8);
      }
   }

   private KeyRec keyRec(StatementCacheKey key) {
      return (KeyRec)this.keyToKeyRec.get(key);
   }

   private HashSet keySet(StatementCacheKey key) {
      KeyRec rec = this.keyRec(key);
      return rec == null ? null : rec.allStmts;
   }

   private boolean removeFromKeySet(StatementCacheKey key, Object pstmt) {
      HashSet stmtSet = this.keySet(key);
      boolean out = stmtSet.remove(pstmt);
      if (stmtSet.isEmpty() && this.checkoutQueue(key).isEmpty()) {
         this.keyToKeyRec.remove(key);
      }

      return out;
   }

   private LinkedList checkoutQueue(StatementCacheKey key) {
      KeyRec rec = this.keyRec(key);
      return rec == null ? null : rec.checkoutQueue;
   }

   private boolean removeFromCheckoutQueue(StatementCacheKey key, Object pstmt) {
      LinkedList q = this.checkoutQueue(key);
      boolean out = q.remove(pstmt);
      if (q.isEmpty() && this.keySet(key).isEmpty()) {
         this.keyToKeyRec.remove(key);
      }

      return out;
   }

   private boolean ourResource(Object ps) {
      return this.stmtToKey.keySet().contains(ps);
   }

   private void refreshStatement(PreparedStatement ps) throws Exception {
      ps.clearParameters();
   }

   private void printStats() {
      int total_size = this.countCachedStatements();
      int checked_out_size = this.checkedOut.size();
      int num_connections = this.cxnStmtMgr.getNumConnectionsWithCachedStatements();
      int num_keys = this.keyToKeyRec.size();
      System.err.print(this.getClass().getName() + " stats -- ");
      System.err.print("total size: " + total_size);
      System.err.print("; checked out: " + checked_out_size);
      System.err.print("; num connections: " + num_connections);
      System.err.println("; num keys: " + num_keys);
   }

   private String statsString() {
      int total_size = this.countCachedStatements();
      int checked_out_size = this.checkedOut.size();
      int num_connections = this.cxnStmtMgr.getNumConnectionsWithCachedStatements();
      int num_keys = this.keyToKeyRec.size();
      StringBuffer sb = new StringBuffer(255);
      sb.append(this.getClass().getName());
      sb.append(" stats -- ");
      sb.append("total size: ");
      sb.append(total_size);
      sb.append("; checked out: ");
      sb.append(checked_out_size);
      sb.append("; num connections: ");
      sb.append(num_connections);
      sb.append("; num keys: ");
      sb.append(num_keys);
      return sb.toString();
   }

   static {
      logger = MLog.getLogger(GooGooStatementCache.class);
   }
}