package com.mchange.v2.c3p0.jboss;

import java.beans.PropertyVetoException;
import java.sql.SQLException;
import javax.naming.NamingException;

public interface C3P0PooledDataSourceMBean {
   void setJndiName(String var1) throws NamingException;

   String getJndiName();

   String getDescription();

   void setDescription(String var1) throws NamingException;

   String getDriverClass();

   void setDriverClass(String var1) throws PropertyVetoException, NamingException;

   String getJdbcUrl();

   void setJdbcUrl(String var1) throws NamingException;

   String getUser();

   void setUser(String var1) throws NamingException;

   String getPassword();

   void setPassword(String var1) throws NamingException;

   int getUnreturnedConnectionTimeout();

   void setUnreturnedConnectionTimeout(int var1) throws NamingException;

   boolean isDebugUnreturnedConnectionStackTraces();

   void setDebugUnreturnedConnectionStackTraces(boolean var1) throws NamingException;

   String getConnectionCustomizerClassName();

   void setConnectionCustomizerClassName(String var1) throws NamingException;

   int getMaxConnectionAge();

   void setMaxConnectionAge(int var1) throws NamingException;

   int getMaxIdleTimeExcessConnections();

   void setMaxIdleTimeExcessConnections(int var1) throws NamingException;

   int getMaxAdministrativeTaskTime();

   void setMaxAdministrativeTaskTime(int var1) throws NamingException;

   int getCheckoutTimeout();

   void setCheckoutTimeout(int var1) throws NamingException;

   int getAcquireIncrement();

   void setAcquireIncrement(int var1) throws NamingException;

   int getAcquireRetryAttempts();

   void setAcquireRetryAttempts(int var1) throws NamingException;

   int getAcquireRetryDelay();

   void setAcquireRetryDelay(int var1) throws NamingException;

   boolean isAutoCommitOnClose();

   void setAutoCommitOnClose(boolean var1) throws NamingException;

   String getConnectionTesterClassName();

   void setConnectionTesterClassName(String var1) throws PropertyVetoException, NamingException;

   String getAutomaticTestTable();

   void setAutomaticTestTable(String var1) throws NamingException;

   boolean isForceIgnoreUnresolvedTransactions();

   void setForceIgnoreUnresolvedTransactions(boolean var1) throws NamingException;

   int getIdleConnectionTestPeriod();

   void setIdleConnectionTestPeriod(int var1) throws NamingException;

   int getInitialPoolSize();

   void setInitialPoolSize(int var1) throws NamingException;

   int getMaxIdleTime();

   void setMaxIdleTime(int var1) throws NamingException;

   int getMaxPoolSize();

   void setMaxPoolSize(int var1) throws NamingException;

   int getMaxStatements();

   void setMaxStatements(int var1) throws NamingException;

   int getMaxStatementsPerConnection();

   void setMaxStatementsPerConnection(int var1) throws NamingException;

   int getMinPoolSize();

   void setMinPoolSize(int var1) throws NamingException;

   int getPropertyCycle();

   void setPropertyCycle(int var1) throws NamingException;

   boolean isBreakAfterAcquireFailure();

   void setBreakAfterAcquireFailure(boolean var1) throws NamingException;

   boolean isTestConnectionOnCheckout();

   void setTestConnectionOnCheckout(boolean var1) throws NamingException;

   boolean isTestConnectionOnCheckin();

   void setTestConnectionOnCheckin(boolean var1) throws NamingException;

   boolean isUsesTraditionalReflectiveProxies();

   void setUsesTraditionalReflectiveProxies(boolean var1) throws NamingException;

   String getPreferredTestQuery();

   void setPreferredTestQuery(String var1) throws NamingException;

   int getNumHelperThreads();

   void setNumHelperThreads(int var1) throws NamingException;

   String getFactoryClassLocation();

   void setFactoryClassLocation(String var1) throws NamingException;

   int getNumUserPools() throws SQLException;

   int getNumConnectionsDefaultUser() throws SQLException;

   int getNumIdleConnectionsDefaultUser() throws SQLException;

   int getNumBusyConnectionsDefaultUser() throws SQLException;

   int getNumUnclosedOrphanedConnectionsDefaultUser() throws SQLException;

   int getNumConnections(String var1, String var2) throws SQLException;

   int getNumIdleConnections(String var1, String var2) throws SQLException;

   int getNumBusyConnections(String var1, String var2) throws SQLException;

   int getNumUnclosedOrphanedConnections(String var1, String var2) throws SQLException;

   float getEffectivePropertyCycle(String var1, String var2) throws SQLException;

   int getNumBusyConnectionsAllUsers() throws SQLException;

   int getNumIdleConnectionsAllUsers() throws SQLException;

   int getNumConnectionsAllUsers() throws SQLException;

   int getNumUnclosedOrphanedConnectionsAllUsers() throws SQLException;

   float getEffectivePropertyCycleDefaultUser() throws SQLException;

   void softResetDefaultUser() throws SQLException;

   void softReset(String var1, String var2) throws SQLException;

   void softResetAllUsers() throws SQLException;

   void hardReset() throws SQLException;

   void close() throws SQLException;

   void create() throws Exception;

   void start() throws Exception;

   void stop();

   void destroy();
}