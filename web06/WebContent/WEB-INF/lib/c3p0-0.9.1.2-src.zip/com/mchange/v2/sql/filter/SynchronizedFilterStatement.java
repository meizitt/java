package com.mchange.v2.sql.filter;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

public abstract class SynchronizedFilterStatement implements Statement {
   protected Statement inner;

   public SynchronizedFilterStatement(Statement inner) {
      this.inner = inner;
   }

   public SynchronizedFilterStatement() {
   }

   public synchronized void setInner(Statement inner) {
      this.inner = inner;
   }

   public synchronized Statement getInner() {
      return this.inner;
   }

   public synchronized SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public synchronized void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public synchronized void setFetchDirection(int a) throws SQLException {
      this.inner.setFetchDirection(a);
   }

   public synchronized int getFetchDirection() throws SQLException {
      return this.inner.getFetchDirection();
   }

   public synchronized void setFetchSize(int a) throws SQLException {
      this.inner.setFetchSize(a);
   }

   public synchronized int getFetchSize() throws SQLException {
      return this.inner.getFetchSize();
   }

   public synchronized int getResultSetHoldability() throws SQLException {
      return this.inner.getResultSetHoldability();
   }

   public synchronized ResultSet executeQuery(String a) throws SQLException {
      return this.inner.executeQuery(a);
   }

   public synchronized int executeUpdate(String a, int b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public synchronized int executeUpdate(String a, String[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public synchronized int executeUpdate(String a, int[] b) throws SQLException {
      return this.inner.executeUpdate(a, b);
   }

   public synchronized int executeUpdate(String a) throws SQLException {
      return this.inner.executeUpdate(a);
   }

   public synchronized int getMaxFieldSize() throws SQLException {
      return this.inner.getMaxFieldSize();
   }

   public synchronized void setMaxFieldSize(int a) throws SQLException {
      this.inner.setMaxFieldSize(a);
   }

   public synchronized int getMaxRows() throws SQLException {
      return this.inner.getMaxRows();
   }

   public synchronized void setMaxRows(int a) throws SQLException {
      this.inner.setMaxRows(a);
   }

   public synchronized void setEscapeProcessing(boolean a) throws SQLException {
      this.inner.setEscapeProcessing(a);
   }

   public synchronized int getQueryTimeout() throws SQLException {
      return this.inner.getQueryTimeout();
   }

   public synchronized void setQueryTimeout(int a) throws SQLException {
      this.inner.setQueryTimeout(a);
   }

   public synchronized void setCursorName(String a) throws SQLException {
      this.inner.setCursorName(a);
   }

   public synchronized ResultSet getResultSet() throws SQLException {
      return this.inner.getResultSet();
   }

   public synchronized int getUpdateCount() throws SQLException {
      return this.inner.getUpdateCount();
   }

   public synchronized boolean getMoreResults() throws SQLException {
      return this.inner.getMoreResults();
   }

   public synchronized boolean getMoreResults(int a) throws SQLException {
      return this.inner.getMoreResults(a);
   }

   public synchronized int getResultSetConcurrency() throws SQLException {
      return this.inner.getResultSetConcurrency();
   }

   public synchronized int getResultSetType() throws SQLException {
      return this.inner.getResultSetType();
   }

   public synchronized void addBatch(String a) throws SQLException {
      this.inner.addBatch(a);
   }

   public synchronized void clearBatch() throws SQLException {
      this.inner.clearBatch();
   }

   public synchronized int[] executeBatch() throws SQLException {
      return this.inner.executeBatch();
   }

   public synchronized ResultSet getGeneratedKeys() throws SQLException {
      return this.inner.getGeneratedKeys();
   }

   public synchronized void close() throws SQLException {
      this.inner.close();
   }

   public synchronized boolean execute(String a, int b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public synchronized boolean execute(String a) throws SQLException {
      return this.inner.execute(a);
   }

   public synchronized boolean execute(String a, int[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public synchronized boolean execute(String a, String[] b) throws SQLException {
      return this.inner.execute(a, b);
   }

   public synchronized Connection getConnection() throws SQLException {
      return this.inner.getConnection();
   }

   public synchronized void cancel() throws SQLException {
      this.inner.cancel();
   }
}