package com.mchange.v2.lang;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class Coerce {
   static final Set CAN_COERCE;

   public static boolean canCoerce(Class cl) {
      return CAN_COERCE.contains(cl);
   }

   public static boolean canCoerce(Object o) {
      return canCoerce(o.getClass());
   }

   public static int toInt(String s) {
      try {
         return Integer.parseInt(s);
      } catch (NumberFormatException var2) {
         return (int)Double.parseDouble(s);
      }
   }

   public static long toLong(String s) {
      try {
         return Long.parseLong(s);
      } catch (NumberFormatException var2) {
         return (long)Double.parseDouble(s);
      }
   }

   public static float toFloat(String s) {
      return Float.parseFloat(s);
   }

   public static double toDouble(String s) {
      return Double.parseDouble(s);
   }

   public static byte toByte(String s) {
      return (byte)toInt(s);
   }

   public static short toShort(String s) {
      return (short)toInt(s);
   }

   public static boolean toBoolean(String s) {
      return Boolean.valueOf(s);
   }

   public static char toChar(String s) {
      s = s.trim();
      return s.length() == 1 ? s.charAt(0) : (char)toInt(s);
   }

   public static Object toObject(String s, Class type) {
      if (type == Byte.TYPE) {
         type = Byte.class;
      } else if (type == Boolean.TYPE) {
         type = Boolean.class;
      } else if (type == Character.TYPE) {
         type = Character.class;
      } else if (type == Short.TYPE) {
         type = Short.class;
      } else if (type == Integer.TYPE) {
         type = Integer.class;
      } else if (type == Long.TYPE) {
         type = Long.class;
      } else if (type == Float.TYPE) {
         type = Float.class;
      } else if (type == Double.TYPE) {
         type = Double.class;
      }

      if (type == String.class) {
         return s;
      } else if (type == Byte.class) {
         return new Byte(toByte(s));
      } else if (type == Boolean.class) {
         return Boolean.valueOf(s);
      } else if (type == Character.class) {
         return new Character(toChar(s));
      } else if (type == Short.class) {
         return new Short(toShort(s));
      } else if (type == Integer.class) {
         return new Integer(s);
      } else if (type == Long.class) {
         return new Long(s);
      } else if (type == Float.class) {
         return new Float(s);
      } else if (type == Double.class) {
         return new Double(s);
      } else {
         throw new IllegalArgumentException("Cannot coerce to type: " + type.getName());
      }
   }

   static {
      Class[] classes = new Class[]{Byte.TYPE, Boolean.TYPE, Character.TYPE, Short.TYPE, Integer.TYPE, Long.TYPE, Float.TYPE, Double.TYPE, String.class, Byte.class, Boolean.class, Character.class, Short.class, Integer.class, Long.class, Float.class, Double.class};
      Set tmp = new HashSet();
      tmp.addAll(Arrays.asList(classes));
      CAN_COERCE = Collections.unmodifiableSet(tmp);
   }
}