package com.mchange.v2.sql.filter;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Map;

public abstract class FilterResultSet implements ResultSet {
   protected ResultSet inner;

   public FilterResultSet(ResultSet inner) {
      this.inner = inner;
   }

   public FilterResultSet() {
   }

   public void setInner(ResultSet inner) {
      this.inner = inner;
   }

   public ResultSet getInner() {
      return this.inner;
   }

   public ResultSetMetaData getMetaData() throws SQLException {
      return this.inner.getMetaData();
   }

   public SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public boolean wasNull() throws SQLException {
      return this.inner.wasNull();
   }

   public BigDecimal getBigDecimal(int a) throws SQLException {
      return this.inner.getBigDecimal(a);
   }

   public BigDecimal getBigDecimal(String a, int b) throws SQLException {
      return this.inner.getBigDecimal(a, b);
   }

   public BigDecimal getBigDecimal(int a, int b) throws SQLException {
      return this.inner.getBigDecimal(a, b);
   }

   public BigDecimal getBigDecimal(String a) throws SQLException {
      return this.inner.getBigDecimal(a);
   }

   public Timestamp getTimestamp(int a) throws SQLException {
      return this.inner.getTimestamp(a);
   }

   public Timestamp getTimestamp(String a) throws SQLException {
      return this.inner.getTimestamp(a);
   }

   public Timestamp getTimestamp(int a, Calendar b) throws SQLException {
      return this.inner.getTimestamp(a, b);
   }

   public Timestamp getTimestamp(String a, Calendar b) throws SQLException {
      return this.inner.getTimestamp(a, b);
   }

   public InputStream getAsciiStream(String a) throws SQLException {
      return this.inner.getAsciiStream(a);
   }

   public InputStream getAsciiStream(int a) throws SQLException {
      return this.inner.getAsciiStream(a);
   }

   public InputStream getUnicodeStream(String a) throws SQLException {
      return this.inner.getUnicodeStream(a);
   }

   public InputStream getUnicodeStream(int a) throws SQLException {
      return this.inner.getUnicodeStream(a);
   }

   public InputStream getBinaryStream(int a) throws SQLException {
      return this.inner.getBinaryStream(a);
   }

   public InputStream getBinaryStream(String a) throws SQLException {
      return this.inner.getBinaryStream(a);
   }

   public String getCursorName() throws SQLException {
      return this.inner.getCursorName();
   }

   public Reader getCharacterStream(int a) throws SQLException {
      return this.inner.getCharacterStream(a);
   }

   public Reader getCharacterStream(String a) throws SQLException {
      return this.inner.getCharacterStream(a);
   }

   public boolean isBeforeFirst() throws SQLException {
      return this.inner.isBeforeFirst();
   }

   public boolean isAfterLast() throws SQLException {
      return this.inner.isAfterLast();
   }

   public boolean isFirst() throws SQLException {
      return this.inner.isFirst();
   }

   public boolean isLast() throws SQLException {
      return this.inner.isLast();
   }

   public void beforeFirst() throws SQLException {
      this.inner.beforeFirst();
   }

   public void afterLast() throws SQLException {
      this.inner.afterLast();
   }

   public boolean absolute(int a) throws SQLException {
      return this.inner.absolute(a);
   }

   public void setFetchDirection(int a) throws SQLException {
      this.inner.setFetchDirection(a);
   }

   public int getFetchDirection() throws SQLException {
      return this.inner.getFetchDirection();
   }

   public void setFetchSize(int a) throws SQLException {
      this.inner.setFetchSize(a);
   }

   public int getFetchSize() throws SQLException {
      return this.inner.getFetchSize();
   }

   public int getConcurrency() throws SQLException {
      return this.inner.getConcurrency();
   }

   public boolean rowUpdated() throws SQLException {
      return this.inner.rowUpdated();
   }

   public boolean rowInserted() throws SQLException {
      return this.inner.rowInserted();
   }

   public boolean rowDeleted() throws SQLException {
      return this.inner.rowDeleted();
   }

   public void updateNull(int a) throws SQLException {
      this.inner.updateNull(a);
   }

   public void updateNull(String a) throws SQLException {
      this.inner.updateNull(a);
   }

   public void updateBoolean(int a, boolean b) throws SQLException {
      this.inner.updateBoolean(a, b);
   }

   public void updateBoolean(String a, boolean b) throws SQLException {
      this.inner.updateBoolean(a, b);
   }

   public void updateByte(int a, byte b) throws SQLException {
      this.inner.updateByte(a, b);
   }

   public void updateByte(String a, byte b) throws SQLException {
      this.inner.updateByte(a, b);
   }

   public void updateShort(int a, short b) throws SQLException {
      this.inner.updateShort(a, b);
   }

   public void updateShort(String a, short b) throws SQLException {
      this.inner.updateShort(a, b);
   }

   public void updateInt(String a, int b) throws SQLException {
      this.inner.updateInt(a, b);
   }

   public void updateInt(int a, int b) throws SQLException {
      this.inner.updateInt(a, b);
   }

   public void updateLong(int a, long b) throws SQLException {
      this.inner.updateLong(a, b);
   }

   public void updateLong(String a, long b) throws SQLException {
      this.inner.updateLong(a, b);
   }

   public void updateFloat(String a, float b) throws SQLException {
      this.inner.updateFloat(a, b);
   }

   public void updateFloat(int a, float b) throws SQLException {
      this.inner.updateFloat(a, b);
   }

   public void updateDouble(String a, double b) throws SQLException {
      this.inner.updateDouble(a, b);
   }

   public void updateDouble(int a, double b) throws SQLException {
      this.inner.updateDouble(a, b);
   }

   public void updateBigDecimal(int a, BigDecimal b) throws SQLException {
      this.inner.updateBigDecimal(a, b);
   }

   public void updateBigDecimal(String a, BigDecimal b) throws SQLException {
      this.inner.updateBigDecimal(a, b);
   }

   public void updateString(String a, String b) throws SQLException {
      this.inner.updateString(a, b);
   }

   public void updateString(int a, String b) throws SQLException {
      this.inner.updateString(a, b);
   }

   public void updateBytes(int a, byte[] b) throws SQLException {
      this.inner.updateBytes(a, b);
   }

   public void updateBytes(String a, byte[] b) throws SQLException {
      this.inner.updateBytes(a, b);
   }

   public void updateDate(String a, Date b) throws SQLException {
      this.inner.updateDate(a, b);
   }

   public void updateDate(int a, Date b) throws SQLException {
      this.inner.updateDate(a, b);
   }

   public void updateTimestamp(int a, Timestamp b) throws SQLException {
      this.inner.updateTimestamp(a, b);
   }

   public void updateTimestamp(String a, Timestamp b) throws SQLException {
      this.inner.updateTimestamp(a, b);
   }

   public void updateAsciiStream(String a, InputStream b, int c) throws SQLException {
      this.inner.updateAsciiStream(a, b, c);
   }

   public void updateAsciiStream(int a, InputStream b, int c) throws SQLException {
      this.inner.updateAsciiStream(a, b, c);
   }

   public void updateBinaryStream(int a, InputStream b, int c) throws SQLException {
      this.inner.updateBinaryStream(a, b, c);
   }

   public void updateBinaryStream(String a, InputStream b, int c) throws SQLException {
      this.inner.updateBinaryStream(a, b, c);
   }

   public void updateCharacterStream(int a, Reader b, int c) throws SQLException {
      this.inner.updateCharacterStream(a, b, c);
   }

   public void updateCharacterStream(String a, Reader b, int c) throws SQLException {
      this.inner.updateCharacterStream(a, b, c);
   }

   public void updateObject(String a, Object b) throws SQLException {
      this.inner.updateObject(a, b);
   }

   public void updateObject(int a, Object b) throws SQLException {
      this.inner.updateObject(a, b);
   }

   public void updateObject(int a, Object b, int c) throws SQLException {
      this.inner.updateObject(a, b, c);
   }

   public void updateObject(String a, Object b, int c) throws SQLException {
      this.inner.updateObject(a, b, c);
   }

   public void insertRow() throws SQLException {
      this.inner.insertRow();
   }

   public void updateRow() throws SQLException {
      this.inner.updateRow();
   }

   public void deleteRow() throws SQLException {
      this.inner.deleteRow();
   }

   public void refreshRow() throws SQLException {
      this.inner.refreshRow();
   }

   public void cancelRowUpdates() throws SQLException {
      this.inner.cancelRowUpdates();
   }

   public void moveToInsertRow() throws SQLException {
      this.inner.moveToInsertRow();
   }

   public void moveToCurrentRow() throws SQLException {
      this.inner.moveToCurrentRow();
   }

   public Statement getStatement() throws SQLException {
      return this.inner.getStatement();
   }

   public Blob getBlob(String a) throws SQLException {
      return this.inner.getBlob(a);
   }

   public Blob getBlob(int a) throws SQLException {
      return this.inner.getBlob(a);
   }

   public Clob getClob(String a) throws SQLException {
      return this.inner.getClob(a);
   }

   public Clob getClob(int a) throws SQLException {
      return this.inner.getClob(a);
   }

   public void updateRef(String a, Ref b) throws SQLException {
      this.inner.updateRef(a, b);
   }

   public void updateRef(int a, Ref b) throws SQLException {
      this.inner.updateRef(a, b);
   }

   public void updateBlob(String a, Blob b) throws SQLException {
      this.inner.updateBlob(a, b);
   }

   public void updateBlob(int a, Blob b) throws SQLException {
      this.inner.updateBlob(a, b);
   }

   public void updateClob(int a, Clob b) throws SQLException {
      this.inner.updateClob(a, b);
   }

   public void updateClob(String a, Clob b) throws SQLException {
      this.inner.updateClob(a, b);
   }

   public void updateArray(String a, Array b) throws SQLException {
      this.inner.updateArray(a, b);
   }

   public void updateArray(int a, Array b) throws SQLException {
      this.inner.updateArray(a, b);
   }

   public Object getObject(int a) throws SQLException {
      return this.inner.getObject(a);
   }

   public Object getObject(String a, Map b) throws SQLException {
      return this.inner.getObject(a, b);
   }

   public Object getObject(String a) throws SQLException {
      return this.inner.getObject(a);
   }

   public Object getObject(int a, Map b) throws SQLException {
      return this.inner.getObject(a, b);
   }

   public boolean getBoolean(int a) throws SQLException {
      return this.inner.getBoolean(a);
   }

   public boolean getBoolean(String a) throws SQLException {
      return this.inner.getBoolean(a);
   }

   public byte getByte(String a) throws SQLException {
      return this.inner.getByte(a);
   }

   public byte getByte(int a) throws SQLException {
      return this.inner.getByte(a);
   }

   public short getShort(String a) throws SQLException {
      return this.inner.getShort(a);
   }

   public short getShort(int a) throws SQLException {
      return this.inner.getShort(a);
   }

   public int getInt(String a) throws SQLException {
      return this.inner.getInt(a);
   }

   public int getInt(int a) throws SQLException {
      return this.inner.getInt(a);
   }

   public long getLong(int a) throws SQLException {
      return this.inner.getLong(a);
   }

   public long getLong(String a) throws SQLException {
      return this.inner.getLong(a);
   }

   public float getFloat(String a) throws SQLException {
      return this.inner.getFloat(a);
   }

   public float getFloat(int a) throws SQLException {
      return this.inner.getFloat(a);
   }

   public double getDouble(int a) throws SQLException {
      return this.inner.getDouble(a);
   }

   public double getDouble(String a) throws SQLException {
      return this.inner.getDouble(a);
   }

   public byte[] getBytes(String a) throws SQLException {
      return this.inner.getBytes(a);
   }

   public byte[] getBytes(int a) throws SQLException {
      return this.inner.getBytes(a);
   }

   public boolean next() throws SQLException {
      return this.inner.next();
   }

   public URL getURL(int a) throws SQLException {
      return this.inner.getURL(a);
   }

   public URL getURL(String a) throws SQLException {
      return this.inner.getURL(a);
   }

   public int getType() throws SQLException {
      return this.inner.getType();
   }

   public boolean previous() throws SQLException {
      return this.inner.previous();
   }

   public void close() throws SQLException {
      this.inner.close();
   }

   public String getString(String a) throws SQLException {
      return this.inner.getString(a);
   }

   public String getString(int a) throws SQLException {
      return this.inner.getString(a);
   }

   public Ref getRef(String a) throws SQLException {
      return this.inner.getRef(a);
   }

   public Ref getRef(int a) throws SQLException {
      return this.inner.getRef(a);
   }

   public Time getTime(int a, Calendar b) throws SQLException {
      return this.inner.getTime(a, b);
   }

   public Time getTime(String a) throws SQLException {
      return this.inner.getTime(a);
   }

   public Time getTime(int a) throws SQLException {
      return this.inner.getTime(a);
   }

   public Time getTime(String a, Calendar b) throws SQLException {
      return this.inner.getTime(a, b);
   }

   public Date getDate(String a) throws SQLException {
      return this.inner.getDate(a);
   }

   public Date getDate(int a) throws SQLException {
      return this.inner.getDate(a);
   }

   public Date getDate(int a, Calendar b) throws SQLException {
      return this.inner.getDate(a, b);
   }

   public Date getDate(String a, Calendar b) throws SQLException {
      return this.inner.getDate(a, b);
   }

   public boolean first() throws SQLException {
      return this.inner.first();
   }

   public boolean last() throws SQLException {
      return this.inner.last();
   }

   public Array getArray(String a) throws SQLException {
      return this.inner.getArray(a);
   }

   public Array getArray(int a) throws SQLException {
      return this.inner.getArray(a);
   }

   public boolean relative(int a) throws SQLException {
      return this.inner.relative(a);
   }

   public void updateTime(String a, Time b) throws SQLException {
      this.inner.updateTime(a, b);
   }

   public void updateTime(int a, Time b) throws SQLException {
      this.inner.updateTime(a, b);
   }

   public int findColumn(String a) throws SQLException {
      return this.inner.findColumn(a);
   }

   public int getRow() throws SQLException {
      return this.inner.getRow();
   }
}