package com.mchange.v2.c3p0.impl;

import com.mchange.v2.c3p0.ConnectionCustomizer;
import com.mchange.v2.c3p0.ConnectionTester;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.1ProxyCallableStatement;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.1ProxyPreparedStatement;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.1ProxyStatement;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.ProxyConnection;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.ProxyConnectionInvocationHandler;
import com.mchange.v2.c3p0.impl.C3P0PooledConnection.StatementProxyingSetManagedResultSet;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache;
import com.mchange.v2.c3p0.util.ConnectionEventSupport;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.sql.SqlUtils;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.sql.ConnectionEventListener;

public final class C3P0PooledConnection extends AbstractC3P0PooledConnection {
   static final MLogger logger;
   static final Class[] PROXY_CTOR_ARGS;
   static final Constructor CON_PROXY_CTOR;
   static final Method RS_CLOSE_METHOD;
   static final Method STMT_CLOSE_METHOD;
   static final Object[] CLOSE_ARGS;
   static final Set OBJECT_METHODS;
   final ConnectionTester connectionTester;
   final boolean autoCommitOnClose;
   final boolean forceIgnoreUnresolvedTransactions;
   final boolean supports_setTypeMap;
   final boolean supports_setHoldability;
   final int dflt_txn_isolation;
   final String dflt_catalog;
   final int dflt_holdability;
   final ConnectionEventSupport ces = new ConnectionEventSupport(this);
   volatile Connection physicalConnection;
   volatile Exception invalidatingException = null;
   ProxyConnection exposedProxy;
   int connection_status = 0;
   final Set uncachedActiveStatements = Collections.synchronizedSet(new HashSet());
   volatile GooGooStatementCache scache;
   volatile boolean isolation_lvl_nondefault = false;
   volatile boolean catalog_nondefault = false;
   volatile boolean holdability_nondefault = false;

   
   private static Constructor createProxyConstructor(Class intfc) throws NoSuchMethodException {
      Class[] proxyInterfaces = new Class[]{intfc};
      Class proxyCl = Proxy.getProxyClass(C3P0PooledConnection.class.getClassLoader(), proxyInterfaces);
      return proxyCl.getConstructor(PROXY_CTOR_ARGS);
   }

   public C3P0PooledConnection(Connection con, ConnectionTester connectionTester, boolean autoCommitOnClose, boolean forceIgnoreUnresolvedTransactions, ConnectionCustomizer cc, String pdsIdt) throws SQLException {
      try {
         if (cc != null) {
            cc.onAcquire(con, pdsIdt);
         }
      } catch (Exception var8) {
         throw SqlUtils.toSQLException(var8);
      }

      this.physicalConnection = con;
      this.connectionTester = connectionTester;
      this.autoCommitOnClose = autoCommitOnClose;
      this.forceIgnoreUnresolvedTransactions = forceIgnoreUnresolvedTransactions;
      this.supports_setTypeMap = C3P0ImplUtils.supportsMethod(con, "setTypeMap", new Class[]{Map.class});
      this.supports_setHoldability = C3P0ImplUtils.supportsMethod(con, "setHoldability", new Class[]{Integer.TYPE});
      this.dflt_txn_isolation = con.getTransactionIsolation();
      this.dflt_catalog = con.getCatalog();
      this.dflt_holdability = this.supports_setHoldability ? con.getHoldability() : 2;
   }

   Connection getPhysicalConnection() {
      return this.physicalConnection;
   }

   boolean isClosed() throws SQLException {
      return this.physicalConnection == null;
   }

   void initStatementCache(GooGooStatementCache scache) {
      this.scache = scache;
   }

   public synchronized Connection getConnection() throws SQLException {
      if (this.exposedProxy != null) {
         logger.warning("c3p0 -- Uh oh... getConnection() was called on a PooledConnection when it had already provided a client with a Connection that has not yet been closed. This probably indicates a bug in the connection pool!!!");
         return this.exposedProxy;
      } else {
         return this.getCreateNewConnection();
      }
   }

   private Connection getCreateNewConnection() throws SQLException {
      try {
         this.ensureOkay();
         return this.exposedProxy = this.createProxyConnection();
      } catch (SQLException var2) {
         throw var2;
      } catch (Exception var3) {
         logger.log(MLevel.WARNING, "Failed to acquire connection!", var3);
         throw new SQLException("Failed to acquire connection!");
      }
   }

   public void closeAll() throws SQLException {
      if (this.scache != null) {
         this.scache.closeAll(this.physicalConnection);
      }

   }

   public void close() throws SQLException {
      this.close(false);
   }

   private synchronized void close(boolean known_invalid) throws SQLException {
      if (this.physicalConnection != null) {
         try {
            StringBuffer debugOnlyLog = null;
            if (known_invalid) {
               debugOnlyLog = new StringBuffer();
               debugOnlyLog.append("[ exceptions: ");
            }

            Exception exc = this.cleanupUncachedActiveStatements();
            if (exc != null) {
               if (known_invalid) {
                  debugOnlyLog.append(((Exception)exc).toString() + ' ');
               } else {
                  logger.log(MLevel.WARNING, "An exception occurred while cleaning up uncached active Statements.", (Throwable)exc);
               }
            }

            try {
               if (this.exposedProxy != null) {
                  this.exposedProxy.silentClose(known_invalid);
               }
            } catch (Exception var12) {
               if (known_invalid) {
                  debugOnlyLog.append(var12.toString() + ' ');
               } else {
                  logger.log(MLevel.WARNING, "An exception occurred.", (Throwable)exc);
               }

               exc = var12;
            }

            try {
               this.closeAll();
            } catch (Exception var11) {
               if (known_invalid) {
                  debugOnlyLog.append(var11.toString() + ' ');
               } else {
                  logger.log(MLevel.WARNING, "An exception occurred.", (Throwable)exc);
               }

               exc = var11;
            }

            try {
               this.physicalConnection.close();
            } catch (Exception var10) {
               if (known_invalid) {
                  debugOnlyLog.append(var10.toString() + ' ');
               } else {
                  logger.log(MLevel.WARNING, "An exception occurred.", (Throwable)exc);
               }

               var10.printStackTrace();
               exc = var10;
            }

            if (exc != null) {
               if (!known_invalid) {
                  throw new SQLException("At least one error occurred while attempting to close() the PooledConnection: " + exc);
               }

               debugOnlyLog.append(" ]");
               logger.fine(this + ": while closing a PooledConnection known to be invalid, " + "  some exceptions occurred. This is probably not a problem: " + debugOnlyLog.toString());
            }

            logger.fine("C3P0PooledConnection closed. [" + this + ']');
         } finally {
            this.physicalConnection = null;
         }
      }

   }

   public void addConnectionEventListener(ConnectionEventListener listener) {
      this.ces.addConnectionEventListener(listener);
   }

   public void removeConnectionEventListener(ConnectionEventListener listener) {
      this.ces.removeConnectionEventListener(listener);
   }

   private void reset() throws SQLException {
      this.reset(false);
   }

   private void reset(boolean known_resolved_txn) throws SQLException {
      this.ensureOkay();
      C3P0ImplUtils.resetTxnState(this.physicalConnection, this.forceIgnoreUnresolvedTransactions, this.autoCommitOnClose, known_resolved_txn);
      if (this.isolation_lvl_nondefault) {
         this.physicalConnection.setTransactionIsolation(this.dflt_txn_isolation);
         this.isolation_lvl_nondefault = false;
      }

      if (this.catalog_nondefault) {
         this.physicalConnection.setCatalog(this.dflt_catalog);
         this.catalog_nondefault = false;
      }

      if (this.holdability_nondefault) {
         this.physicalConnection.setHoldability(this.dflt_holdability);
         this.holdability_nondefault = false;
      }

      try {
         this.physicalConnection.setReadOnly(false);
      } catch (Throwable var4) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "A Throwable occurred while trying to reset the readOnly property of our Connection to false!", var4);
         }
      }

      try {
         if (this.supports_setTypeMap) {
            this.physicalConnection.setTypeMap(Collections.EMPTY_MAP);
         }
      } catch (Throwable var3) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "A Throwable occurred while trying to reset the typeMap property of our Connection to Collections.EMPTY_MAP!", var3);
         }
      }

   }

   boolean closeAndRemoveResultSets(Set rsSet) {
      boolean okay = true;
      synchronized(rsSet) {
         Iterator ii = rsSet.iterator();

         while(ii.hasNext()) {
            ResultSet rs = (ResultSet)ii.next();

            try {
               rs.close();
            } catch (SQLException var12) {
               logger.log(MLevel.WARNING, "An exception occurred while cleaning up a ResultSet.", var12);
               okay = false;
            } finally {
               ii.remove();
            }
         }

         return okay;
      }
   }

   void ensureOkay() throws SQLException {
      if (this.physicalConnection == null) {
         throw new SQLException(this.invalidatingException == null ? "Connection is closed or broken." : "Connection is broken. Invalidating Exception: " + this.invalidatingException.toString());
      }
   }

   boolean closeAndRemoveResourcesInSet(Set s, Method closeMethod) {
      boolean okay = true;
      HashSet temp;
      synchronized(s) {
         temp = new HashSet(s);
      }

      Iterator ii = temp.iterator();

      while(ii.hasNext()) {
         Object rsrc = ii.next();

         try {
            closeMethod.invoke(rsrc, CLOSE_ARGS);
         } catch (Exception var14) {
            Throwable t = var14;
            if (var14 instanceof InvocationTargetException) {
               t = ((InvocationTargetException)var14).getTargetException();
            }

            logger.log(MLevel.WARNING, "An exception occurred while cleaning up a resource.", (Throwable)t);
            okay = false;
         } finally {
            s.remove(rsrc);
         }
      }

      return okay;
   }

   private SQLException cleanupUncachedActiveStatements() {
      boolean okay = this.closeAndRemoveResourcesInSet(this.uncachedActiveStatements, STMT_CLOSE_METHOD);
      return okay ? null : new SQLException("An exception occurred while trying to clean up orphaned resources.");
   }

   ProxyConnection createProxyConnection() throws Exception {
      InvocationHandler handler = new ProxyConnectionInvocationHandler(this);
      return (ProxyConnection)CON_PROXY_CTOR.newInstance(handler);
   }

   Statement createProxyStatement(Statement innerStmt) throws Exception {
      return this.createProxyStatement(false, innerStmt);
   }

   Statement createProxyStatement(boolean inner_is_cached, Statement innerStmt) throws Exception {
      Set activeResultSets = Collections.synchronizedSet(new HashSet());
      Connection parentConnection = this.exposedProxy;
      if (parentConnection == null) {
         logger.warning("PROBABLE C3P0 BUG -- " + this + ": created a proxy Statement when there is no active, exposed proxy Connection???");
      }

      StatementProxyingSetManagedResultSet mainResultSet = new StatementProxyingSetManagedResultSet(activeResultSets);
      if (innerStmt instanceof CallableStatement) {
         return new 1ProxyCallableStatement(this, (CallableStatement)innerStmt, innerStmt, mainResultSet, activeResultSets, inner_is_cached, parentConnection);
      } else {
         return (Statement)(innerStmt instanceof PreparedStatement ? new 1ProxyPreparedStatement(this, (PreparedStatement)innerStmt, innerStmt, mainResultSet, activeResultSets, inner_is_cached, parentConnection) : new 1ProxyStatement(this, innerStmt, innerStmt, mainResultSet, activeResultSets, inner_is_cached, parentConnection));
      }
   }

   public synchronized int getConnectionStatus() {
      return this.connection_status;
   }

   private synchronized void updateConnectionStatus(int status) {
      switch(this.connection_status) {
      case -8:
         break;
      case -1:
         if (status == -8) {
            this.doBadUpdate(status);
         }
         break;
      case 0:
         if (status != 0) {
            this.doBadUpdate(status);
         }
         break;
      default:
         throw new InternalError(this + " -- Illegal Connection Status: " + this.connection_status);
      }

   }

   private void doBadUpdate(int new_status) {
      this.connection_status = new_status;

      try {
         this.close(true);
      } catch (SQLException var3) {
         logger.log(MLevel.WARNING, "Broken Connection Close Error. ", var3);
      }

   }

   static {
      logger = MLog.getLogger(C3P0PooledConnection.class);
      PROXY_CTOR_ARGS = new Class[]{InvocationHandler.class};

      try {
         CON_PROXY_CTOR = createProxyConstructor(ProxyConnection.class);
         Class[] argClasses = new Class[0];
         RS_CLOSE_METHOD = ResultSet.class.getMethod("close", argClasses);
         STMT_CLOSE_METHOD = Statement.class.getMethod("close", argClasses);
         CLOSE_ARGS = new Object[0];
         OBJECT_METHODS = Collections.unmodifiableSet(new HashSet(Arrays.asList(Object.class.getMethods())));
      } catch (Exception var1) {
         logger.log(MLevel.SEVERE, "An Exception occurred in static initializer of" + C3P0PooledConnection.class.getName(), var1);
         throw new InternalError("Something is very wrong, or this is a pre 1.3 JVM.We cannot set up dynamic proxies and/or methods!");
      }
   }
}