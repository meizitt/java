package com.mchange.v2.c3p0;

import java.sql.Connection;

public interface ConnectionCustomizer {
   void onAcquire(Connection var1, String var2) throws Exception;

   void onDestroy(Connection var1, String var2) throws Exception;

   void onCheckOut(Connection var1, String var2) throws Exception;

   void onCheckIn(Connection var1, String var2) throws Exception;
}