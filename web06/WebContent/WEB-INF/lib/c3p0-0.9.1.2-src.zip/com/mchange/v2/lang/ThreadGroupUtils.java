package com.mchange.v2.lang;

public final class ThreadGroupUtils {
   public static ThreadGroup rootThreadGroup() {
      ThreadGroup tg = Thread.currentThread().getThreadGroup();

      for(ThreadGroup ptg = tg.getParent(); ptg != null; ptg = ptg.getParent()) {
         tg = ptg;
      }

      return tg;
   }
}