package com.mchange.v2.beans;

import com.mchange.v2.lang.Coerce;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.beans.BeanInfo;
import java.beans.IndexedPropertyDescriptor;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyDescriptor;
import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class BeansUtils {
   static final MLogger logger;
   static final Object[] EMPTY_ARGS;

   public static PropertyEditor findPropertyEditor(PropertyDescriptor pd) {
      PropertyEditor out = null;
      Class editorClass = null;

      try {
         editorClass = pd.getPropertyEditorClass();
         if (editorClass != null) {
            out = (PropertyEditor)editorClass.newInstance();
         }
      } catch (Exception var4) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Bad property editor class " + editorClass.getName() + " registered for property " + pd.getName(), var4);
         }
      }

      if (out == null) {
         out = PropertyEditorManager.findEditor(pd.getPropertyType());
      }

      return out;
   }

   public static boolean equalsByAccessibleProperties(Object bean0, Object bean1) throws IntrospectionException {
      return equalsByAccessibleProperties(bean0, bean1, Collections.EMPTY_SET);
   }

   public static boolean equalsByAccessibleProperties(Object bean0, Object bean1, Collection ignoreProps) throws IntrospectionException {
      Map m0 = new HashMap();
      Map m1 = new HashMap();
      extractAccessiblePropertiesToMap(m0, bean0, ignoreProps);
      extractAccessiblePropertiesToMap(m1, bean1, ignoreProps);
      return m0.equals(m1);
   }

   public static void overwriteAccessibleProperties(Object sourceBean, Object destBean) throws IntrospectionException {
      overwriteAccessibleProperties(sourceBean, destBean, Collections.EMPTY_SET);
   }

   public static void overwriteAccessibleProperties(Object sourceBean, Object destBean, Collection ignoreProps) throws IntrospectionException {
      try {
         BeanInfo beanInfo = Introspector.getBeanInfo(sourceBean.getClass(), Object.class);
         PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
         int i = 0;

         for(int len = pds.length; i < len; ++i) {
            PropertyDescriptor pd = pds[i];
            if (!ignoreProps.contains(pd.getName())) {
               Method getter = pd.getReadMethod();
               Method setter = pd.getWriteMethod();
               if (getter != null && setter != null) {
                  Object value = getter.invoke(sourceBean, EMPTY_ARGS);
                  setter.invoke(destBean, value);
               } else {
                  if (pd instanceof IndexedPropertyDescriptor && logger.isLoggable(MLevel.WARNING)) {
                     logger.warning("BeansUtils.overwriteAccessibleProperties() does not support indexed properties that do not provide single-valued array getters and setters! [The indexed methods provide no means of modifying the size of the array in the destination bean if it does not match the source.]");
                  }

                  if (logger.isLoggable(MLevel.INFO)) {
                     logger.info("Property inaccessible for overwriting: " + pd.getName());
                  }
               }
            }
         }

      } catch (IntrospectionException var11) {
         throw var11;
      } catch (Exception var12) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "Converting exception to throwable IntrospectionException");
         }

         throw new IntrospectionException(var12.getMessage());
      }
   }

   public static void overwriteAccessiblePropertiesFromMap(Map sourceMap, Object destBean, boolean skip_nulls) throws IntrospectionException {
      overwriteAccessiblePropertiesFromMap(sourceMap, destBean, skip_nulls, Collections.EMPTY_SET);
   }

   public static void overwriteAccessiblePropertiesFromMap(Map sourceMap, Object destBean, boolean skip_nulls, Collection ignoreProps) throws IntrospectionException {
      overwriteAccessiblePropertiesFromMap(sourceMap, destBean, skip_nulls, ignoreProps, false, MLevel.WARNING, MLevel.WARNING, true);
   }

   public static void overwriteAccessiblePropertiesFromMap(Map sourceMap, Object destBean, boolean skip_nulls, Collection ignoreProps, boolean coerce_strings, MLevel cantWriteLevel, MLevel cantCoerceLevel, boolean die_on_one_prop_failure) throws IntrospectionException {
      if (cantWriteLevel == null) {
         cantWriteLevel = MLevel.WARNING;
      }

      if (cantCoerceLevel == null) {
         cantCoerceLevel = MLevel.WARNING;
      }

      Set sourceMapProps = sourceMap.keySet();
      String propName = null;
      BeanInfo beanInfo = Introspector.getBeanInfo(destBean.getClass(), Object.class);
      PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
      int i = 0;

      for(int len = pds.length; i < len; ++i) {
         PropertyDescriptor pd = pds[i];
         propName = pd.getName();
         if (sourceMapProps.contains(propName) && (ignoreProps == null || !ignoreProps.contains(propName))) {
            Object propVal = sourceMap.get(propName);
            if (propVal != null || !skip_nulls) {
               Method setter = pd.getWriteMethod();
               boolean rethrow = false;
               Class propType = pd.getPropertyType();
               if (setter == null) {
                  if (pd instanceof IndexedPropertyDescriptor && logger.isLoggable(MLevel.FINER)) {
                     logger.finer("BeansUtils.overwriteAccessiblePropertiesFromMap() does not support indexed properties that do not provide single-valued array getters and setters! [The indexed methods provide no means of modifying the size of the array in the destination bean if it does not match the source.]");
                  }

                  if (logger.isLoggable(cantWriteLevel)) {
                     String msg = "Property inaccessible for overwriting: " + propName;
                     logger.log(cantWriteLevel, msg);
                     if (die_on_one_prop_failure) {
                        rethrow = true;
                        throw new IntrospectionException(msg);
                     }
                  }
               } else if (coerce_strings && propVal != null && propVal.getClass() == String.class && (propType = pd.getPropertyType()) != String.class && Coerce.canCoerce(propType)) {
                  String msg;
                  try {
                     Object coercedPropVal = Coerce.toObject((String)propVal, propType);
                     setter.invoke(destBean, coercedPropVal);
                  } catch (IllegalArgumentException var22) {
                     msg = "Failed to coerce property: " + propName + " [propVal: " + propVal + "; propType: " + propType + "]";
                     if (logger.isLoggable(cantCoerceLevel)) {
                        logger.log(cantCoerceLevel, msg, var22);
                     }

                     if (die_on_one_prop_failure) {
                        rethrow = true;
                        throw new IntrospectionException(msg);
                     }
                  } catch (Exception var23) {
                     msg = "Failed to set property: " + propName + " [propVal: " + propVal + "; propType: " + propType + "]";
                     if (logger.isLoggable(cantWriteLevel)) {
                        logger.log(cantWriteLevel, msg, var23);
                     }

                     if (die_on_one_prop_failure) {
                        rethrow = true;
                        throw new IntrospectionException(msg);
                     }
                  }
               } else {
                  try {
                     setter.invoke(destBean, propVal);
                  } catch (Exception var24) {
                     String msg = "Failed to set property: " + propName + " [propVal: " + propVal + "; propType: " + propType + "]";
                     if (logger.isLoggable(cantWriteLevel)) {
                        logger.log(cantWriteLevel, msg, var24);
                     }

                     if (die_on_one_prop_failure) {
                        rethrow = true;
                        throw new IntrospectionException(msg);
                     }
                  }
               }
            }
         }
      }

   }

   public static void appendPropNamesAndValues(StringBuffer appendIntoMe, Object bean, Collection ignoreProps) throws IntrospectionException {
      Map tmp = new TreeMap(String.CASE_INSENSITIVE_ORDER);
      extractAccessiblePropertiesToMap(tmp, bean, ignoreProps);
      boolean first = true;
      Iterator ii = tmp.keySet().iterator();

      while(ii.hasNext()) {
         String key = (String)ii.next();
         Object val = tmp.get(key);
         if (first) {
            first = false;
         } else {
            appendIntoMe.append(", ");
         }

         appendIntoMe.append(key);
         appendIntoMe.append(" -> ");
         appendIntoMe.append(val);
      }

   }

   public static void extractAccessiblePropertiesToMap(Map fillMe, Object bean) throws IntrospectionException {
      extractAccessiblePropertiesToMap(fillMe, bean, Collections.EMPTY_SET);
   }

   public static void extractAccessiblePropertiesToMap(Map fillMe, Object bean, Collection ignoreProps) throws IntrospectionException {
      String propName = null;

      try {
         BeanInfo bi = Introspector.getBeanInfo(bean.getClass(), Object.class);
         PropertyDescriptor[] pds = bi.getPropertyDescriptors();
         int i = 0;

         for(int len = pds.length; i < len; ++i) {
            PropertyDescriptor pd = pds[i];
            propName = pd.getName();
            if (!ignoreProps.contains(propName)) {
               Method readMethod = pd.getReadMethod();
               Object propVal = readMethod.invoke(bean, EMPTY_ARGS);
               fillMe.put(propName, propVal);
            }
         }

      } catch (IntrospectionException var11) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.warning("Problem occurred while overwriting property: " + propName);
         }

         if (logger.isLoggable(MLevel.FINE)) {
            logger.logp(MLevel.FINE, BeansUtils.class.getName(), "extractAccessiblePropertiesToMap( Map fillMe, Object bean, Collection ignoreProps )", (propName != null ? "Problem occurred while overwriting property: " + propName : "") + " throwing...", var11);
         }

         throw var11;
      } catch (Exception var12) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.logp(MLevel.FINE, BeansUtils.class.getName(), "extractAccessiblePropertiesToMap( Map fillMe, Object bean, Collection ignoreProps )", "Caught unexpected Exception; Converting to IntrospectionException.", var12);
         }

         throw new IntrospectionException(var12.toString() + (propName == null ? "" : " [" + propName + ']'));
      }
   }

   private static void overwriteProperty(String propName, Object value, Method putativeSetter, Object target) throws Exception {
      if (putativeSetter.getDeclaringClass().isAssignableFrom(target.getClass())) {
         putativeSetter.invoke(target, value);
      } else {
         BeanInfo beanInfo = Introspector.getBeanInfo(target.getClass(), Object.class);
         PropertyDescriptor pd = null;
         PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
         int i = 0;

         for(int len = pds.length; i < len; ++i) {
            if (propName.equals(pds[i].getName())) {
               pd = pds[i];
               break;
            }
         }

         Method targetSetter = pd.getWriteMethod();
         targetSetter.invoke(target, value);
      }

   }

   public static void overwriteSpecificAccessibleProperties(Object sourceBean, Object destBean, Collection props) throws IntrospectionException {
      try {
         Set _props = new HashSet(props);
         BeanInfo beanInfo = Introspector.getBeanInfo(sourceBean.getClass(), Object.class);
         PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
         int i = 0;

         for(int len = pds.length; i < len; ++i) {
            PropertyDescriptor pd = pds[i];
            String name = pd.getName();
            if (_props.remove(name)) {
               Method getter = pd.getReadMethod();
               Method setter = pd.getWriteMethod();
               if (getter != null && setter != null) {
                  Object value = getter.invoke(sourceBean, EMPTY_ARGS);
                  overwriteProperty(name, value, setter, destBean);
               } else {
                  if (pd instanceof IndexedPropertyDescriptor && logger.isLoggable(MLevel.WARNING)) {
                     logger.warning("BeansUtils.overwriteAccessibleProperties() does not support indexed properties that do not provide single-valued array getters and setters! [The indexed methods provide no means of modifying the size of the array in the destination bean if it does not match the source.]");
                  }

                  if (logger.isLoggable(MLevel.INFO)) {
                     logger.info("Property inaccessible for overwriting: " + pd.getName());
                  }
               }
            }
         }

         if (logger.isLoggable(MLevel.WARNING)) {
            Iterator ii = _props.iterator();

            while(ii.hasNext()) {
               logger.warning("failed to find expected property: " + ii.next());
            }
         }

      } catch (IntrospectionException var13) {
         throw var13;
      } catch (Exception var14) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.logp(MLevel.FINE, BeansUtils.class.getName(), "overwriteSpecificAccessibleProperties( Object sourceBean, Object destBean, Collection props )", "Caught unexpected Exception; Converting to IntrospectionException.", var14);
         }

         throw new IntrospectionException(var14.getMessage());
      }
   }

   public static void debugShowPropertyChange(PropertyChangeEvent evt) {
      System.err.println("PropertyChangeEvent: [ propertyName -> " + evt.getPropertyName() + ", oldValue -> " + evt.getOldValue() + ", newValue -> " + evt.getNewValue() + " ]");
   }

   static {
      logger = MLog.getLogger(BeansUtils.class);
      EMPTY_ARGS = new Object[0];
   }
}