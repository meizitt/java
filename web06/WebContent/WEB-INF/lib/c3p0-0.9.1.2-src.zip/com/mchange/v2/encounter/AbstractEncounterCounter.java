package com.mchange.v2.encounter;

import java.util.Map;

class AbstractEncounterCounter implements EncounterCounter {
   static final Long ONE = new Long(1L);
   Map m;

   AbstractEncounterCounter(Map m) {
      this.m = m;
   }

   public long encounter(Object o) {
      Long oldLong = (Long)this.m.get(o);
      Long newLong;
      long out;
      if (oldLong == null) {
         out = 0L;
         newLong = ONE;
      } else {
         out = oldLong;
         newLong = new Long(out + 1L);
      }

      this.m.put(o, newLong);
      return out;
   }
}