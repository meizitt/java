package com.mchange.v2.c3p0.management;

import com.mchange.v1.lang.ClassUtils;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.DriverManagerDataSource;
import com.mchange.v2.c3p0.PooledDataSource;
import com.mchange.v2.c3p0.WrapperConnectionPoolDataSource;
import com.mchange.v2.c3p0.impl.AbstractPoolBackedDataSource;
import com.mchange.v2.c3p0.management.DynamicPooledDataSourceManagerMBean.1;
import com.mchange.v2.c3p0.management.DynamicPooledDataSourceManagerMBean.AttrRec;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.management.ManagementUtils;
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyChangeListener;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.AttributeNotFoundException;
import javax.management.DynamicMBean;
import javax.management.IntrospectionException;
import javax.management.InvalidAttributeValueException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanConstructorInfo;
import javax.management.MBeanException;
import javax.management.MBeanInfo;
import javax.management.MBeanNotificationInfo;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.DataSource;

public class DynamicPooledDataSourceManagerMBean implements DynamicMBean {
   static final MLogger logger;
   static final Set HIDE_PROPS;
   static final Set HIDE_OPS;
   static final Set FORCE_OPS;
   static final Set FORCE_READ_ONLY_PROPS;
   static final MBeanOperationInfo[] OP_INFS;
   MBeanInfo info = null;
   PooledDataSource pds;
   String mbeanName;
   MBeanServer mbs;
   ConnectionPoolDataSource cpds;
   DataSource unpooledDataSource;
   Map pdsAttrInfos;
   Map cpdsAttrInfos;
   Map unpooledDataSourceAttrInfos;
   PropertyChangeListener pcl = new 1(this);

   public DynamicPooledDataSourceManagerMBean(PooledDataSource pds, String mbeanName, MBeanServer mbs) throws Exception {
      this.pds = pds;
      this.mbeanName = mbeanName;
      this.mbs = mbs;
      if (!(pds instanceof ComboPooledDataSource)) {
         if (pds instanceof AbstractPoolBackedDataSource) {
            ((AbstractPoolBackedDataSource)pds).addPropertyChangeListener(this.pcl);
         } else {
            logger.warning(this + "managing an unexpected PooledDataSource. Only top-level attributes will be available. PooledDataSource: " + pds);
         }
      }

      Exception e = this.reinitialize();
      if (e != null) {
         throw e;
      }
   }

   private synchronized Exception reinitialize() {
      try {
         if (!(this.pds instanceof ComboPooledDataSource) && this.pds instanceof AbstractPoolBackedDataSource) {
            if (this.cpds instanceof WrapperConnectionPoolDataSource) {
               ((WrapperConnectionPoolDataSource)this.cpds).removePropertyChangeListener(this.pcl);
            }

            this.cpds = null;
            this.unpooledDataSource = null;
            this.cpds = ((AbstractPoolBackedDataSource)this.pds).getConnectionPoolDataSource();
            if (this.cpds instanceof WrapperConnectionPoolDataSource) {
               this.unpooledDataSource = ((WrapperConnectionPoolDataSource)this.cpds).getNestedDataSource();
               ((WrapperConnectionPoolDataSource)this.cpds).addPropertyChangeListener(this.pcl);
            }
         }

         this.pdsAttrInfos = extractAttributeInfos(this.pds);
         this.cpdsAttrInfos = extractAttributeInfos(this.cpds);
         this.unpooledDataSourceAttrInfos = extractAttributeInfos(this.unpooledDataSource);
         Set allAttrNames = new HashSet();
         allAttrNames.addAll(this.pdsAttrInfos.keySet());
         allAttrNames.addAll(this.cpdsAttrInfos.keySet());
         allAttrNames.addAll(this.unpooledDataSourceAttrInfos.keySet());
         Set allAttrs = new HashSet();

         Object attrInfo;
         for(Iterator ii = allAttrNames.iterator(); ii.hasNext(); allAttrs.add(attrInfo)) {
            String name = (String)ii.next();
            attrInfo = this.pdsAttrInfos.get(name);
            if (attrInfo == null) {
               attrInfo = this.cpdsAttrInfos.get(name);
            }

            if (attrInfo == null) {
               attrInfo = this.unpooledDataSourceAttrInfos.get(name);
            }
         }

         String className = this.getClass().getName();
         MBeanAttributeInfo[] attrInfos = (MBeanAttributeInfo[])((MBeanAttributeInfo[])allAttrs.toArray(new MBeanAttributeInfo[allAttrs.size()]));
         Class[] ctorArgClasses = new Class[]{PooledDataSource.class, String.class, MBeanServer.class};
         MBeanConstructorInfo[] constrInfos = new MBeanConstructorInfo[]{new MBeanConstructorInfo("Constructor from PooledDataSource", this.getClass().getConstructor(ctorArgClasses))};
         this.info = new MBeanInfo(this.getClass().getName(), "An MBean to monitor and manage a PooledDataSource", attrInfos, constrInfos, OP_INFS, (MBeanNotificationInfo[])null);

         try {
            ObjectName oname = ObjectName.getInstance(this.mbeanName);
            if (this.mbs.isRegistered(oname)) {
               this.mbs.unregisterMBean(oname);
               if (logger.isLoggable(MLevel.FINER)) {
                  logger.log(MLevel.FINER, "MBean: " + this.mbeanName + " unregistered, in order to be reregistered after update.");
               }
            }

            this.mbs.registerMBean(this, oname);
            if (logger.isLoggable(MLevel.FINER)) {
               logger.log(MLevel.FINER, "MBean: " + this.mbeanName + " registered.");
            }

            return null;
         } catch (Exception var8) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "An Exception occurred while registering/reregistering mbean " + this.mbeanName + ". MBean may not be registered, or may not work properly.", var8);
            }

            return var8;
         }
      } catch (NoSuchMethodException var9) {
         if (logger.isLoggable(MLevel.SEVERE)) {
            logger.log(MLevel.SEVERE, "Huh? We can't find our own constructor?? The one we're in?", var9);
         }

         return var9;
      }
   }

   private static MBeanOperationInfo[] extractOpInfs() {
      MBeanParameterInfo user = new MBeanParameterInfo("user", "java.lang.String", "The database username of a pool-owner.");
      MBeanParameterInfo pwd = new MBeanParameterInfo("password", "java.lang.String", "The database password of a pool-owner.");
      MBeanParameterInfo[] userPass = new MBeanParameterInfo[]{user, pwd};
      MBeanParameterInfo[] empty = new MBeanParameterInfo[0];
      Method[] meths = PooledDataSource.class.getMethods();
      Set attrInfos = new TreeSet(ManagementUtils.OP_INFO_COMPARATOR);

      for(int i = 0; i < meths.length; ++i) {
         Method meth = meths[i];
         if (!HIDE_OPS.contains(meth)) {
            String mname = meth.getName();
            Class[] params = meth.getParameterTypes();
            if (FORCE_OPS.contains(mname) || (!mname.startsWith("set") || params.length != 1) && (!mname.startsWith("get") && !mname.startsWith("is") || params.length != 0)) {
               Class retType = meth.getReturnType();
               int impact = retType == Void.TYPE ? 1 : 0;
               MBeanParameterInfo[] pi;
               if (params.length == 2 && params[0] == String.class && params[1] == String.class) {
                  pi = userPass;
               } else if (params.length == 0) {
                  pi = empty;
               } else {
                  pi = null;
               }

               MBeanOperationInfo opi;
               if (pi != null) {
                  opi = new MBeanOperationInfo(mname, (String)null, pi, retType.getName(), impact);
               } else {
                  opi = new MBeanOperationInfo(meth.toString(), meth);
               }

               attrInfos.add(opi);
            }
         }
      }

      return (MBeanOperationInfo[])((MBeanOperationInfo[])attrInfos.toArray(new MBeanOperationInfo[attrInfos.size()]));
   }

   public synchronized Object getAttribute(String attr) throws AttributeNotFoundException, MBeanException, ReflectionException {
      try {
         AttrRec rec = this.attrRecForAttribute(attr);
         if (rec == null) {
            throw new AttributeNotFoundException(attr);
         } else {
            MBeanAttributeInfo ai = rec.attrInfo;
            if (!ai.isReadable()) {
               throw new IllegalArgumentException(attr + " not readable.");
            } else {
               String name = ai.getName();
               String pfx = ai.isIs() ? "is" : "get";
               String mname = pfx + Character.toUpperCase(name.charAt(0)) + name.substring(1);
               Object target = rec.target;
               Method m = target.getClass().getMethod(mname, (Class[])null);
               return m.invoke(target, (Object[])null);
            }
         }
      } catch (Exception var9) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Failed to get requested attribute: " + attr, var9);
         }

         throw new MBeanException(var9);
      }
   }

   public synchronized AttributeList getAttributes(String[] attrs) {
      AttributeList al = new AttributeList();
      int i = 0;

      for(int len = attrs.length; i < len; ++i) {
         String attr = attrs[i];

         try {
            Object val = this.getAttribute(attr);
            al.add(new Attribute(attr, val));
         } catch (Exception var7) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "Failed to get requested attribute (for list): " + attr, var7);
            }
         }
      }

      return al;
   }

   private AttrRec attrRecForAttribute(String attr) {
      if (!$assertionsDisabled && !Thread.holdsLock(this)) {
         throw new AssertionError();
      } else if (this.pdsAttrInfos.containsKey(attr)) {
         return new AttrRec(this.pds, (MBeanAttributeInfo)this.pdsAttrInfos.get(attr));
      } else if (this.cpdsAttrInfos.containsKey(attr)) {
         return new AttrRec(this.cpds, (MBeanAttributeInfo)this.cpdsAttrInfos.get(attr));
      } else {
         return this.unpooledDataSourceAttrInfos.containsKey(attr) ? new AttrRec(this.unpooledDataSource, (MBeanAttributeInfo)this.unpooledDataSourceAttrInfos.get(attr)) : null;
      }
   }

   public synchronized MBeanInfo getMBeanInfo() {
      if (this.info == null) {
         this.reinitialize();
      }

      return this.info;
   }

   public synchronized Object invoke(String operation, Object[] paramVals, String[] signature) throws MBeanException, ReflectionException {
      int i;
      try {
         int slen = signature.length;
         Class[] paramTypes = new Class[slen];

         for(i = 0; i < slen; ++i) {
            paramTypes[i] = ClassUtils.forName(signature[i]);
         }

         Method m = this.pds.getClass().getMethod(operation, paramTypes);
         return m.invoke(this.pds, paramVals);
      } catch (NoSuchMethodException var9) {
         NoSuchMethodException e = var9;

         try {
            boolean two = false;
            if (signature.length != 0 || !operation.startsWith("get") && !(two = operation.startsWith("is"))) {
               if (signature.length == 1 && operation.startsWith("set")) {
                  this.setAttribute(new Attribute(Character.toLowerCase(operation.charAt(3)) + operation.substring(4), paramVals[0]));
                  return null;
               } else {
                  throw new MBeanException(e);
               }
            } else {
               i = two ? 2 : 3;
               String attr = Character.toLowerCase(operation.charAt(i)) + operation.substring(i + 1);
               return this.getAttribute(attr);
            }
         } catch (Exception var8) {
            throw new MBeanException(var8);
         }
      } catch (Exception var10) {
         throw new MBeanException(var10);
      }
   }

   public synchronized void setAttribute(Attribute attrObj) throws AttributeNotFoundException, InvalidAttributeValueException, MBeanException, ReflectionException {
      try {
         String attr = attrObj.getName();
         if (attr == "factoryClassLocation") {
            if (this.pds instanceof ComboPooledDataSource) {
               ((ComboPooledDataSource)this.pds).setFactoryClassLocation((String)attrObj.getValue());
               return;
            }

            if (this.pds instanceof AbstractPoolBackedDataSource) {
               String val = (String)attrObj.getValue();
               AbstractPoolBackedDataSource apbds = (AbstractPoolBackedDataSource)this.pds;
               apbds.setFactoryClassLocation(val);
               ConnectionPoolDataSource checkDs1 = apbds.getConnectionPoolDataSource();
               if (checkDs1 instanceof WrapperConnectionPoolDataSource) {
                  WrapperConnectionPoolDataSource wcheckDs1 = (WrapperConnectionPoolDataSource)checkDs1;
                  wcheckDs1.setFactoryClassLocation(val);
                  DataSource checkDs2 = wcheckDs1.getNestedDataSource();
                  if (checkDs2 instanceof DriverManagerDataSource) {
                     ((DriverManagerDataSource)checkDs2).setFactoryClassLocation(val);
                  }
               }

               return;
            }
         }

         AttrRec rec = this.attrRecForAttribute(attr);
         if (rec == null) {
            throw new AttributeNotFoundException(attr);
         } else {
            MBeanAttributeInfo ai = rec.attrInfo;
            if (!ai.isWritable()) {
               throw new IllegalArgumentException(attr + " not writable.");
            } else {
               Class attrType = ClassUtils.forName(rec.attrInfo.getType());
               String name = ai.getName();
               String pfx = "set";
               String mname = pfx + Character.toUpperCase(name.charAt(0)) + name.substring(1);
               Object target = rec.target;
               Method m = target.getClass().getMethod(mname, attrType);
               m.invoke(target, attrObj.getValue());
               if (target != this.pds) {
                  if (this.pds instanceof AbstractPoolBackedDataSource) {
                     ((AbstractPoolBackedDataSource)this.pds).resetPoolManager(false);
                  } else if (logger.isLoggable(MLevel.WARNING)) {
                     logger.warning("MBean set a nested ConnectionPoolDataSource or DataSource parameter on an unknown PooledDataSource type. Could not reset the pool manager, so the changes may not take effect. c3p0 may need to be updated for PooledDataSource type " + this.pds.getClass() + ".");
                  }
               }

            }
         }
      } catch (Exception var11) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Failed to set requested attribute: " + attrObj, var11);
         }

         throw new MBeanException(var11);
      }
   }

   public synchronized AttributeList setAttributes(AttributeList al) {
      AttributeList out = new AttributeList();
      int i = 0;

      for(int len = al.size(); i < len; ++i) {
         Attribute attrObj = (Attribute)al.get(i);

         try {
            this.setAttribute(attrObj);
            out.add(attrObj);
         } catch (Exception var7) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "Failed to set requested attribute (from list): " + attrObj, var7);
            }
         }
      }

      return out;
   }

   private static Map extractAttributeInfos(Object bean) {
      if (bean != null) {
         try {
            Map out = new HashMap();
            BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass(), Object.class);
            PropertyDescriptor[] pds = beanInfo.getPropertyDescriptors();
            int i = 0;

            for(int len = pds.length; i < len; ++i) {
               PropertyDescriptor pd = pds[i];
               String name = pd.getName();
               if (!HIDE_PROPS.contains(name)) {
                  String desc = getDescription(name);
                  Method getter = pd.getReadMethod();
                  Method setter = pd.getWriteMethod();
                  if (FORCE_READ_ONLY_PROPS.contains(name)) {
                     setter = null;
                  }

                  try {
                     out.put(name, new MBeanAttributeInfo(name, desc, getter, setter));
                  } catch (IntrospectionException var12) {
                     if (logger.isLoggable(MLevel.WARNING)) {
                        logger.log(MLevel.WARNING, "IntrospectionException while setting up MBean attribute '" + name + "'", var12);
                     }
                  }
               }
            }

            return Collections.synchronizedMap(out);
         } catch (java.beans.IntrospectionException var13) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "IntrospectionException while setting up MBean attributes for " + bean, var13);
            }

            return Collections.EMPTY_MAP;
         }
      } else {
         return Collections.EMPTY_MAP;
      }
   }

   private static String getDescription(String attrName) {
      return null;
   }

   static {
      $assertionsDisabled = !DynamicPooledDataSourceManagerMBean.class.desiredAssertionStatus();
      logger = MLog.getLogger(DynamicPooledDataSourceManagerMBean.class);
      Set hpTmp = new HashSet();
      hpTmp.add("connectionPoolDataSource");
      hpTmp.add("nestedDataSource");
      hpTmp.add("reference");
      hpTmp.add("connection");
      hpTmp.add("password");
      hpTmp.add("pooledConnection");
      hpTmp.add("properties");
      hpTmp.add("logWriter");
      hpTmp.add("lastAcquisitionFailureDefaultUser");
      hpTmp.add("lastCheckoutFailureDefaultUser");
      hpTmp.add("lastCheckinFailureDefaultUser");
      hpTmp.add("lastIdleTestFailureDefaultUser");
      hpTmp.add("lastConnectionTestFailureDefaultUser");
      HIDE_PROPS = Collections.unmodifiableSet(hpTmp);
      Class[] userPassArgs = new Class[]{String.class, String.class};
      HashSet hoTmp = new HashSet();

      try {
         hoTmp.add(PooledDataSource.class.getMethod("close", Boolean.TYPE));
         hoTmp.add(PooledDataSource.class.getMethod("getConnection", userPassArgs));
         hoTmp.add(PooledDataSource.class.getMethod("getLastAcquisitionFailure", userPassArgs));
         hoTmp.add(PooledDataSource.class.getMethod("getLastCheckinFailure", userPassArgs));
         hoTmp.add(PooledDataSource.class.getMethod("getLastCheckoutFailure", userPassArgs));
         hoTmp.add(PooledDataSource.class.getMethod("getLastIdleTestFailure", userPassArgs));
         hoTmp.add(PooledDataSource.class.getMethod("getLastConnectionTestFailure", userPassArgs));
      } catch (Exception var5) {
         logger.log(MLevel.WARNING, "Tried to hide an operation from being exposed by mbean, but failed to find the operation!", var5);
      }

      HIDE_OPS = Collections.unmodifiableSet(hoTmp);
      Set fropTmp = new HashSet();
      fropTmp.add("identityToken");
      FORCE_READ_ONLY_PROPS = Collections.unmodifiableSet(fropTmp);
      Set foTmp = new HashSet();
      FORCE_OPS = Collections.unmodifiableSet(foTmp);
      OP_INFS = extractOpInfs();
   }
}