package com.mchange.v2.c3p0.impl;

import com.mchange.v2.async.AsynchronousRunner;
import com.mchange.v2.async.ThreadPoolAsynchronousRunner;
import com.mchange.v2.c3p0.ConnectionCustomizer;
import com.mchange.v2.c3p0.ConnectionTester;
import com.mchange.v2.c3p0.impl.C3P0PooledConnectionPool.1PooledConnectionResourcePoolManager;
import com.mchange.v2.c3p0.impl.C3P0PooledConnectionPool.ConnectionEventListenerImpl;
import com.mchange.v2.c3p0.impl.C3P0PooledConnectionPool.ThrowableHolderPool;
import com.mchange.v2.c3p0.stmt.DoubleMaxStatementCache;
import com.mchange.v2.c3p0.stmt.GlobalMaxOnlyStatementCache;
import com.mchange.v2.c3p0.stmt.GooGooStatementCache;
import com.mchange.v2.c3p0.stmt.PerConnectionMaxOnlyStatementCache;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.resourcepool.CannotAcquireResourceException;
import com.mchange.v2.resourcepool.ResourcePool;
import com.mchange.v2.resourcepool.ResourcePoolException;
import com.mchange.v2.resourcepool.ResourcePoolFactory;
import com.mchange.v2.resourcepool.TimeoutException;
import com.mchange.v2.resourcepool.ResourcePool.Manager;
import com.mchange.v2.sql.SqlUtils;
import java.sql.SQLException;
import javax.sql.ConnectionEventListener;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;

public final class C3P0PooledConnectionPool {
   private static final boolean ASYNCHRONOUS_CONNECTION_EVENT_LISTENER = false;
   private static final Throwable[] EMPTY_THROWABLE_HOLDER = new Throwable[1];
   static final MLogger logger;
   final ResourcePool rp;
   final ConnectionEventListener cl = new ConnectionEventListenerImpl(this);
   final ConnectionTester connectionTester;
   final GooGooStatementCache scache;
   final int checkoutTimeout;
   final AsynchronousRunner sharedTaskRunner;
   final ThrowableHolderPool thp = new ThrowableHolderPool();

   C3P0PooledConnectionPool(ConnectionPoolDataSource cpds, DbAuth auth, int min, int max, int start, int inc, int acq_retry_attempts, int acq_retry_delay, boolean break_after_acq_failure, int checkoutTimeout, int idleConnectionTestPeriod, int maxIdleTime, int maxIdleTimeExcessConnections, int maxConnectionAge, int propertyCycle, int unreturnedConnectionTimeout, boolean debugUnreturnedConnectionStackTraces, boolean testConnectionOnCheckout, boolean testConnectionOnCheckin, int maxStatements, int maxStatementsPerConnection, ConnectionTester connectionTester, ConnectionCustomizer connectionCustomizer, String testQuery, ResourcePoolFactory fact, ThreadPoolAsynchronousRunner taskRunner, String parentDataSourceIdentityToken) throws SQLException {
      try {
         if (maxStatements > 0 && maxStatementsPerConnection > 0) {
            this.scache = new DoubleMaxStatementCache(taskRunner, maxStatements, maxStatementsPerConnection);
         } else if (maxStatementsPerConnection > 0) {
            this.scache = new PerConnectionMaxOnlyStatementCache(taskRunner, maxStatementsPerConnection);
         } else if (maxStatements > 0) {
            this.scache = new GlobalMaxOnlyStatementCache(taskRunner, maxStatements);
         } else {
            this.scache = null;
         }

         this.connectionTester = connectionTester;
         this.checkoutTimeout = checkoutTimeout;
         this.sharedTaskRunner = taskRunner;
         Manager manager = new 1PooledConnectionResourcePoolManager(this, connectionTester, cpds, connectionCustomizer, auth, parentDataSourceIdentityToken, testConnectionOnCheckout, testConnectionOnCheckin, testQuery);
         synchronized(fact) {
            fact.setMin(min);
            fact.setMax(max);
            fact.setStart(start);
            fact.setIncrement(inc);
            fact.setIdleResourceTestPeriod((long)(idleConnectionTestPeriod * 1000));
            fact.setResourceMaxIdleTime((long)(maxIdleTime * 1000));
            fact.setExcessResourceMaxIdleTime((long)(maxIdleTimeExcessConnections * 1000));
            fact.setResourceMaxAge((long)(maxConnectionAge * 1000));
            fact.setExpirationEnforcementDelay((long)(propertyCycle * 1000));
            fact.setDestroyOverdueResourceTime((long)(unreturnedConnectionTimeout * 1000));
            fact.setDebugStoreCheckoutStackTrace(debugUnreturnedConnectionStackTraces);
            fact.setAcquisitionRetryAttempts(acq_retry_attempts);
            fact.setAcquisitionRetryDelay(acq_retry_delay);
            fact.setBreakOnAcquisitionFailure(break_after_acq_failure);
            this.rp = fact.createPool(manager);
         }
      } catch (ResourcePoolException var32) {
         throw SqlUtils.toSQLException(var32);
      }
   }

   public PooledConnection checkoutPooledConnection() throws SQLException {
      try {
         return (PooledConnection)this.rp.checkoutResource((long)this.checkoutTimeout);
      } catch (TimeoutException var2) {
         throw SqlUtils.toSQLException("An attempt by a client to checkout a Connection has timed out.", var2);
      } catch (CannotAcquireResourceException var3) {
         throw SqlUtils.toSQLException("Connections could not be acquired from the underlying database!", "08001", var3);
      } catch (Exception var4) {
         throw SqlUtils.toSQLException(var4);
      }
   }

   public void checkinPooledConnection(PooledConnection pcon) throws SQLException {
      try {
         this.rp.checkinResource(pcon);
      } catch (ResourcePoolException var3) {
         throw SqlUtils.toSQLException(var3);
      }
   }

   public float getEffectivePropertyCycle() throws SQLException {
      try {
         return (float)this.rp.getEffectiveExpirationEnforcementDelay() / 1000.0F;
      } catch (ResourcePoolException var2) {
         throw SqlUtils.toSQLException(var2);
      }
   }

   public int getNumThreadsAwaitingCheckout() throws SQLException {
      try {
         return this.rp.getNumCheckoutWaiters();
      } catch (ResourcePoolException var2) {
         throw SqlUtils.toSQLException(var2);
      }
   }

   public int getStatementCacheNumStatements() {
      return this.scache == null ? 0 : this.scache.getNumStatements();
   }

   public int getStatementCacheNumCheckedOut() {
      return this.scache == null ? 0 : this.scache.getNumStatementsCheckedOut();
   }

   public int getStatementCacheNumConnectionsWithCachedStatements() {
      return this.scache == null ? 0 : this.scache.getNumConnectionsWithCachedStatements();
   }

   public String dumpStatementCacheStatus() {
      return this.scache == null ? "Statement caching disabled." : this.scache.dumpStatementCacheStatus();
   }

   public void close() throws SQLException {
      this.close(true);
   }

   public void close(boolean close_outstanding_connections) throws SQLException {
      Object throwMe = null;

      try {
         if (this.scache != null) {
            this.scache.close();
         }
      } catch (SQLException var4) {
         throwMe = var4;
      }

      try {
         this.rp.close(close_outstanding_connections);
      } catch (ResourcePoolException var5) {
         if (throwMe != null && logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while closing the StatementCache.", (Throwable)throwMe);
         }

         throwMe = var5;
      }

      if (throwMe != null) {
         throw SqlUtils.toSQLException((Throwable)throwMe);
      }
   }

   public int getNumConnections() throws SQLException {
      try {
         return this.rp.getPoolSize();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public int getNumIdleConnections() throws SQLException {
      try {
         return this.rp.getAvailableCount();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public int getNumBusyConnections() throws SQLException {
      try {
         ResourcePool var1 = this.rp;
         synchronized(this.rp) {
            return this.rp.getAwaitingCheckinCount() - this.rp.getExcludedCount();
         }
      } catch (Exception var4) {
         logger.log(MLevel.WARNING, (String)null, var4);
         throw SqlUtils.toSQLException(var4);
      }
   }

   public int getNumUnclosedOrphanedConnections() throws SQLException {
      try {
         return this.rp.getExcludedCount();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public long getStartTime() throws SQLException {
      try {
         return this.rp.getStartTime();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public long getUpTime() throws SQLException {
      try {
         return this.rp.getUpTime();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public long getNumFailedCheckins() throws SQLException {
      try {
         return this.rp.getNumFailedCheckins();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public long getNumFailedCheckouts() throws SQLException {
      try {
         return this.rp.getNumFailedCheckouts();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public long getNumFailedIdleTests() throws SQLException {
      try {
         return this.rp.getNumFailedIdleTests();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public Throwable getLastCheckinFailure() throws SQLException {
      try {
         return this.rp.getLastCheckinFailure();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public Throwable getLastCheckoutFailure() throws SQLException {
      try {
         return this.rp.getLastCheckoutFailure();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public Throwable getLastIdleTestFailure() throws SQLException {
      try {
         return this.rp.getLastIdleCheckFailure();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public Throwable getLastConnectionTestFailure() throws SQLException {
      try {
         return this.rp.getLastResourceTestFailure();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public Throwable getLastAcquisitionFailure() throws SQLException {
      try {
         return this.rp.getLastAcquisitionFailure();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   public void reset() throws SQLException {
      try {
         this.rp.resetPool();
      } catch (Exception var2) {
         logger.log(MLevel.WARNING, (String)null, var2);
         throw SqlUtils.toSQLException(var2);
      }
   }

   static {
      logger = MLog.getLogger(C3P0PooledConnectionPool.class);
   }
}