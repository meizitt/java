package com.mchange.v2.resourcepool;

import java.util.EventListener;

public interface ResourcePoolListener extends EventListener {
   void resourceAcquired(ResourcePoolEvent var1);

   void resourceCheckedIn(ResourcePoolEvent var1);

   void resourceCheckedOut(ResourcePoolEvent var1);

   void resourceRemoved(ResourcePoolEvent var1);
}