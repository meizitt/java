package com.mchange.v2.codegen.bean;

public interface ResolvedProperty extends Property {
   Class getType();
}