package com.mchange.v2.management;

import com.mchange.v2.management.ManagementUtils.1;
import com.mchange.v2.management.ManagementUtils.2;
import java.util.Comparator;

public class ManagementUtils {
   public static final Comparator PARAM_INFO_COMPARATOR = new 1();
   public static final Comparator OP_INFO_COMPARATOR = new 2();
}