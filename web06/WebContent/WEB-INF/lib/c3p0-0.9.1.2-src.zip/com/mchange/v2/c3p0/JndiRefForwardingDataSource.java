package com.mchange.v2.c3p0;

import com.mchange.v2.c3p0.JndiRefForwardingDataSource.1;
import com.mchange.v2.c3p0.JndiRefForwardingDataSource.2;
import com.mchange.v2.c3p0.impl.JndiRefDataSourceBase;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.sql.SqlUtils;
import java.beans.PropertyChangeListener;
import java.beans.VetoableChangeListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Hashtable;
import javax.naming.InitialContext;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.sql.DataSource;

final class JndiRefForwardingDataSource extends JndiRefDataSourceBase implements DataSource {
   static final MLogger logger;
   transient DataSource cachedInner;
   private static final long serialVersionUID = 1L;
   private static final short VERSION = 1;

   public JndiRefForwardingDataSource() {
      this(true);
   }

   public JndiRefForwardingDataSource(boolean autoregister) {
      super(autoregister);
      this.setUpPropertyListeners();
   }

   private void setUpPropertyListeners() {
      VetoableChangeListener l = new 1(this);
      this.addVetoableChangeListener(l);
      PropertyChangeListener pcl = new 2(this);
      this.addPropertyChangeListener(pcl);
   }

   private DataSource dereference() throws SQLException {
      Object jndiName = this.getJndiName();
      Hashtable jndiEnv = this.getJndiEnv();

      try {
         InitialContext ctx;
         if (jndiEnv != null) {
            ctx = new InitialContext(jndiEnv);
         } else {
            ctx = new InitialContext();
         }

         if (jndiName instanceof String) {
            return (DataSource)ctx.lookup((String)jndiName);
         } else if (jndiName instanceof Name) {
            return (DataSource)ctx.lookup((Name)jndiName);
         } else {
            throw new SQLException("Could not find ConnectionPoolDataSource with JNDI name: " + jndiName);
         }
      } catch (NamingException var4) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while trying to look up a target DataSource via JNDI!", var4);
         }

         throw SqlUtils.toSQLException(var4);
      }
   }

   private synchronized DataSource inner() throws SQLException {
      if (this.cachedInner != null) {
         return this.cachedInner;
      } else {
         DataSource out = this.dereference();
         if (this.isCaching()) {
            this.cachedInner = out;
         }

         return out;
      }
   }

   public Connection getConnection() throws SQLException {
      return this.inner().getConnection();
   }

   public Connection getConnection(String username, String password) throws SQLException {
      return this.inner().getConnection(username, password);
   }

   public PrintWriter getLogWriter() throws SQLException {
      return this.inner().getLogWriter();
   }

   public void setLogWriter(PrintWriter out) throws SQLException {
      this.inner().setLogWriter(out);
   }

   public int getLoginTimeout() throws SQLException {
      return this.inner().getLoginTimeout();
   }

   public void setLoginTimeout(int seconds) throws SQLException {
      this.inner().setLoginTimeout(seconds);
   }

   private void writeObject(ObjectOutputStream oos) throws IOException {
      oos.writeShort(1);
   }

   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
      short version = ois.readShort();
      switch(version) {
      case 1:
         this.setUpPropertyListeners();
         return;
      default:
         throw new IOException("Unsupported Serialized Version: " + version);
      }
   }

   static {
      logger = MLog.getLogger(JndiRefForwardingDataSource.class);
   }
}