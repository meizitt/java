package com.mchange.v2.sql.filter;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.Map;

public abstract class SynchronizedFilterConnection implements Connection {
   protected Connection inner;

   public SynchronizedFilterConnection(Connection inner) {
      this.inner = inner;
   }

   public SynchronizedFilterConnection() {
   }

   public synchronized void setInner(Connection inner) {
      this.inner = inner;
   }

   public synchronized Connection getInner() {
      return this.inner;
   }

   public synchronized Statement createStatement(int a, int b, int c) throws SQLException {
      return this.inner.createStatement(a, b, c);
   }

   public synchronized Statement createStatement(int a, int b) throws SQLException {
      return this.inner.createStatement(a, b);
   }

   public synchronized Statement createStatement() throws SQLException {
      return this.inner.createStatement();
   }

   public synchronized PreparedStatement prepareStatement(String a, String[] b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public synchronized PreparedStatement prepareStatement(String a) throws SQLException {
      return this.inner.prepareStatement(a);
   }

   public synchronized PreparedStatement prepareStatement(String a, int b, int c) throws SQLException {
      return this.inner.prepareStatement(a, b, c);
   }

   public synchronized PreparedStatement prepareStatement(String a, int b, int c, int d) throws SQLException {
      return this.inner.prepareStatement(a, b, c, d);
   }

   public synchronized PreparedStatement prepareStatement(String a, int b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public synchronized PreparedStatement prepareStatement(String a, int[] b) throws SQLException {
      return this.inner.prepareStatement(a, b);
   }

   public synchronized CallableStatement prepareCall(String a, int b, int c, int d) throws SQLException {
      return this.inner.prepareCall(a, b, c, d);
   }

   public synchronized CallableStatement prepareCall(String a, int b, int c) throws SQLException {
      return this.inner.prepareCall(a, b, c);
   }

   public synchronized CallableStatement prepareCall(String a) throws SQLException {
      return this.inner.prepareCall(a);
   }

   public synchronized String nativeSQL(String a) throws SQLException {
      return this.inner.nativeSQL(a);
   }

   public synchronized void setAutoCommit(boolean a) throws SQLException {
      this.inner.setAutoCommit(a);
   }

   public synchronized boolean getAutoCommit() throws SQLException {
      return this.inner.getAutoCommit();
   }

   public synchronized void commit() throws SQLException {
      this.inner.commit();
   }

   public synchronized void rollback(Savepoint a) throws SQLException {
      this.inner.rollback(a);
   }

   public synchronized void rollback() throws SQLException {
      this.inner.rollback();
   }

   public synchronized DatabaseMetaData getMetaData() throws SQLException {
      return this.inner.getMetaData();
   }

   public synchronized void setCatalog(String a) throws SQLException {
      this.inner.setCatalog(a);
   }

   public synchronized String getCatalog() throws SQLException {
      return this.inner.getCatalog();
   }

   public synchronized void setTransactionIsolation(int a) throws SQLException {
      this.inner.setTransactionIsolation(a);
   }

   public synchronized int getTransactionIsolation() throws SQLException {
      return this.inner.getTransactionIsolation();
   }

   public synchronized SQLWarning getWarnings() throws SQLException {
      return this.inner.getWarnings();
   }

   public synchronized void clearWarnings() throws SQLException {
      this.inner.clearWarnings();
   }

   public synchronized Map getTypeMap() throws SQLException {
      return this.inner.getTypeMap();
   }

   public synchronized void setTypeMap(Map a) throws SQLException {
      this.inner.setTypeMap(a);
   }

   public synchronized void setHoldability(int a) throws SQLException {
      this.inner.setHoldability(a);
   }

   public synchronized int getHoldability() throws SQLException {
      return this.inner.getHoldability();
   }

   public synchronized Savepoint setSavepoint() throws SQLException {
      return this.inner.setSavepoint();
   }

   public synchronized Savepoint setSavepoint(String a) throws SQLException {
      return this.inner.setSavepoint(a);
   }

   public synchronized void releaseSavepoint(Savepoint a) throws SQLException {
      this.inner.releaseSavepoint(a);
   }

   public synchronized void setReadOnly(boolean a) throws SQLException {
      this.inner.setReadOnly(a);
   }

   public synchronized boolean isReadOnly() throws SQLException {
      return this.inner.isReadOnly();
   }

   public synchronized void close() throws SQLException {
      this.inner.close();
   }

   public synchronized boolean isClosed() throws SQLException {
      return this.inner.isClosed();
   }
}