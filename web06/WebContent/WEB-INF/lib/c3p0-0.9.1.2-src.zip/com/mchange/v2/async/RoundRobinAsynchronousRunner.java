package com.mchange.v2.async;

import com.mchange.v2.async.RoundRobinAsynchronousRunner.RunnableQueueView;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.util.ResourceClosedException;

public class RoundRobinAsynchronousRunner implements AsynchronousRunner, Queuable {
   private static final MLogger logger;
   final RunnableQueue[] rqs;
   int task_turn = 0;
   int view_turn = 0;

   public RoundRobinAsynchronousRunner(int num_threads, boolean daemon) {
      this.rqs = new RunnableQueue[num_threads];

      for(int i = 0; i < num_threads; ++i) {
         this.rqs[i] = new CarefulRunnableQueue(daemon, false);
      }

   }

   public synchronized void postRunnable(Runnable r) {
      try {
         int index = this.task_turn;
         this.task_turn = (this.task_turn + 1) % this.rqs.length;
         this.rqs[index].postRunnable(r);
      } catch (NullPointerException var3) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "NullPointerException while posting Runnable -- Probably we're closed.", var3);
         }

         this.close(true);
         throw new ResourceClosedException("Attempted to use a RoundRobinAsynchronousRunner in a closed or broken state.");
      }
   }

   public synchronized RunnableQueue asRunnableQueue() {
      try {
         int index = this.view_turn;
         this.view_turn = (this.view_turn + 1) % this.rqs.length;
         return new RunnableQueueView(this, index);
      } catch (NullPointerException var2) {
         if (logger.isLoggable(MLevel.FINE)) {
            logger.log(MLevel.FINE, "NullPointerException in asRunnableQueue() -- Probably we're closed.", var2);
         }

         this.close(true);
         throw new ResourceClosedException("Attempted to use a RoundRobinAsynchronousRunner in a closed or broken state.");
      }
   }

   public synchronized void close(boolean skip_remaining_tasks) {
      int i = 0;

      for(int len = this.rqs.length; i < len; ++i) {
         attemptClose(this.rqs[i], skip_remaining_tasks);
         this.rqs[i] = null;
      }

   }

   public void close() {
      this.close(true);
   }

   static void attemptClose(RunnableQueue rq, boolean skip_remaining_tasks) {
      try {
         rq.close(skip_remaining_tasks);
      } catch (Exception var3) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "RunnableQueue close FAILED.", var3);
         }
      }

   }

   static {
      logger = MLog.getLogger(RoundRobinAsynchronousRunner.class);
   }
}