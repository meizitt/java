package com.mchange.v2.ser;

public interface Indirector {
   IndirectlySerialized indirectForm(Object var1) throws Exception;
}