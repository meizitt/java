package com.mchange.v2.c3p0.impl;

import com.mchange.v2.lang.ObjectUtils;
import com.mchange.v2.ser.UnsupportedVersionException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public final class DbAuth implements Serializable {
   transient String username;
   transient String password;
   static final long serialVersionUID = 1L;
   private static final short VERSION = 1;

   public DbAuth(String username, String password) {
      this.username = username;
      this.password = password;
   }

   public String getUser() {
      return this.username;
   }

   public String getPassword() {
      return this.password;
   }

   public boolean equals(Object o) {
      if (this == o) {
         return true;
      } else if (o != null && this.getClass() == o.getClass()) {
         DbAuth other = (DbAuth)o;
         return ObjectUtils.eqOrBothNull(this.username, other.username) && ObjectUtils.eqOrBothNull(this.password, other.password);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return ObjectUtils.hashOrZero(this.username) ^ ObjectUtils.hashOrZero(this.password);
   }

   private void writeObject(ObjectOutputStream out) throws IOException {
      out.writeShort(1);
      out.writeObject(this.username);
      out.writeObject(this.password);
   }

   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
      short version = in.readShort();
      switch(version) {
      case 1:
         this.username = (String)in.readObject();
         this.password = (String)in.readObject();
         return;
      default:
         throw new UnsupportedVersionException(this, version);
      }
   }
}