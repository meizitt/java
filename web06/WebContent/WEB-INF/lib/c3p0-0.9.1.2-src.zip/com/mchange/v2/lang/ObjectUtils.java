package com.mchange.v2.lang;

public final class ObjectUtils {
   public static boolean eqOrBothNull(Object a, Object b) {
      if (a == b) {
         return true;
      } else {
         return a == null ? false : a.equals(b);
      }
   }

   public static int hashOrZero(Object o) {
      return o == null ? 0 : o.hashCode();
   }
}