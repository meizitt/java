package com.mchange.v2.log;

public class PackageNames implements NameTransformer {
   public String transformName(String name) {
      return null;
   }

   public String transformName(Class cl) {
      String fqcn = cl.getName();
      int i = fqcn.lastIndexOf(46);
      return i <= 0 ? "" : fqcn.substring(0, i);
   }

   public String transformName() {
      return null;
   }
}