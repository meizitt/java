package com.mchange.v2.c3p0;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.sql.Statement;

public interface C3P0ProxyStatement extends Statement {
   Object RAW_STATEMENT = new Object();

   Object rawStatementOperation(Method var1, Object var2, Object[] var3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, SQLException;
}