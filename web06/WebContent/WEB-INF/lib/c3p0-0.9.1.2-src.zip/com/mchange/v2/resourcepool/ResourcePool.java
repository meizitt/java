package com.mchange.v2.resourcepool;

import com.mchange.v1.util.ClosableResource;

public interface ResourcePool extends ClosableResource {
   int KNOWN_AND_AVAILABLE = 0;
   int KNOWN_AND_CHECKED_OUT = 1;
   int UNKNOWN_OR_PURGED = -1;

   Object checkoutResource() throws ResourcePoolException, InterruptedException;

   Object checkoutResource(long var1) throws TimeoutException, ResourcePoolException, InterruptedException;

   void checkinResource(Object var1) throws ResourcePoolException;

   void checkinAll() throws ResourcePoolException;

   int statusInPool(Object var1) throws ResourcePoolException;

   void markBroken(Object var1) throws ResourcePoolException;

   int getMinPoolSize() throws ResourcePoolException;

   int getMaxPoolSize() throws ResourcePoolException;

   int getPoolSize() throws ResourcePoolException;

   void setPoolSize(int var1) throws ResourcePoolException;

   int getAvailableCount() throws ResourcePoolException;

   int getExcludedCount() throws ResourcePoolException;

   int getAwaitingCheckinCount() throws ResourcePoolException;

   long getEffectiveExpirationEnforcementDelay() throws ResourcePoolException;

   long getStartTime() throws ResourcePoolException;

   long getUpTime() throws ResourcePoolException;

   long getNumFailedCheckins() throws ResourcePoolException;

   long getNumFailedCheckouts() throws ResourcePoolException;

   long getNumFailedIdleTests() throws ResourcePoolException;

   int getNumCheckoutWaiters() throws ResourcePoolException;

   Throwable getLastAcquisitionFailure() throws ResourcePoolException;

   Throwable getLastCheckinFailure() throws ResourcePoolException;

   Throwable getLastCheckoutFailure() throws ResourcePoolException;

   Throwable getLastIdleCheckFailure() throws ResourcePoolException;

   Throwable getLastResourceTestFailure() throws ResourcePoolException;

   void resetPool() throws ResourcePoolException;

   void close() throws ResourcePoolException;

   void close(boolean var1) throws ResourcePoolException;
}