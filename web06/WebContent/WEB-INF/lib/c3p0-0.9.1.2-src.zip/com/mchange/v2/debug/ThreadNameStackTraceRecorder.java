package com.mchange.v2.debug;

import com.mchange.lang.ThrowableUtils;
import com.mchange.v2.debug.ThreadNameStackTraceRecorder.Record;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ThreadNameStackTraceRecorder {
   static final String NL = System.getProperty("line.separator", "\r\n");
   Set set;
   String dumpHeader;
   String stackTraceHeader;

   public ThreadNameStackTraceRecorder(String dumpHeader) {
      this(dumpHeader, "Debug Stack Trace.");
   }

   public ThreadNameStackTraceRecorder(String dumpHeader, String stackTraceHeader) {
      this.set = new HashSet();
      this.dumpHeader = dumpHeader;
      this.stackTraceHeader = stackTraceHeader;
   }

   public synchronized Object record() {
      Record r = new Record(this.stackTraceHeader);
      this.set.add(r);
      return r;
   }

   public synchronized void remove(Object rec) {
      this.set.remove(rec);
   }

   public synchronized int size() {
      return this.set.size();
   }

   public synchronized String getDump() {
      return this.getDump((String)null);
   }

   public synchronized String getDump(String locationSpecificNote) {
      DateFormat df = new SimpleDateFormat("dd-MMMM-yyyy HH:mm:ss.SSSS");
      StringBuffer sb = new StringBuffer(2047);
      sb.append(NL);
      sb.append("----------------------------------------------------");
      sb.append(NL);
      sb.append(this.dumpHeader);
      sb.append(NL);
      if (locationSpecificNote != null) {
         sb.append(locationSpecificNote);
         sb.append(NL);
      }

      boolean first = true;
      Iterator ii = this.set.iterator();

      while(ii.hasNext()) {
         if (first) {
            first = false;
         } else {
            sb.append("---");
            sb.append(NL);
         }

         Record r = (Record)ii.next();
         sb.append(df.format(new Date(r.time)));
         sb.append(" --> Thread Name: ");
         sb.append(r.threadName);
         sb.append(NL);
         sb.append("Stack Trace: ");
         sb.append(ThrowableUtils.extractStackTrace(r.stackTrace));
      }

      sb.append("----------------------------------------------------");
      sb.append(NL);
      return sb.toString();
   }
}