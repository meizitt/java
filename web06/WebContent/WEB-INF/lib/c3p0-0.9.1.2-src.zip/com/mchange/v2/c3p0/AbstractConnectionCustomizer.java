package com.mchange.v2.c3p0;

import java.sql.Connection;

public abstract class AbstractConnectionCustomizer implements ConnectionCustomizer {
   public void onAcquire(Connection c, String parentDataSourceIdentityToken) throws Exception {
   }

   public void onDestroy(Connection c, String parentDataSourceIdentityToken) throws Exception {
   }

   public void onCheckOut(Connection c, String parentDataSourceIdentityToken) throws Exception {
   }

   public void onCheckIn(Connection c, String parentDataSourceIdentityToken) throws Exception {
   }
}