package com.mchange.v2.c3p0.cfg;

import com.mchange.v1.lang.BooleanUtils;
import com.mchange.v2.beans.BeansUtils;
import com.mchange.v2.c3p0.impl.C3P0Defaults;
import com.mchange.v2.c3p0.impl.C3P0ImplUtils;
import com.mchange.v2.cfg.MultiPropertiesConfig;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.beans.IntrospectionException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class C3P0Config {
   public static final String CFG_FINDER_CLASSNAME_KEY = "com.mchange.v2.c3p0.cfg.finder";
   public static final String DEFAULT_CONFIG_NAME = "default";
   public static final C3P0Config MAIN;
   static final MLogger logger;
   static final Class[] SUOAS_ARGS;
   static final Collection SKIP_BIND_PROPS;
   NamedScope defaultConfig;
   HashMap configNamesToNamedScopes;

   private static void warnOnUnknownProperties(C3P0Config cfg) {
      warnOnUnknownProperties(cfg.defaultConfig);
      Iterator ii = cfg.configNamesToNamedScopes.values().iterator();

      while(ii.hasNext()) {
         warnOnUnknownProperties((NamedScope)ii.next());
      }

   }

   private static void warnOnUnknownProperties(NamedScope scope) {
      warnOnUnknownProperties((Map)scope.props);
      Iterator ii = scope.userNamesToOverrides.values().iterator();

      while(ii.hasNext()) {
         warnOnUnknownProperties((Map)ii.next());
      }

   }

   private static void warnOnUnknownProperties(Map propMap) {
      Iterator ii = propMap.keySet().iterator();

      while(ii.hasNext()) {
         String prop = (String)ii.next();
         if (!C3P0Defaults.isKnownProperty(prop) && logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Unknown c3p0-config property: " + prop);
         }
      }

   }

   public static String getUnspecifiedUserProperty(String propKey, String configName) {
      String out = null;
      if (configName == null) {
         out = (String)MAIN.defaultConfig.props.get(propKey);
      } else {
         NamedScope named = (NamedScope)MAIN.configNamesToNamedScopes.get(configName);
         if (named != null) {
            out = (String)named.props.get(propKey);
         } else {
            logger.warning("named-config with name '" + configName + "' does not exist. Using default-config for property '" + propKey + "'.");
         }

         if (out == null) {
            out = (String)MAIN.defaultConfig.props.get(propKey);
         }
      }

      return out;
   }

   public static Map getUnspecifiedUserProperties(String configName) {
      Map out = new HashMap();
      out.putAll(MAIN.defaultConfig.props);
      if (configName != null) {
         NamedScope named = (NamedScope)MAIN.configNamesToNamedScopes.get(configName);
         if (named != null) {
            out.putAll(named.props);
         } else {
            logger.warning("named-config with name '" + configName + "' does not exist. Using default-config.");
         }
      }

      return out;
   }

   public static Map getUserOverrides(String configName) {
      Map out = new HashMap();
      NamedScope namedConfigScope = null;
      if (configName != null) {
         namedConfigScope = (NamedScope)MAIN.configNamesToNamedScopes.get(configName);
      }

      out.putAll(MAIN.defaultConfig.userNamesToOverrides);
      if (namedConfigScope != null) {
         out.putAll(namedConfigScope.userNamesToOverrides);
      }

      return out.isEmpty() ? null : out;
   }

   public static String getUserOverridesAsString(String configName) throws IOException {
      Map userOverrides = getUserOverrides(configName);
      return userOverrides == null ? null : C3P0ImplUtils.createUserOverridesAsString(userOverrides).intern();
   }

   public static void bindNamedConfigToBean(Object bean, String configName) throws IntrospectionException {
      Map defaultUserProps = getUnspecifiedUserProperties(configName);
      BeansUtils.overwriteAccessiblePropertiesFromMap(defaultUserProps, bean, false, SKIP_BIND_PROPS, true, MLevel.FINEST, MLevel.WARNING, false);

      try {
         Method m = bean.getClass().getMethod("setUserOverridesAsString", SUOAS_ARGS);
         m.invoke(bean, getUserOverridesAsString(configName));
      } catch (NoSuchMethodException var4) {
         var4.printStackTrace();
      } catch (Exception var5) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An exception occurred while trying to bind user overrides for named config '" + configName + "'. Only default user configs " + "will be used.", var5);
         }
      }

   }

   public static String initializeUserOverridesAsString() {
      try {
         return getUserOverridesAsString((String)null);
      } catch (Exception var1) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Error initializing default user overrides. User overrides may be ignored.", var1);
         }

         return null;
      }
   }

   public static String initializeStringPropertyVar(String propKey, String dflt) {
      String out = getUnspecifiedUserProperty(propKey, (String)null);
      if (out == null) {
         out = dflt;
      }

      return out;
   }

   public static int initializeIntPropertyVar(String propKey, int dflt) {
      boolean set = false;
      int out = -1;
      String outStr = getUnspecifiedUserProperty(propKey, (String)null);
      if (outStr != null) {
         try {
            out = Integer.parseInt(outStr.trim());
            set = true;
         } catch (NumberFormatException var6) {
            logger.info("'" + outStr + "' is not a legal value for property '" + propKey + "'. Using default value: " + dflt);
         }
      }

      if (!set) {
         out = dflt;
      }

      return out;
   }

   public static boolean initializeBooleanPropertyVar(String propKey, boolean dflt) {
      boolean set = false;
      boolean out = false;
      String outStr = getUnspecifiedUserProperty(propKey, (String)null);
      if (outStr != null) {
         try {
            out = BooleanUtils.parseBoolean(outStr.trim());
            set = true;
         } catch (IllegalArgumentException var6) {
            logger.info("'" + outStr + "' is not a legal value for property '" + propKey + "'. Using default value: " + dflt);
         }
      }

      if (!set) {
         out = dflt;
      }

      return out;
   }

   C3P0Config(NamedScope defaultConfig, HashMap configNamesToNamedScopes) {
      this.defaultConfig = defaultConfig;
      this.configNamesToNamedScopes = configNamesToNamedScopes;
   }

   static {
      logger = MLog.getLogger(C3P0Config.class);
      String cname = MultiPropertiesConfig.readVmConfig().getProperty("com.mchange.v2.c3p0.cfg.finder");
      Object cfgFinder = null;

      try {
         if (cname != null) {
            cfgFinder = (C3P0ConfigFinder)Class.forName(cname).newInstance();
         }
      } catch (Exception var6) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Could not load specified C3P0ConfigFinder class'" + cname + "'.", var6);
         }
      }

      C3P0Config protoMain;
      try {
         if (cfgFinder == null) {
            Class.forName("org.w3c.dom.Node");
            Class.forName("com.mchange.v2.c3p0.cfg.C3P0ConfigXmlUtils");
            cfgFinder = new DefaultC3P0ConfigFinder();
         }

         protoMain = ((C3P0ConfigFinder)cfgFinder).findConfig();
      } catch (Exception var5) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "XML configuration disabled! Verify that standard XML libs are available.", var5);
         }

         HashMap flatDefaults = C3P0ConfigUtils.extractHardcodedC3P0Defaults();
         flatDefaults.putAll(C3P0ConfigUtils.extractC3P0PropertiesResources());
         protoMain = C3P0ConfigUtils.configFromFlatDefaults(flatDefaults);
      }

      MAIN = protoMain;
      warnOnUnknownProperties(MAIN);
      SUOAS_ARGS = new Class[]{String.class};
      SKIP_BIND_PROPS = Arrays.asList("loginTimeout", "properties");
   }
}