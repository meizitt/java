package com.mchange.v2.sql.filter;

import com.mchange.v1.lang.ClassUtils;
import com.mchange.v2.codegen.intfc.DelegatorGenerator;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;

public final class RecreatePackage {
   static final Class[] intfcs;

   public static void main(String[] argv) {
      try {
         DelegatorGenerator dg = new DelegatorGenerator();
         String thisClassName = RecreatePackage.class.getName();
         String pkg = thisClassName.substring(0, thisClassName.lastIndexOf(46));

         for(int i = 0; i < intfcs.length; ++i) {
            Class intfcl = intfcs[i];
            String sin = ClassUtils.simpleClassName(intfcl);
            String sgenclass1 = "Filter" + sin;
            String sgenclass2 = "SynchronizedFilter" + sin;
            BufferedWriter w = null;

            try {
               w = new BufferedWriter(new FileWriter(sgenclass1 + ".java"));
               dg.setMethodModifiers(1);
               dg.writeDelegator(intfcl, pkg + '.' + sgenclass1, w);
               System.err.println(sgenclass1);
            } finally {
               try {
                  if (w != null) {
                     w.close();
                  }
               } catch (Exception var29) {
                  var29.printStackTrace();
               }

            }

            try {
               w = new BufferedWriter(new FileWriter(sgenclass2 + ".java"));
               dg.setMethodModifiers(33);
               dg.writeDelegator(intfcl, pkg + '.' + sgenclass2, w);
               System.err.println(sgenclass2);
            } finally {
               try {
                  if (w != null) {
                     w.close();
                  }
               } catch (Exception var28) {
                  var28.printStackTrace();
               }

            }
         }
      } catch (Exception var32) {
         var32.printStackTrace();
      }

   }

   static {
      intfcs = new Class[]{Connection.class, ResultSet.class, DatabaseMetaData.class, Statement.class, PreparedStatement.class, CallableStatement.class, DataSource.class};
   }
}