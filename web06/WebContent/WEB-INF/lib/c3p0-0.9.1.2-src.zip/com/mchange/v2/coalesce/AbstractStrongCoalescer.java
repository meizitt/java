package com.mchange.v2.coalesce;

import java.util.Iterator;
import java.util.Map;

class AbstractStrongCoalescer implements Coalescer {
   Map coalesced;

   AbstractStrongCoalescer(Map coalesced) {
      this.coalesced = coalesced;
   }

   public Object coalesce(Object o) {
      Object out = this.coalesced.get(o);
      if (out == null) {
         this.coalesced.put(o, o);
         out = o;
      }

      return out;
   }

   public int countCoalesced() {
      return this.coalesced.size();
   }

   public Iterator iterator() {
      return new CoalescerIterator(this.coalesced.keySet().iterator());
   }
}