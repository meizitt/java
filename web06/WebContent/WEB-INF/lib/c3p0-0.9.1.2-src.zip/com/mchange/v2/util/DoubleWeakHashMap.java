package com.mchange.v2.util;

import com.mchange.v2.util.DoubleWeakHashMap.1;
import com.mchange.v2.util.DoubleWeakHashMap.CheckKeyHolder;
import com.mchange.v2.util.DoubleWeakHashMap.UserEntrySet;
import com.mchange.v2.util.DoubleWeakHashMap.UserKeySet;
import com.mchange.v2.util.DoubleWeakHashMap.ValuesCollection;
import com.mchange.v2.util.DoubleWeakHashMap.WKey;
import com.mchange.v2.util.DoubleWeakHashMap.WVal;
import java.lang.ref.ReferenceQueue;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class DoubleWeakHashMap implements Map {
   HashMap inner;
   ReferenceQueue keyQ;
   ReferenceQueue valQ;
   CheckKeyHolder holder;
   Set userKeySet;
   Collection valuesCollection;

   public DoubleWeakHashMap() {
      this.keyQ = new ReferenceQueue();
      this.valQ = new ReferenceQueue();
      this.holder = new CheckKeyHolder();
      this.userKeySet = null;
      this.valuesCollection = null;
      this.inner = new HashMap();
   }

   public DoubleWeakHashMap(int initialCapacity) {
      this.keyQ = new ReferenceQueue();
      this.valQ = new ReferenceQueue();
      this.holder = new CheckKeyHolder();
      this.userKeySet = null;
      this.valuesCollection = null;
      this.inner = new HashMap(initialCapacity);
   }

   public DoubleWeakHashMap(int initialCapacity, float loadFactor) {
      this.keyQ = new ReferenceQueue();
      this.valQ = new ReferenceQueue();
      this.holder = new CheckKeyHolder();
      this.userKeySet = null;
      this.valuesCollection = null;
      this.inner = new HashMap(initialCapacity, loadFactor);
   }

   public DoubleWeakHashMap(Map m) {
      this();
      this.putAll(m);
   }

   public void cleanCleared() {
      WKey wk;
      while((wk = (WKey)this.keyQ.poll()) != null) {
         this.inner.remove(wk);
      }

      WVal wv;
      while((wv = (WVal)this.valQ.poll()) != null) {
         this.inner.remove(wv.getWKey());
      }

   }

   public void clear() {
      this.cleanCleared();
      this.inner.clear();
   }

   public boolean containsKey(Object key) {
      this.cleanCleared();

      boolean var2;
      try {
         var2 = this.inner.containsKey(this.holder.set(key));
      } finally {
         this.holder.clear();
      }

      return var2;
   }

   public boolean containsValue(Object val) {
      Iterator ii = this.inner.values().iterator();

      WVal wval;
      do {
         if (!ii.hasNext()) {
            return false;
         }

         wval = (WVal)ii.next();
      } while(!val.equals(wval.get()));

      return true;
   }

   public Set entrySet() {
      this.cleanCleared();
      return new UserEntrySet(this, (1)null);
   }

   public Object get(Object key) {
      Object var3;
      try {
         this.cleanCleared();
         WVal wval = (WVal)this.inner.get(this.holder.set(key));
         var3 = wval == null ? null : wval.get();
      } finally {
         this.holder.clear();
      }

      return var3;
   }

   public boolean isEmpty() {
      this.cleanCleared();
      return this.inner.isEmpty();
   }

   public Set keySet() {
      this.cleanCleared();
      if (this.userKeySet == null) {
         this.userKeySet = new UserKeySet(this);
      }

      return this.userKeySet;
   }

   public Object put(Object key, Object val) {
      this.cleanCleared();
      WVal wout = this.doPut(key, val);
      return wout != null ? wout.get() : null;
   }

   private WVal doPut(Object key, Object val) {
      WKey wk = new WKey(key, this.keyQ);
      WVal wv = new WVal(wk, val, this.valQ);
      return (WVal)this.inner.put(wk, wv);
   }

   public void putAll(Map m) {
      this.cleanCleared();
      Iterator ii = m.entrySet().iterator();

      while(ii.hasNext()) {
         Entry entry = (Entry)ii.next();
         this.doPut(entry.getKey(), entry.getValue());
      }

   }

   public Object remove(Object key) {
      Object var3;
      try {
         this.cleanCleared();
         WVal wv = (WVal)this.inner.remove(this.holder.set(key));
         var3 = wv == null ? null : wv.get();
      } finally {
         this.holder.clear();
      }

      return var3;
   }

   public int size() {
      this.cleanCleared();
      return this.inner.size();
   }

   public Collection values() {
      if (this.valuesCollection == null) {
         this.valuesCollection = new ValuesCollection(this);
      }

      return this.valuesCollection;
   }
}