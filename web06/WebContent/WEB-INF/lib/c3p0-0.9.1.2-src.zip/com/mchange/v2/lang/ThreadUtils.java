package com.mchange.v2.lang;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.lang.reflect.Method;

public final class ThreadUtils {
   private static final MLogger logger;
   static final Method holdsLock;

   public static void enumerateAll(Thread[] threads) {
      ThreadGroupUtils.rootThreadGroup().enumerate(threads);
   }

   public static Boolean reflectiveHoldsLock(Object o) {
      try {
         return holdsLock == null ? null : (Boolean)holdsLock.invoke((Object)null, o);
      } catch (Exception var2) {
         if (logger.isLoggable(MLevel.FINER)) {
            logger.log(MLevel.FINER, "An Exception occurred while trying to call Thread.holdsLock( ... ) reflectively.", var2);
         }

         return null;
      }
   }

   static {
      logger = MLog.getLogger(ThreadUtils.class);

      Method _holdsLock;
      try {
         _holdsLock = Thread.class.getMethod("holdsLock", Object.class);
      } catch (NoSuchMethodException var2) {
         _holdsLock = null;
      }

      holdsLock = _holdsLock;
   }
}