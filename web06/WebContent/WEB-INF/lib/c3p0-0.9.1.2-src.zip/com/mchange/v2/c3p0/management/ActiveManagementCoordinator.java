package com.mchange.v2.c3p0.management;

import com.mchange.v2.c3p0.PooledDataSource;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.lang.management.ManagementFactory;
import javax.management.MBeanServer;
import javax.management.ObjectName;

public class ActiveManagementCoordinator implements ManagementCoordinator {
   private static final String C3P0_REGISTRY_NAME = "com.mchange.v2.c3p0:type=C3P0Registry";
   static final MLogger logger;
   MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

   public ActiveManagementCoordinator() throws Exception {
   }

   public void attemptManageC3P0Registry() {
      try {
         ObjectName name = new ObjectName("com.mchange.v2.c3p0:type=C3P0Registry");
         C3P0RegistryManager mbean = new C3P0RegistryManager();
         if (this.mbs.isRegistered(name)) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.warning("A C3P0Registry mbean is already registered. This probably means that an application using c3p0 was undeployed, but not all PooledDataSources were closed prior to undeployment. This may lead to resource leaks over time. Please take care to close all PooledDataSources.");
            }

            this.mbs.unregisterMBean(name);
         }

         this.mbs.registerMBean(mbean, name);
      } catch (Exception var3) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Failed to set up C3P0RegistryManager mBean. [c3p0 will still function normally, but management via JMX may not be possible.]", var3);
         }
      }

   }

   public void attemptUnmanageC3P0Registry() {
      try {
         ObjectName name = new ObjectName("com.mchange.v2.c3p0:type=C3P0Registry");
         if (this.mbs.isRegistered(name)) {
            this.mbs.unregisterMBean(name);
            if (logger.isLoggable(MLevel.FINER)) {
               logger.log(MLevel.FINER, "C3P0Registry mbean unregistered.");
            }
         } else if (logger.isLoggable(MLevel.FINE)) {
            logger.fine("The C3P0Registry mbean was not found in the registry, so could not be unregistered.");
         }
      } catch (Exception var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while trying to unregister the C3P0RegistryManager mBean." + var2);
         }
      }

   }

   public void attemptManagePooledDataSource(PooledDataSource pds) {
      String name = this.getPdsObjectNameStr(pds);

      try {
         new DynamicPooledDataSourceManagerMBean(pds, name, this.mbs);
      } catch (Exception var4) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Failed to set up a PooledDataSourceManager mBean. [" + name + "] " + "[c3p0 will still functioning normally, but management via JMX may not be possible.]", var4);
         }
      }

   }

   public void attemptUnmanagePooledDataSource(PooledDataSource pds) {
      String nameStr = this.getPdsObjectNameStr(pds);

      try {
         ObjectName name = new ObjectName(nameStr);
         if (this.mbs.isRegistered(name)) {
            this.mbs.unregisterMBean(name);
            if (logger.isLoggable(MLevel.FINER)) {
               logger.log(MLevel.FINER, "MBean: " + nameStr + " unregistered.");
            }
         } else if (logger.isLoggable(MLevel.FINE)) {
            logger.fine("The mbean " + nameStr + " was not found in the registry, so could not be unregistered.");
         }
      } catch (Exception var4) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "An Exception occurred while unregistering mBean. [" + nameStr + "] " + var4);
         }
      }

   }

   private String getPdsObjectNameStr(PooledDataSource pds) {
      return "com.mchange.v2.c3p0:type=PooledDataSource[" + pds.getIdentityToken() + "]";
   }

   static {
      logger = MLog.getLogger(ActiveManagementCoordinator.class);
   }
}