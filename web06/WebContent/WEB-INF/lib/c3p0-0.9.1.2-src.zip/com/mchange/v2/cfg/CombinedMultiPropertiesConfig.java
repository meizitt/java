package com.mchange.v2.cfg;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Map.Entry;

class CombinedMultiPropertiesConfig extends MultiPropertiesConfig {
   MultiPropertiesConfig[] configs;
   String[] resourcePaths;

   CombinedMultiPropertiesConfig(MultiPropertiesConfig[] configs) {
      this.configs = configs;
      List allPaths = new LinkedList();

      for(int i = configs.length - 1; i >= 0; --i) {
         String[] rps = configs[i].getPropertiesResourcePaths();

         for(int j = rps.length - 1; j >= 0; --j) {
            String rp = rps[j];
            if (!allPaths.contains(rp)) {
               allPaths.add(0, rp);
            }
         }
      }

      this.resourcePaths = (String[])((String[])allPaths.toArray(new String[allPaths.size()]));
   }

   public String[] getPropertiesResourcePaths() {
      return (String[])((String[])this.resourcePaths.clone());
   }

   public Properties getPropertiesByResourcePath(String path) {
      for(int i = this.configs.length - 1; i >= 0; --i) {
         MultiPropertiesConfig config = this.configs[i];
         Properties check = config.getPropertiesByResourcePath(path);
         if (check != null) {
            return check;
         }
      }

      return null;
   }

   public Properties getPropertiesByPrefix(String pfx) {
      List entries = new LinkedList();

      for(int i = this.configs.length - 1; i >= 0; --i) {
         MultiPropertiesConfig config = this.configs[i];
         Properties check = config.getPropertiesByPrefix(pfx);
         if (check != null) {
            entries.addAll(0, check.entrySet());
         }
      }

      if (entries.size() == 0) {
         return null;
      } else {
         Properties out = new Properties();
         Iterator ii = entries.iterator();

         while(ii.hasNext()) {
            Entry entry = (Entry)ii.next();
            out.put(entry.getKey(), entry.getValue());
         }

         return out;
      }
   }

   public String getProperty(String key) {
      for(int i = this.configs.length - 1; i >= 0; --i) {
         MultiPropertiesConfig config = this.configs[i];
         String check = config.getProperty(key);
         if (check != null) {
            return check;
         }
      }

      return null;
   }
}