package com.mchange.v2.c3p0.util;

import com.mchange.v2.c3p0.C3P0ProxyConnection;
import com.mchange.v2.c3p0.util.TestUtils.StupidDataSourceInvocationHandler;
import com.mchange.v2.sql.SqlUtils;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;

public final class TestUtils {
   private static final Method OBJECT_EQUALS;
   private static final Method IDENTITY_HASHCODE;
   private static final Method IPCFP;

   public static boolean samePhysicalConnection(C3P0ProxyConnection con1, C3P0ProxyConnection con2) throws SQLException {
      try {
         Object out = con1.rawConnectionOperation(IPCFP, (Object)null, new Object[]{C3P0ProxyConnection.RAW_CONNECTION, con2});
         return (Boolean)out;
      } catch (Exception var3) {
         var3.printStackTrace();
         throw SqlUtils.toSQLException(var3);
      }
   }

   public static boolean isPhysicalConnectionForProxy(Connection physicalConnection, C3P0ProxyConnection proxy) throws SQLException {
      try {
         Object out = proxy.rawConnectionOperation(OBJECT_EQUALS, physicalConnection, new Object[]{C3P0ProxyConnection.RAW_CONNECTION});
         return (Boolean)out;
      } catch (Exception var3) {
         var3.printStackTrace();
         throw SqlUtils.toSQLException(var3);
      }
   }

   public static int physicalConnectionIdentityHashCode(C3P0ProxyConnection conn) throws SQLException {
      try {
         Object out = conn.rawConnectionOperation(IDENTITY_HASHCODE, (Object)null, new Object[]{C3P0ProxyConnection.RAW_CONNECTION});
         return (Integer)out;
      } catch (Exception var2) {
         var2.printStackTrace();
         throw SqlUtils.toSQLException(var2);
      }
   }

   public static DataSource unreliableCommitDataSource(DataSource ds) throws Exception {
      return (DataSource)Proxy.newProxyInstance(TestUtils.class.getClassLoader(), new Class[]{DataSource.class}, new StupidDataSourceInvocationHandler(ds));
   }

   static {
      try {
         OBJECT_EQUALS = Object.class.getMethod("equals", Object.class);
         IDENTITY_HASHCODE = System.class.getMethod("identityHashCode", Object.class);
         IPCFP = TestUtils.class.getMethod("isPhysicalConnectionForProxy", Connection.class, C3P0ProxyConnection.class);
      } catch (Exception var1) {
         var1.printStackTrace();
         throw new RuntimeException("Huh? Can't reflectively get ahold of expected methods?");
      }
   }
}