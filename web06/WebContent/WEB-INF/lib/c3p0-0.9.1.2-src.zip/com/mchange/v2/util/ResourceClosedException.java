package com.mchange.v2.util;

import com.mchange.v2.lang.VersionUtils;

public class ResourceClosedException extends RuntimeException {
   Throwable rootCause;

   public ResourceClosedException(String msg, Throwable t) {
      super(msg);
      this.setRootCause(t);
   }

   public ResourceClosedException(Throwable t) {
      this.setRootCause(t);
   }

   public ResourceClosedException(String msg) {
      super(msg);
   }

   public ResourceClosedException() {
   }

   public Throwable getCause() {
      return this.rootCause;
   }

   private void setRootCause(Throwable t) {
      this.rootCause = t;
      if (VersionUtils.isAtLeastJavaVersion14()) {
         this.initCause(t);
      }

   }
}