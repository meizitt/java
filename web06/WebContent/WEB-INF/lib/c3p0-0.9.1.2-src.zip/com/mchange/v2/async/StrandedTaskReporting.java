package com.mchange.v2.async;

import java.util.List;

public interface StrandedTaskReporting {
   List getStrandedTasks();
}