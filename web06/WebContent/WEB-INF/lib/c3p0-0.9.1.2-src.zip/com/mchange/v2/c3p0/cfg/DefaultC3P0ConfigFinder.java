package com.mchange.v2.c3p0.cfg;

import com.mchange.v2.cfg.MultiPropertiesConfig;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Properties;

public class DefaultC3P0ConfigFinder implements C3P0ConfigFinder {
   static final String XML_CFG_FILE_KEY = "com.mchange.v2.c3p0.cfg.xml";

   public C3P0Config findConfig() throws Exception {
      HashMap flatDefaults = C3P0ConfigUtils.extractHardcodedC3P0Defaults();
      flatDefaults.putAll(C3P0ConfigUtils.extractC3P0PropertiesResources());
      String cfgFile = MultiPropertiesConfig.readVmConfig().getProperty("com.mchange.v2.c3p0.cfg.xml");
      C3P0Config out;
      if (cfgFile == null) {
         C3P0Config xmlConfig = C3P0ConfigXmlUtils.extractXmlConfigFromDefaultResource();
         if (xmlConfig != null) {
            this.insertDefaultsUnderNascentConfig(flatDefaults, xmlConfig);
            out = xmlConfig;
         } else {
            out = C3P0ConfigUtils.configFromFlatDefaults(flatDefaults);
         }
      } else {
         BufferedInputStream is = new BufferedInputStream(new FileInputStream(cfgFile));

         try {
            C3P0Config xmlConfig = C3P0ConfigXmlUtils.extractXmlConfigFromInputStream(is);
            this.insertDefaultsUnderNascentConfig(flatDefaults, xmlConfig);
            out = xmlConfig;
         } finally {
            try {
               is.close();
            } catch (Exception var11) {
               var11.printStackTrace();
            }

         }
      }

      Properties sysPropConfig = C3P0ConfigUtils.findAllC3P0SystemProperties();
      out.defaultConfig.props.putAll(sysPropConfig);
      return out;
   }

   private void insertDefaultsUnderNascentConfig(HashMap flatDefaults, C3P0Config config) {
      flatDefaults.putAll(config.defaultConfig.props);
      config.defaultConfig.props = flatDefaults;
   }
}