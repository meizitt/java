package com.mchange.v2.c3p0;

import com.mchange.v2.c3p0.cfg.C3P0ConfigUtils;
import com.mchange.v2.c3p0.impl.C3P0Defaults;
import com.mchange.v2.c3p0.impl.IdentityTokenized;
import com.mchange.v2.c3p0.impl.IdentityTokenizedCoalesceChecker;
import com.mchange.v2.c3p0.management.ManagementCoordinator;
import com.mchange.v2.c3p0.management.NullManagementCoordinator;
import com.mchange.v2.coalesce.CoalesceChecker;
import com.mchange.v2.coalesce.Coalescer;
import com.mchange.v2.coalesce.CoalescerFactory;
import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import com.mchange.v2.sql.SqlUtils;
import com.mchange.v2.util.DoubleWeakHashMap;
import java.sql.SQLException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class C3P0Registry {
   private static final String MC_PARAM = "com.mchange.v2.c3p0.management.ManagementCoordinator";
   static final MLogger logger;
   static boolean banner_printed;
   static boolean registry_mbean_registered;
   private static CoalesceChecker CC;
   private static Coalescer idtCoalescer;
   private static Map tokensToTokenized;
   private static HashSet unclosedPooledDataSources;
   private static Map classNamesToConnectionTesters;
   private static Map classNamesToConnectionCustomizers;
   private static ManagementCoordinator mc;

   public static ConnectionTester getConnectionTester(String className) {
      try {
         ConnectionTester out = (ConnectionTester)classNamesToConnectionTesters.get(className);
         if (out == null) {
            out = (ConnectionTester)Class.forName(className).newInstance();
            classNamesToConnectionTesters.put(className, out);
         }

         return out;
      } catch (Exception var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Could not create for find ConnectionTester with class name '" + className + "'. Using default.", var2);
         }

         return C3P0Defaults.connectionTester();
      }
   }

   public static ConnectionCustomizer getConnectionCustomizer(String className) throws SQLException {
      if (className == null) {
         return null;
      } else {
         try {
            ConnectionCustomizer out = (ConnectionCustomizer)classNamesToConnectionCustomizers.get(className);
            if (out == null) {
               out = (ConnectionCustomizer)Class.forName(className).newInstance();
               classNamesToConnectionCustomizers.put(className, out);
            }

            return out;
         } catch (Exception var2) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "Could not create for find ConnectionCustomizer with class name '" + className + "'.", var2);
            }

            throw SqlUtils.toSQLException(var2);
         }
      }
   }

   private static void banner() {
      if (!banner_printed) {
         if (logger.isLoggable(MLevel.INFO)) {
            logger.info("Initializing c3p0-0.9.1.2 [built 21-May-2007 15:04:56; debug? true; trace: 10]");
         }

         banner_printed = true;
      }

   }

   private static void attemptRegisterRegistryMBean() {
      if (!registry_mbean_registered) {
         mc.attemptManageC3P0Registry();
         registry_mbean_registered = true;
      }

   }

   private static boolean isIncorporated(IdentityTokenized idt) {
      return tokensToTokenized.keySet().contains(idt.getIdentityToken());
   }

   private static void incorporate(IdentityTokenized idt) {
      tokensToTokenized.put(idt.getIdentityToken(), idt);
      if (idt instanceof PooledDataSource) {
         unclosedPooledDataSources.add(idt);
         mc.attemptManagePooledDataSource((PooledDataSource)idt);
      }

   }

   public static synchronized IdentityTokenized reregister(IdentityTokenized idt) {
      if (idt instanceof PooledDataSource) {
         banner();
         attemptRegisterRegistryMBean();
      }

      if (idt.getIdentityToken() == null) {
         throw new RuntimeException("[c3p0 issue] The identityToken of a registered object should be set prior to registration.");
      } else {
         IdentityTokenized coalesceCheck = (IdentityTokenized)idtCoalescer.coalesce(idt);
         if (!isIncorporated(coalesceCheck)) {
            incorporate(coalesceCheck);
         }

         return coalesceCheck;
      }
   }

   public static synchronized void markClosed(PooledDataSource pds) {
      unclosedPooledDataSources.remove(pds);
      mc.attemptUnmanagePooledDataSource(pds);
      if (unclosedPooledDataSources.isEmpty()) {
         mc.attemptUnmanageC3P0Registry();
         registry_mbean_registered = false;
      }

   }

   public static synchronized Set getPooledDataSources() {
      return (Set)unclosedPooledDataSources.clone();
   }

   public static synchronized Set pooledDataSourcesByName(String dataSourceName) {
      Set out = new HashSet();
      Iterator ii = unclosedPooledDataSources.iterator();

      while(ii.hasNext()) {
         PooledDataSource pds = (PooledDataSource)ii.next();
         if (pds.getDataSourceName().equals(dataSourceName)) {
            out.add(pds);
         }
      }

      return out;
   }

   public static synchronized PooledDataSource pooledDataSourceByName(String dataSourceName) {
      Iterator ii = unclosedPooledDataSources.iterator();

      PooledDataSource pds;
      do {
         if (!ii.hasNext()) {
            return null;
         }

         pds = (PooledDataSource)ii.next();
      } while(!pds.getDataSourceName().equals(dataSourceName));

      return pds;
   }

   public static synchronized Set allIdentityTokens() {
      Set out = Collections.unmodifiableSet(tokensToTokenized.keySet());
      return out;
   }

   public static synchronized Set allIdentityTokenized() {
      HashSet out = new HashSet();
      out.addAll(tokensToTokenized.values());
      return Collections.unmodifiableSet(out);
   }

   public static synchronized Set allPooledDataSources() {
      Set out = Collections.unmodifiableSet(unclosedPooledDataSources);
      return out;
   }

   public static synchronized int getNumPooledDataSources() {
      return unclosedPooledDataSources.size();
   }

   public static synchronized int getNumPoolsAllDataSources() throws SQLException {
      int count = 0;

      PooledDataSource pds;
      for(Iterator ii = unclosedPooledDataSources.iterator(); ii.hasNext(); count += pds.getNumUserPools()) {
         pds = (PooledDataSource)ii.next();
      }

      return count;
   }

   public synchronized int getNumThreadsAllThreadPools() throws SQLException {
      int count = 0;

      PooledDataSource pds;
      for(Iterator ii = unclosedPooledDataSources.iterator(); ii.hasNext(); count += pds.getNumHelperThreads()) {
         pds = (PooledDataSource)ii.next();
      }

      return count;
   }

   static {
      logger = MLog.getLogger(C3P0Registry.class);
      banner_printed = false;
      registry_mbean_registered = false;
      CC = IdentityTokenizedCoalesceChecker.INSTANCE;
      idtCoalescer = CoalescerFactory.createCoalescer(CC, true, false);
      tokensToTokenized = new DoubleWeakHashMap();
      unclosedPooledDataSources = new HashSet();
      classNamesToConnectionTesters = Collections.synchronizedMap(new HashMap());
      classNamesToConnectionCustomizers = Collections.synchronizedMap(new HashMap());
      classNamesToConnectionTesters.put(C3P0Defaults.connectionTesterClassName(), C3P0Defaults.connectionTester());
      String userManagementCoordinator = C3P0ConfigUtils.getPropFileConfigProperty("com.mchange.v2.c3p0.management.ManagementCoordinator");
      if (userManagementCoordinator != null) {
         try {
            mc = (ManagementCoordinator)Class.forName(userManagementCoordinator).newInstance();
         } catch (Exception var3) {
            if (logger.isLoggable(MLevel.WARNING)) {
               logger.log(MLevel.WARNING, "Could not instantiate user-specified ManagementCoordinator " + userManagementCoordinator + ". Using NullManagementCoordinator (c3p0 JMX management disabled!)", var3);
            }

            mc = new NullManagementCoordinator();
         }
      } else {
         try {
            Class.forName("java.lang.management.ManagementFactory");
            mc = (ManagementCoordinator)Class.forName("com.mchange.v2.c3p0.management.ActiveManagementCoordinator").newInstance();
         } catch (Exception var2) {
            if (logger.isLoggable(MLevel.INFO)) {
               logger.log(MLevel.INFO, "jdk1.5 management interfaces unavailable... JMX support disabled.", var2);
            }

            mc = new NullManagementCoordinator();
         }
      }

   }
}