package com.mchange.v1.lang;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class ClassUtils {
   static final String[] EMPTY_SA = new String[0];
   static Map primitivesToClasses;

   public static Set allAssignableFrom(Class type) {
      Set out = new HashSet();

      for(Class cl = type; cl != null; cl = cl.getSuperclass()) {
         out.add(cl);
      }

      addSuperInterfacesToSet(type, out);
      return out;
   }

   public static String simpleClassName(Class cl) {
      int array_level;
      for(array_level = 0; cl.isArray(); cl = cl.getComponentType()) {
         ++array_level;
      }

      String scn = simpleClassName(cl.getName());
      if (array_level <= 0) {
         return scn;
      } else {
         StringBuffer sb = new StringBuffer(16);
         sb.append(scn);

         for(int i = 0; i < array_level; ++i) {
            sb.append("[]");
         }

         return sb.toString();
      }
   }

   private static String simpleClassName(String fqcn) {
      int pkgdot = fqcn.lastIndexOf(46);
      if (pkgdot < 0) {
         return fqcn;
      } else {
         String scn = fqcn.substring(pkgdot + 1);
         if (scn.indexOf(36) >= 0) {
            StringBuffer sb = new StringBuffer(scn);
            int i = 0;

            for(int len = sb.length(); i < len; ++i) {
               if (sb.charAt(i) == '$') {
                  sb.setCharAt(i, '.');
               }
            }

            return sb.toString();
         } else {
            return scn;
         }
      }
   }

   public static boolean isPrimitive(String typeStr) {
      return primitivesToClasses.get(typeStr) != null;
   }

   public static Class classForPrimitive(String typeStr) {
      return (Class)primitivesToClasses.get(typeStr);
   }

   public static Class forName(String fqcnOrPrimitive) throws ClassNotFoundException {
      Class out = classForPrimitive(fqcnOrPrimitive);
      if (out == null) {
         out = Class.forName(fqcnOrPrimitive);
      }

      return out;
   }

   public static Class forName(String fqOrSimple, String[] importPkgs, String[] importClasses) throws AmbiguousClassNameException, ClassNotFoundException {
      try {
         return Class.forName(fqOrSimple);
      } catch (ClassNotFoundException var4) {
         return classForSimpleName(fqOrSimple, importPkgs, importClasses);
      }
   }

   public static Class classForSimpleName(String simpleName, String[] importPkgs, String[] importClasses) throws AmbiguousClassNameException, ClassNotFoundException {
      Set checkSet = new HashSet();
      Class out = classForPrimitive(simpleName);
      if (out == null) {
         if (importPkgs == null) {
            importPkgs = EMPTY_SA;
         }

         if (importClasses == null) {
            importClasses = EMPTY_SA;
         }

         int i = 0;

         int len;
         String tryClass;
         for(len = importClasses.length; i < len; ++i) {
            tryClass = fqcnLastElement(importClasses[i]);
            if (!checkSet.add(tryClass)) {
               throw new IllegalArgumentException("Duplicate imported classes: " + tryClass);
            }

            if (simpleName.equals(tryClass)) {
               out = Class.forName(importClasses[i]);
            }
         }

         if (out == null) {
            try {
               out = Class.forName("java.lang." + simpleName);
            } catch (ClassNotFoundException var10) {
               ;
            }

            i = 0;

            for(len = importPkgs.length; i < len; ++i) {
               try {
                  tryClass = importPkgs[i] + '.' + simpleName;
                  Class test = Class.forName(tryClass);
                  if (out != null) {
                     throw new AmbiguousClassNameException(simpleName, out, test);
                  }

                  out = test;
               } catch (ClassNotFoundException var9) {
                  ;
               }
            }
         }
      }

      if (out == null) {
         throw new ClassNotFoundException("Could not find a class whose unqualified name is \"" + simpleName + "\" with the imports supplied. Import packages are " + Arrays.asList(importPkgs) + "; class imports are " + Arrays.asList(importClasses));
      } else {
         return out;
      }
   }

   public static String resolvableTypeName(Class type, String[] importPkgs, String[] importClasses) throws ClassNotFoundException {
      String simpleName = simpleClassName(type);

      try {
         classForSimpleName(simpleName, importPkgs, importClasses);
         return simpleName;
      } catch (AmbiguousClassNameException var5) {
         return type.getName();
      }
   }

   public static String fqcnLastElement(String fqcn) {
      int pkgdot = fqcn.lastIndexOf(46);
      return pkgdot < 0 ? fqcn : fqcn.substring(pkgdot + 1);
   }

   private static void addSuperInterfacesToSet(Class type, Set set) {
      Class[] ifaces = type.getInterfaces();
      int i = 0;

      for(int len = ifaces.length; i < len; ++i) {
         set.add(ifaces[i]);
         addSuperInterfacesToSet(ifaces[i], set);
      }

   }

   static {
      HashMap tmp = new HashMap();
      tmp.put("boolean", Boolean.TYPE);
      tmp.put("int", Integer.TYPE);
      tmp.put("char", Character.TYPE);
      tmp.put("short", Short.TYPE);
      tmp.put("int", Integer.TYPE);
      tmp.put("long", Long.TYPE);
      tmp.put("float", Float.TYPE);
      tmp.put("double", Double.TYPE);
      tmp.put("void", Void.TYPE);
      primitivesToClasses = Collections.unmodifiableMap(tmp);
   }
}