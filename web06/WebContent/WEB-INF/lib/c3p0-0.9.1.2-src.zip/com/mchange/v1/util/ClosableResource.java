package com.mchange.v1.util;

public interface ClosableResource {
   void close() throws Exception;
}