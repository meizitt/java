package com.mchange.v1.identicator;

import com.mchange.v1.identicator.IdMap.1;
import com.mchange.v1.identicator.IdMap.UserEntrySet;
import com.mchange.v1.util.SimpleMapEntry;
import java.util.AbstractMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

abstract class IdMap extends AbstractMap implements Map {
   Map inner;
   Identicator id;

   protected IdMap(Map inner, Identicator id) {
      this.inner = inner;
      this.id = id;
   }

   public Object put(Object key, Object value) {
      return this.inner.put(this.createIdKey(key), value);
   }

   public boolean containsKey(Object key) {
      return this.inner.containsKey(this.createIdKey(key));
   }

   public Object get(Object key) {
      return this.inner.get(this.createIdKey(key));
   }

   public Object remove(Object key) {
      return this.inner.remove(this.createIdKey(key));
   }

   protected Object removeIdHashKey(IdHashKey idhk) {
      return this.inner.remove(idhk);
   }

   public Set entrySet() {
      return new UserEntrySet(this, (1)null);
   }

   protected final Set internalEntrySet() {
      return this.inner.entrySet();
   }

   protected abstract IdHashKey createIdKey(Object var1);

   protected final Entry createIdEntry(Object key, Object val) {
      return new SimpleMapEntry(this.createIdKey(key), val);
   }

   protected final Entry createIdEntry(Entry entry) {
      return this.createIdEntry(entry.getKey(), entry.getValue());
   }
}