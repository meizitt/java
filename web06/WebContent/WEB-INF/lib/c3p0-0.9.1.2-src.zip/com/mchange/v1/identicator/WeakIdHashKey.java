package com.mchange.v1.identicator;

import com.mchange.v1.identicator.WeakIdHashKey.Ref;
import java.lang.ref.ReferenceQueue;

final class WeakIdHashKey extends IdHashKey {
   Ref keyRef;
   int hash;

   public WeakIdHashKey(Object keyObj, Identicator id, ReferenceQueue rq) {
      super(id);
      if (keyObj == null) {
         throw new UnsupportedOperationException("Collection does not accept nulls!");
      } else {
         this.keyRef = new Ref(this, keyObj, rq);
         this.hash = id.hash(keyObj);
      }
   }

   public Ref getInternalRef() {
      return this.keyRef;
   }

   public Object getKeyObj() {
      return this.keyRef.get();
   }

   public boolean equals(Object o) {
      if (o instanceof WeakIdHashKey) {
         WeakIdHashKey other = (WeakIdHashKey)o;
         if (this.keyRef == other.keyRef) {
            return true;
         } else {
            Object myKeyObj = this.keyRef.get();
            Object oKeyObj = other.keyRef.get();
            return myKeyObj != null && oKeyObj != null ? this.id.identical(myKeyObj, oKeyObj) : false;
         }
      } else {
         return false;
      }
   }

   public int hashCode() {
      return this.hash;
   }
}