package com.mchange.v1.util;

import java.util.Map.Entry;

public class SimpleMapEntry extends AbstractMapEntry implements Entry {
   Object key;
   Object value;

   public SimpleMapEntry(Object key, Object value) {
      this.key = key;
      this.value = value;
   }

   public Object getKey() {
      return this.key;
   }

   public Object getValue() {
      return this.value;
   }

   public Object setValue(Object value) {
      this.value = value;
      return value;
   }
}