package com.mchange.v1.xml;

import com.mchange.v1.util.DebugUtils;
import com.mchange.v1.xml.DomParseUtils.1;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public final class DomParseUtils {
   static final boolean DEBUG = true;

   public static String allTextFromUniqueChild(Element elem, String childTagName) throws DOMException {
      return allTextFromUniqueChild(elem, childTagName, false);
   }

   public static String allTextFromUniqueChild(Element elem, String childTagName, boolean trim) throws DOMException {
      Element uniqueChild = uniqueChildByTagName(elem, childTagName);
      return uniqueChild == null ? null : allTextFromElement(uniqueChild, trim);
   }

   public static Element uniqueChild(Element elem, String childTagName) throws DOMException {
      return uniqueChildByTagName(elem, childTagName);
   }

   
   public static Element uniqueChildByTagName(Element elem, String childTagName) throws DOMException {
      NodeList nl = elem.getElementsByTagName(childTagName);
      int len = nl.getLength();
      DebugUtils.myAssert(len <= 1, "There is more than one (" + len + ") child with tag name: " + childTagName + "!!!");
      return len == 1 ? (Element)nl.item(0) : null;
   }

   public static String allText(Element elem) throws DOMException {
      return allTextFromElement(elem);
   }

   public static String allText(Element elem, boolean trim) throws DOMException {
      return allTextFromElement(elem, trim);
   }

   
   public static String allTextFromElement(Element elem) throws DOMException {
      return allTextFromElement(elem, false);
   }

   
   public static String allTextFromElement(Element elem, boolean trim) throws DOMException {
      StringBuffer textBuf = new StringBuffer();
      NodeList nl = elem.getChildNodes();
      int j = 0;

      for(int len = nl.getLength(); j < len; ++j) {
         Node node = nl.item(j);
         if (node instanceof Text) {
            textBuf.append(node.getNodeValue());
         }
      }

      String out = textBuf.toString();
      return trim ? out.trim() : out;
   }

   public static String[] allTextFromImmediateChildElements(Element parent, String tagName) throws DOMException {
      return allTextFromImmediateChildElements(parent, tagName, false);
   }

   public static String[] allTextFromImmediateChildElements(Element parent, String tagName, boolean trim) throws DOMException {
      NodeList nl = immediateChildElementsByTagName(parent, tagName);
      int len = nl.getLength();
      String[] out = new String[len];

      for(int i = 0; i < len; ++i) {
         out[i] = allText((Element)nl.item(i), trim);
      }

      return out;
   }

   public static NodeList immediateChildElementsByTagName(Element parent, String tagName) throws DOMException {
      return getImmediateChildElementsByTagName(parent, tagName);
   }

   
   public static NodeList getImmediateChildElementsByTagName(Element parent, String tagName) throws DOMException {
      List nodes = new ArrayList();

      for(Node child = parent.getFirstChild(); child != null; child = child.getNextSibling()) {
         if (child instanceof Element && ((Element)child).getTagName().equals(tagName)) {
            nodes.add(child);
         }
      }

      return new 1(nodes);
   }

   public static String allTextFromUniqueImmediateChild(Element elem, String childTagName) throws DOMException {
      Element uniqueChild = uniqueImmediateChildByTagName(elem, childTagName);
      return uniqueChild == null ? null : allTextFromElement(uniqueChild);
   }

   public static Element uniqueImmediateChild(Element elem, String childTagName) throws DOMException {
      return uniqueImmediateChildByTagName(elem, childTagName);
   }

   
   public static Element uniqueImmediateChildByTagName(Element elem, String childTagName) throws DOMException {
      NodeList nl = getImmediateChildElementsByTagName(elem, childTagName);
      int len = nl.getLength();
      DebugUtils.myAssert(len <= 1, "There is more than one (" + len + ") child with tag name: " + childTagName + "!!!");
      return len == 1 ? (Element)nl.item(0) : null;
   }

   
   public static String attrValFromElement(Element element, String attrName) throws DOMException {
      Attr attr = element.getAttributeNode(attrName);
      return attr == null ? null : attr.getValue();
   }
}