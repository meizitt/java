package com.mchange.v1.db.sql;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.sql.SQLException;
import java.sql.Statement;

public final class StatementUtils {
   private static final MLogger logger;

   public static boolean attemptClose(Statement stmt) {
      try {
         if (stmt != null) {
            stmt.close();
         }

         return true;
      } catch (SQLException var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "Statement close FAILED.", var2);
         }

         return false;
      }
   }

   static {
      logger = MLog.getLogger(StatementUtils.class);
   }
}