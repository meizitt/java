package com.mchange.v1.io;

import com.mchange.v2.log.MLevel;
import com.mchange.v2.log.MLog;
import com.mchange.v2.log.MLogger;
import java.io.IOException;
import java.io.OutputStream;

public final class OutputStreamUtils {
   private static final MLogger logger;

   public static void attemptClose(OutputStream os) {
      try {
         if (os != null) {
            os.close();
         }
      } catch (IOException var2) {
         if (logger.isLoggable(MLevel.WARNING)) {
            logger.log(MLevel.WARNING, "OutputStream close FAILED.", var2);
         }
      }

   }

   static {
      logger = MLog.getLogger(OutputStreamUtils.class);
   }
}