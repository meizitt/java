package com.mchange.v1.identicator;

import com.mchange.v1.identicator.IdWeakHashMap.1;
import com.mchange.v1.identicator.IdWeakHashMap.WeakUserEntrySet;
import com.mchange.v1.identicator.WeakIdHashKey.Ref;
import java.lang.ref.ReferenceQueue;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class IdWeakHashMap extends IdMap implements Map {
   ReferenceQueue rq = new ReferenceQueue();

   public IdWeakHashMap(Identicator id) {
      super(new HashMap(), id);
   }

   public int size() {
      this.cleanCleared();
      return super.size();
   }

   public boolean isEmpty() {
      boolean var1;
      try {
         var1 = super.isEmpty();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public boolean containsKey(Object o) {
      boolean var2;
      try {
         var2 = super.containsKey(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public boolean containsValue(Object o) {
      boolean var2;
      try {
         var2 = super.containsValue(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public Object get(Object o) {
      Object var2;
      try {
         var2 = super.get(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public Object put(Object k, Object v) {
      Object var3;
      try {
         var3 = super.put(k, v);
      } finally {
         this.cleanCleared();
      }

      return var3;
   }

   public Object remove(Object o) {
      Object var2;
      try {
         var2 = super.remove(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public void putAll(Map m) {
      try {
         super.putAll(m);
      } finally {
         this.cleanCleared();
      }

   }

   public void clear() {
      try {
         super.clear();
      } finally {
         this.cleanCleared();
      }

   }

   public Set keySet() {
      Set var1;
      try {
         var1 = super.keySet();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public Collection values() {
      Collection var1;
      try {
         var1 = super.values();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public Set entrySet() {
      WeakUserEntrySet var1;
      try {
         var1 = new WeakUserEntrySet(this, (1)null);
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   public boolean equals(Object o) {
      boolean var2;
      try {
         var2 = super.equals(o);
      } finally {
         this.cleanCleared();
      }

      return var2;
   }

   public int hashCode() {
      int var1;
      try {
         var1 = super.hashCode();
      } finally {
         this.cleanCleared();
      }

      return var1;
   }

   protected IdHashKey createIdKey(Object o) {
      return new WeakIdHashKey(o, this.id, this.rq);
   }

   private void cleanCleared() {
      Ref ref;
      while((ref = (Ref)this.rq.poll()) != null) {
         this.removeIdHashKey(ref.getKey());
      }

   }
}