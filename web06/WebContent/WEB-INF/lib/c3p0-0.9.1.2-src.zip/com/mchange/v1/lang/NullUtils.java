package com.mchange.v1.lang;


public final class NullUtils {
   public static boolean equalsOrBothNull(Object a, Object b) {
      if (a == b) {
         return true;
      } else {
         return a == null ? false : a.equals(b);
      }
   }
}