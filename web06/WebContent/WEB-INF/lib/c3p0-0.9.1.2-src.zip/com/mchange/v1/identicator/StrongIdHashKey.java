package com.mchange.v1.identicator;

final class StrongIdHashKey extends IdHashKey {
   Object keyObj;

   public StrongIdHashKey(Object keyObj, Identicator id) {
      super(id);
      this.keyObj = keyObj;
   }

   public Object getKeyObj() {
      return this.keyObj;
   }

   public boolean equals(Object o) {
      return o instanceof StrongIdHashKey ? this.id.identical(this.keyObj, ((StrongIdHashKey)o).keyObj) : false;
   }

   public int hashCode() {
      return this.id.hash(this.keyObj);
   }
}