package com.mchange.util;

public class AssertException extends RuntimeException {
   public AssertException(String message) {
      super(message);
   }

   public AssertException() {
   }
}