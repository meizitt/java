package javax.servlet;

import java.util.Collection;
import java.util.Set;

public interface ServletRegistration extends Registration {
   Set<String> addMapping(String... var1);

   Collection<String> getMappings();

   String getRunAsRole();
}