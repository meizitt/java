package javax.servlet.http;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.function.Supplier;
import javax.servlet.ServletResponse;

public interface HttpServletResponse extends ServletResponse {
   int SC_CONTINUE = 100;
   int SC_SWITCHING_PROTOCOLS = 101;
   int SC_OK = 200;
   int SC_CREATED = 201;
   int SC_ACCEPTED = 202;
   int SC_NON_AUTHORITATIVE_INFORMATION = 203;
   int SC_NO_CONTENT = 204;
   int SC_RESET_CONTENT = 205;
   int SC_PARTIAL_CONTENT = 206;
   int SC_MULTIPLE_CHOICES = 300;
   int SC_MOVED_PERMANENTLY = 301;
   int SC_MOVED_TEMPORARILY = 302;
   int SC_FOUND = 302;
   int SC_SEE_OTHER = 303;
   int SC_NOT_MODIFIED = 304;
   int SC_USE_PROXY = 305;
   int SC_TEMPORARY_REDIRECT = 307;
   int SC_BAD_REQUEST = 400;
   int SC_UNAUTHORIZED = 401;
   int SC_PAYMENT_REQUIRED = 402;
   int SC_FORBIDDEN = 403;
   int SC_NOT_FOUND = 404;
   int SC_METHOD_NOT_ALLOWED = 405;
   int SC_NOT_ACCEPTABLE = 406;
   int SC_PROXY_AUTHENTICATION_REQUIRED = 407;
   int SC_REQUEST_TIMEOUT = 408;
   int SC_CONFLICT = 409;
   int SC_GONE = 410;
   int SC_LENGTH_REQUIRED = 411;
   int SC_PRECONDITION_FAILED = 412;
   int SC_REQUEST_ENTITY_TOO_LARGE = 413;
   int SC_REQUEST_URI_TOO_LONG = 414;
   int SC_UNSUPPORTED_MEDIA_TYPE = 415;
   int SC_REQUESTED_RANGE_NOT_SATISFIABLE = 416;
   int SC_EXPECTATION_FAILED = 417;
   int SC_INTERNAL_SERVER_ERROR = 500;
   int SC_NOT_IMPLEMENTED = 501;
   int SC_BAD_GATEWAY = 502;
   int SC_SERVICE_UNAVAILABLE = 503;
   int SC_GATEWAY_TIMEOUT = 504;
   int SC_HTTP_VERSION_NOT_SUPPORTED = 505;

   void addCookie(Cookie var1);

   boolean containsHeader(String var1);

   String encodeURL(String var1);

   String encodeRedirectURL(String var1);

   
   @Deprecated
   String encodeUrl(String var1);

   
   @Deprecated
   String encodeRedirectUrl(String var1);

   void sendError(int var1, String var2) throws IOException;

   void sendError(int var1) throws IOException;

   void sendRedirect(String var1) throws IOException;

   void setDateHeader(String var1, long var2);

   void addDateHeader(String var1, long var2);

   void setHeader(String var1, String var2);

   void addHeader(String var1, String var2);

   void setIntHeader(String var1, int var2);

   void addIntHeader(String var1, int var2);

   void setStatus(int var1);

   
   @Deprecated
   void setStatus(int var1, String var2);

   int getStatus();

   String getHeader(String var1);

   Collection<String> getHeaders(String var1);

   Collection<String> getHeaderNames();

   default void setTrailerFields(Supplier<Map<String, String>> supplier) {
   }

   default Supplier<Map<String, String>> getTrailerFields() {
      return null;
   }
}