package javax.servlet.http;

public enum MappingMatch {
   CONTEXT_ROOT,
   DEFAULT,
   EXACT,
   EXTENSION,
   PATH;
}