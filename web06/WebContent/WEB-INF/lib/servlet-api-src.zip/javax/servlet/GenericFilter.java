package javax.servlet;

import java.io.Serializable;
import java.util.Enumeration;

public abstract class GenericFilter implements Filter, FilterConfig, Serializable {
   private static final long serialVersionUID = 1L;
   private volatile FilterConfig filterConfig;

   public String getInitParameter(String name) {
      return this.getFilterConfig().getInitParameter(name);
   }

   public Enumeration<String> getInitParameterNames() {
      return this.getFilterConfig().getInitParameterNames();
   }

   public FilterConfig getFilterConfig() {
      return this.filterConfig;
   }

   public ServletContext getServletContext() {
      return this.getFilterConfig().getServletContext();
   }

   public void init(FilterConfig filterConfig) throws ServletException {
      this.filterConfig = filterConfig;
      this.init();
   }

   public void init() throws ServletException {
   }

   public String getFilterName() {
      return this.getFilterConfig().getFilterName();
   }
}