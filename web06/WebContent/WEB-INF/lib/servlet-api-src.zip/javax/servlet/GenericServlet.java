package javax.servlet;

import java.io.IOException;
import java.io.Serializable;
import java.util.Enumeration;

public abstract class GenericServlet implements Servlet, ServletConfig, Serializable {
   private static final long serialVersionUID = 1L;
   private transient ServletConfig config;

   public void destroy() {
   }

   public String getInitParameter(String name) {
      return this.getServletConfig().getInitParameter(name);
   }

   public Enumeration<String> getInitParameterNames() {
      return this.getServletConfig().getInitParameterNames();
   }

   public ServletConfig getServletConfig() {
      return this.config;
   }

   public ServletContext getServletContext() {
      return this.getServletConfig().getServletContext();
   }

   public String getServletInfo() {
      return "";
   }

   public void init(ServletConfig config) throws ServletException {
      this.config = config;
      this.init();
   }

   public void init() throws ServletException {
   }

   public void log(String msg) {
      this.getServletContext().log(this.getServletName() + ": " + msg);
   }

   public void log(String message, Throwable t) {
      this.getServletContext().log(this.getServletName() + ": " + message, t);
   }

   public abstract void service(ServletRequest var1, ServletResponse var2) throws ServletException, IOException;

   public String getServletName() {
      return this.config.getServletName();
   }
}