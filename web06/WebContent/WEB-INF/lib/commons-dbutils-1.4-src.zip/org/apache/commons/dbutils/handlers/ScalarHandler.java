package org.apache.commons.dbutils.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.commons.dbutils.ResultSetHandler;

public class ScalarHandler implements ResultSetHandler<Object> {
   private final int columnIndex;
   private final String columnName;

   public ScalarHandler() {
      this(1, (String)null);
   }

   public ScalarHandler(int columnIndex) {
      this(columnIndex, (String)null);
   }

   public ScalarHandler(String columnName) {
      this(1, columnName);
   }

   private ScalarHandler(int columnIndex, String columnName) {
      this.columnIndex = columnIndex;
      this.columnName = columnName;
   }

   public Object handle(ResultSet rs) throws SQLException {
      if (rs.next()) {
         return this.columnName == null ? rs.getObject(this.columnIndex) : rs.getObject(this.columnName);
      } else {
         return null;
      }
   }
}