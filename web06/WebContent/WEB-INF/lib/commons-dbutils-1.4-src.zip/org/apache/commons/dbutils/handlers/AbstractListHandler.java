package org.apache.commons.dbutils.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.dbutils.ResultSetHandler;

public abstract class AbstractListHandler<T> implements ResultSetHandler<List<T>> {
   public List<T> handle(ResultSet rs) throws SQLException {
      ArrayList rows = new ArrayList();

      while(rs.next()) {
         rows.add(this.handleRow(rs));
      }

      return rows;
   }

   protected abstract T handleRow(ResultSet var1) throws SQLException;
}