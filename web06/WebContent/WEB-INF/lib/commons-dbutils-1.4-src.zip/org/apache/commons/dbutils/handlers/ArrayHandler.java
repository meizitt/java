package org.apache.commons.dbutils.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.commons.dbutils.BasicRowProcessor;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.RowProcessor;

public class ArrayHandler implements ResultSetHandler<Object[]> {
   static final RowProcessor ROW_PROCESSOR = new BasicRowProcessor();
   private final RowProcessor convert;

   public ArrayHandler() {
      this(ROW_PROCESSOR);
   }

   public ArrayHandler(RowProcessor convert) {
      this.convert = convert;
   }

   public Object[] handle(ResultSet rs) throws SQLException {
      return rs.next() ? this.convert.toArray(rs) : null;
   }
}