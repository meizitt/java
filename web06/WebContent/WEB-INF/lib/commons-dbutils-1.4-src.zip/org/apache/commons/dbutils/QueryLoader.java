package org.apache.commons.dbutils;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class QueryLoader {
   private static final QueryLoader instance = new QueryLoader();
   private final Map<String, Map<String, String>> queries = new HashMap();

   public static QueryLoader instance() {
      return instance;
   }

   public synchronized Map<String, String> load(String path) throws IOException {
      Map<String, String> queryMap = (Map)this.queries.get(path);
      if (queryMap == null) {
         queryMap = this.loadQueries(path);
         this.queries.put(path, queryMap);
      }

      return queryMap;
   }

   protected Map<String, String> loadQueries(String path) throws IOException {
      InputStream in = this.getClass().getResourceAsStream(path);
      if (in == null) {
         throw new IllegalArgumentException(path + " not found.");
      } else {
         Properties props = new Properties();

         try {
            props.load(in);
         } finally {
            in.close();
         }

         HashMap var4 = new HashMap(props);
         return var4;
      }
   }

   public synchronized void unload(String path) {
      this.queries.remove(path);
   }
}