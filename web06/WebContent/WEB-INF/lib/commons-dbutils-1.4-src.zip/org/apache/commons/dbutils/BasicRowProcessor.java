package org.apache.commons.dbutils;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbutils.BasicRowProcessor.1;
import org.apache.commons.dbutils.BasicRowProcessor.CaseInsensitiveHashMap;

public class BasicRowProcessor implements RowProcessor {
   private static final BeanProcessor defaultConvert = new BeanProcessor();
   private static final BasicRowProcessor instance = new BasicRowProcessor();
   private final BeanProcessor convert;

   
   @Deprecated
   public static BasicRowProcessor instance() {
      return instance;
   }

   public BasicRowProcessor() {
      this(defaultConvert);
   }

   public BasicRowProcessor(BeanProcessor convert) {
      this.convert = convert;
   }

   public Object[] toArray(ResultSet rs) throws SQLException {
      ResultSetMetaData meta = rs.getMetaData();
      int cols = meta.getColumnCount();
      Object[] result = new Object[cols];

      for(int i = 0; i < cols; ++i) {
         result[i] = rs.getObject(i + 1);
      }

      return result;
   }

   public <T> T toBean(ResultSet rs, Class<T> type) throws SQLException {
      return this.convert.toBean(rs, type);
   }

   public <T> List<T> toBeanList(ResultSet rs, Class<T> type) throws SQLException {
      return this.convert.toBeanList(rs, type);
   }

   public Map<String, Object> toMap(ResultSet rs) throws SQLException {
      Map<String, Object> result = new CaseInsensitiveHashMap((1)null);
      ResultSetMetaData rsmd = rs.getMetaData();
      int cols = rsmd.getColumnCount();

      for(int i = 1; i <= cols; ++i) {
         result.put(rsmd.getColumnName(i), rs.getObject(i));
      }

      return result;
   }
}