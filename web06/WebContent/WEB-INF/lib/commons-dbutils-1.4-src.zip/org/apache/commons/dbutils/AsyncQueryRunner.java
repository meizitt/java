package org.apache.commons.dbutils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import javax.sql.DataSource;
import org.apache.commons.dbutils.AsyncQueryRunner.BatchCallableStatement;
import org.apache.commons.dbutils.AsyncQueryRunner.QueryCallableStatement;
import org.apache.commons.dbutils.AsyncQueryRunner.UpdateCallableStatement;

public class AsyncQueryRunner extends AbstractQueryRunner {
   private final ExecutorService executorService;

   public AsyncQueryRunner(ExecutorService executorService) {
      this((DataSource)null, false, executorService);
   }

   public AsyncQueryRunner(boolean pmdKnownBroken, ExecutorService executorService) {
      this((DataSource)null, pmdKnownBroken, executorService);
   }

   public AsyncQueryRunner(DataSource ds, ExecutorService executorService) {
      this(ds, false, executorService);
   }

   public AsyncQueryRunner(DataSource ds, boolean pmdKnownBroken, ExecutorService executorService) {
      super(ds, pmdKnownBroken);
      this.executorService = executorService;
   }

   public Future<int[]> batch(Connection conn, String sql, Object[][] params) throws SQLException {
      return this.executorService.submit(this.batch(conn, false, sql, params));
   }

   public Future<int[]> batch(String sql, Object[][] params) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.batch(conn, true, sql, params));
   }

   private Callable<int[]> batch(Connection conn, boolean closeConn, String sql, Object[][] params) throws SQLException {
      if (conn == null) {
         throw new SQLException("Null connection");
      } else if (sql == null) {
         if (closeConn) {
            this.close(conn);
         }

         throw new SQLException("Null SQL statement");
      } else if (params == null) {
         if (closeConn) {
            this.close(conn);
         }

         throw new SQLException("Null parameters. If parameters aren't need, pass an empty array.");
      } else {
         PreparedStatement stmt = null;
         BatchCallableStatement ret = null;

         try {
            stmt = this.prepareStatement(conn, sql);

            for(int i = 0; i < params.length; ++i) {
               this.fillStatement(stmt, params[i]);
               stmt.addBatch();
            }

            ret = new BatchCallableStatement(this, sql, params, conn, closeConn, stmt);
         } catch (SQLException var8) {
            this.close(stmt);
            this.close(conn);
            this.rethrow(var8, sql, (Object[])params);
         }

         return ret;
      }
   }

   private <T> Callable<T> query(Connection conn, boolean closeConn, String sql, ResultSetHandler<T> rsh, Object... params) throws SQLException {
      PreparedStatement stmt = null;
      Callable<T> ret = null;
      if (conn == null) {
         throw new SQLException("Null connection");
      } else if (sql == null) {
         if (closeConn) {
            this.close(conn);
         }

         throw new SQLException("Null SQL statement");
      } else if (rsh == null) {
         if (closeConn) {
            this.close(conn);
         }

         throw new SQLException("Null ResultSetHandler");
      } else {
         try {
            stmt = this.prepareStatement(conn, sql);
            this.fillStatement(stmt, params);
            ret = new QueryCallableStatement(this, conn, closeConn, stmt, rsh, sql, params);
         } catch (SQLException var9) {
            this.close(stmt);
            if (closeConn) {
               this.close(conn);
            }

            this.rethrow(var9, sql, params);
         }

         return ret;
      }
   }

   public <T> Future<T> query(Connection conn, String sql, ResultSetHandler<T> rsh, Object... params) throws SQLException {
      return this.executorService.submit(this.query(conn, false, sql, rsh, params));
   }

   public <T> Future<T> query(Connection conn, String sql, ResultSetHandler<T> rsh) throws SQLException {
      return this.executorService.submit(this.query(conn, false, sql, rsh, (Object[])null));
   }

   public <T> Future<T> query(String sql, ResultSetHandler<T> rsh, Object... params) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.query(conn, true, sql, rsh, params));
   }

   public <T> Future<T> query(String sql, ResultSetHandler<T> rsh) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.query(conn, true, sql, rsh, (Object[])null));
   }

   private Callable<Integer> update(Connection conn, boolean closeConn, String sql, Object... params) throws SQLException {
      PreparedStatement stmt = null;
      Callable<Integer> ret = null;
      if (conn == null) {
         throw new SQLException("Null connection");
      } else if (sql == null) {
         if (closeConn) {
            this.close(conn);
         }

         throw new SQLException("Null SQL statement");
      } else {
         try {
            stmt = this.prepareStatement(conn, sql);
            this.fillStatement(stmt, params);
            ret = new UpdateCallableStatement(this, conn, closeConn, stmt, sql, params);
         } catch (SQLException var8) {
            this.close(stmt);
            if (closeConn) {
               this.close(conn);
            }

            this.rethrow(var8, sql, params);
         }

         return ret;
      }
   }

   public Future<Integer> update(Connection conn, String sql) throws SQLException {
      return this.executorService.submit(this.update(conn, false, sql, (Object[])null));
   }

   public Future<Integer> update(Connection conn, String sql, Object param) throws SQLException {
      return this.executorService.submit(this.update(conn, false, sql, param));
   }

   public Future<Integer> update(Connection conn, String sql, Object... params) throws SQLException {
      return this.executorService.submit(this.update(conn, false, sql, params));
   }

   public Future<Integer> update(String sql) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.update(conn, true, sql, (Object[])null));
   }

   public Future<Integer> update(String sql, Object param) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.update(conn, true, sql, param));
   }

   public Future<Integer> update(String sql, Object... params) throws SQLException {
      Connection conn = this.prepareConnection();
      return this.executorService.submit(this.update(conn, true, sql, params));
   }
}